﻿"""
tests/unit/test_auth_service.py
Unit tests for services/auth_service.py.

Tasks covered: 5.2 (Property 3), 5.3 (Property 4), 5.4 (unit tests)
Requirements:  1.1-1.6, 2.1-2.6, 13.2
"""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

from trust_trace.database import get_db, init_db
from trust_trace.services import auth_service


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    """Return path to a fresh in-memory-equivalent test DB (file-based for sharing)."""
    path = str(tmp_path / "test.db")
    init_db(path)
    return path


def _register(db_path, email="test@example.com", display_name="Test Co", password="SecurePass123!"):
    return auth_service.register_manufacturer(db_path, email, display_name, password)


# ---------------------------------------------------------------------------
# Registration -- Requirement 1.x
# ---------------------------------------------------------------------------

class TestRegisterManufacturer:
    def test_successful_registration_returns_ok(self, db_path):
        result = _register(db_path)
        assert result["ok"] is True
        assert isinstance(result["manufacturer_id"], int)

    def test_successful_registration_stores_hash_not_plaintext(self, db_path):
        _register(db_path)
        db = get_db(db_path)
        row = db.execute("SELECT password_hash FROM manufacturers WHERE email = ?",
                         ("test@example.com",)).fetchone()
        db.close()
        assert row is not None
        # Hash must not equal the plaintext
        assert row["password_hash"] != "SecurePass123!"
        # bcrypt hashes start with $2b$
        assert row["password_hash"].startswith("$2b$")

    def test_bcrypt_work_factor_12(self, db_path):
        """Requirement 1.5: bcrypt work factor must be at least 12."""
        _register(db_path)
        db = get_db(db_path)
        row = db.execute("SELECT password_hash FROM manufacturers WHERE email = ?",
                         ("test@example.com",)).fetchone()
        db.close()
        # bcrypt hash format: $2b$<rounds>$...
        parts = row["password_hash"].split("$")
        assert int(parts[2]) >= 12

    def test_duplicate_email_returns_error(self, db_path):
        _register(db_path)
        result = _register(db_path)  # second call with same email
        assert result["ok"] is False
        assert result["error"] == "email_already_registered"

    def test_password_too_short_returns_error(self, db_path):
        result = _register(db_path, password="short")
        assert result["ok"] is False
        assert result["error"] == "password_too_short"
        assert result["min_length"] == 12

    def test_password_exactly_12_chars_accepted(self, db_path):
        result = _register(db_path, password="A" * 12)
        assert result["ok"] is True

    def test_password_11_chars_rejected(self, db_path):
        result = _register(db_path, password="A" * 11)
        assert result["ok"] is False
        assert result["error"] == "password_too_short"

    def test_missing_display_name_returns_error(self, db_path):
        result = _register(db_path, display_name="")
        assert result["ok"] is False
        assert result["field"] == "display_name"

    def test_whitespace_only_display_name_returns_error(self, db_path):
        result = _register(db_path, display_name="   ")
        assert result["ok"] is False
        assert result["field"] == "display_name"

    def test_display_name_over_255_chars_returns_error(self, db_path):
        result = _register(db_path, display_name="A" * 256)
        assert result["ok"] is False
        assert result["error"] == "field_too_long"
        assert result["field"] == "display_name"

    def test_invalid_email_format_returns_error(self, db_path):
        result = _register(db_path, email="not-an-email")
        assert result["ok"] is False
        assert result["error"] == "invalid_email_format"
        assert result["field"] == "email"

    def test_email_normalised_to_lowercase(self, db_path):
        result = _register(db_path, email="User@Example.COM")
        assert result["ok"] is True
        db = get_db(db_path)
        row = db.execute("SELECT email FROM manufacturers WHERE id = ?",
                         (result["manufacturer_id"],)).fetchone()
        db.close()
        assert row["email"] == "user@example.com"

    def test_plaintext_password_not_in_db(self, db_path):
        """Requirement 1.6: plaintext password must never be stored."""
        plaintext = "SecurePass123!"
        _register(db_path, password=plaintext)
        db = get_db(db_path)
        rows = db.execute("SELECT * FROM manufacturers").fetchall()
        db.close()
        for row in rows:
            for col in row.keys():
                assert plaintext not in str(row[col]), \
                    f"Plaintext password found in column '{col}'"


# ---------------------------------------------------------------------------
# Login -- Requirement 2.x
# ---------------------------------------------------------------------------

class TestLogin:
    def test_valid_credentials_return_session_token(self, db_path):
        _register(db_path)
        result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        assert result["ok"] is True
        assert "session_token" in result
        assert len(result["session_token"]) == 64   # 32 bytes hex

    def test_session_token_expires_in_8_hours(self, db_path):
        _register(db_path)
        result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        assert result["expires_in_seconds"] == 8 * 3600

    def test_wrong_password_returns_generic_error(self, db_path):
        _register(db_path)
        result = auth_service.login(db_path, "test@example.com", "WrongPassword!")
        assert result["ok"] is False
        assert result["error"] == "authentication_failed"
        # Must NOT hint which field was wrong
        assert "password" not in result.get("error", "")
        assert "email" not in result.get("error", "")

    def test_unknown_email_returns_generic_error(self, db_path):
        result = auth_service.login(db_path, "nobody@example.com", "SomePassword123!")
        assert result["ok"] is False
        assert result["error"] == "authentication_failed"

    def test_case_insensitive_email_login(self, db_path):
        _register(db_path, email="user@example.com")
        result = auth_service.login(db_path, "USER@EXAMPLE.COM", "SecurePass123!")
        assert result["ok"] is True

    def test_session_token_is_stored_in_db(self, db_path):
        _register(db_path)
        result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        token = result["session_token"]
        db = get_db(db_path)
        row = db.execute("SELECT * FROM sessions WHERE token = ?", (token,)).fetchone()
        db.close()
        assert row is not None
        assert row["is_valid"] == 1


# ---------------------------------------------------------------------------
# Account lockout -- Requirement 2.3
# ---------------------------------------------------------------------------

class TestAccountLockout:
    def test_fifth_failure_triggers_lockout(self, db_path):
        _register(db_path)
        for i in range(4):
            r = auth_service.login(db_path, "test@example.com", "WrongPass123!")
            assert r["error"] == "authentication_failed", f"Expected auth failure on attempt {i+1}"

        # 5th failure should trigger lockout
        result = auth_service.login(db_path, "test@example.com", "WrongPass123!")
        assert result["ok"] is False
        assert result["error"] == "account_locked"
        assert "locked_until" in result

    def test_locked_account_rejects_correct_password(self, db_path):
        _register(db_path)
        # Trigger lockout
        for _ in range(5):
            auth_service.login(db_path, "test@example.com", "WrongPass123!")

        # Even the correct password must be rejected while locked
        result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        assert result["ok"] is False
        assert result["error"] == "account_locked"

    def test_lockout_status_endpoint(self, db_path):
        _register(db_path)
        for _ in range(5):
            auth_service.login(db_path, "test@example.com", "WrongPass123!")

        status = auth_service.get_lockout_status(db_path, "test@example.com")
        assert status["locked"] is True
        assert status["locked_until"] is not None

    def test_unlocked_account_status(self, db_path):
        _register(db_path)
        status = auth_service.get_lockout_status(db_path, "test@example.com")
        assert status["locked"] is False
        assert status["locked_until"] is None

    def test_four_failures_do_not_lock(self, db_path):
        _register(db_path)
        for _ in range(4):
            auth_service.login(db_path, "test@example.com", "WrongPass123!")
        result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        assert result["ok"] is True


# ---------------------------------------------------------------------------
# Session validation & logout -- Requirement 2.4-2.6
# ---------------------------------------------------------------------------

class TestSessionManagement:
    def test_valid_session_returns_manufacturer(self, db_path):
        _register(db_path)
        login_result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        token = login_result["session_token"]
        mfg = auth_service.validate_session(db_path, token)
        assert mfg is not None
        assert mfg["email"] == "test@example.com"

    def test_invalid_token_returns_none(self, db_path):
        result = auth_service.validate_session(db_path, "completely-fake-token")
        assert result is None

    def test_empty_token_returns_none(self, db_path):
        assert auth_service.validate_session(db_path, "") is None
        assert auth_service.validate_session(db_path, None) is None

    def test_logout_invalidates_session(self, db_path):
        _register(db_path)
        login_result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        token = login_result["session_token"]

        auth_service.logout(db_path, token)

        result = auth_service.validate_session(db_path, token)
        assert result is None

    def test_expired_session_is_rejected(self, db_path):
        """Requirement 2.5: session inactive for 8+ hours must be rejected."""
        _register(db_path)
        login_result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        token = login_result["session_token"]

        # Artificially age the last_active timestamp
        past = datetime.now(timezone.utc) - timedelta(hours=9)
        past_str = past.strftime("%Y-%m-%dT%H:%M:%SZ")
        db = get_db(db_path)
        db.execute("UPDATE sessions SET last_active = ? WHERE token = ?", (past_str, token))
        db.commit()
        db.close()

        result = auth_service.validate_session(db_path, token)
        assert result is None

    def test_active_session_updates_last_active(self, db_path):
        _register(db_path)
        login_result = auth_service.login(db_path, "test@example.com", "SecurePass123!")
        token = login_result["session_token"]

        db = get_db(db_path)
        before = db.execute("SELECT last_active FROM sessions WHERE token = ?", (token,)).fetchone()["last_active"]
        db.close()

        import time; time.sleep(1)  # ensure timestamp advances
        auth_service.validate_session(db_path, token)

        db = get_db(db_path)
        after = db.execute("SELECT last_active FROM sessions WHERE token = ?", (token,)).fetchone()["last_active"]
        db.close()

        assert after >= before  # last_active was updated


# ---------------------------------------------------------------------------
# Task 5.2 -- Property 3: Whitespace/Short Passwords Rejected
# Feature: trust-trace, Property 3: Whitespace-Only Passwords Are Rejected
# Validates: Requirements 1.3
# ---------------------------------------------------------------------------

_short_pw = st.text(max_size=11)
_whitespace_pw = st.text(
    alphabet=st.characters(whitelist_categories=("Zs",)),
    min_size=1,
    max_size=50,
)



@given(password=st.one_of(_short_pw, _whitespace_pw))
@settings(max_examples=100, deadline=None)
def test_property3_short_or_whitespace_password_rejected(password):
    # Feature: trust-trace, Property 3: Whitespace-Only Passwords Are Rejected
    """Any password shorter than 12 chars or whitespace-only must be rejected."""
    import tempfile, os as _os
    tmp_dir = tempfile.mkdtemp()
    db_path = _os.path.join(tmp_dir, "prop3.db")
    try:
        init_db(db_path)
        result = auth_service.register_manufacturer(
            db_path, "prop3@example.com", "Test Corp", password
        )
        # Either too short or whitespace-only -- both must fail
        if len(password) < 12 or not password.strip():
            assert result["ok"] is False
    finally:
        try:
            _os.unlink(db_path)
            _os.rmdir(tmp_dir)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Task 5.3 -- Property 4: Duplicate Email Rejected
# Feature: trust-trace, Property 4: Duplicate Email Registration Is Rejected
# Validates: Requirements 1.2
# ---------------------------------------------------------------------------

_email_strategy = st.emails()


@given(email=_email_strategy)
@settings(max_examples=50, deadline=None)
def test_property4_duplicate_email_rejected(email):
    # Feature: trust-trace, Property 4: Duplicate Email Registration Is Rejected
    """Any email already in manufacturers must be rejected on second registration."""
    import tempfile, os as _os
    tmp_dir = tempfile.mkdtemp()
    db_path = _os.path.join(tmp_dir, "prop4.db")
    try:
        init_db(db_path)
        first = auth_service.register_manufacturer(db_path, email, "Corp A", "ValidPass123!")
        if not first["ok"]:
            # Email may have failed format validation -- skip this example
            return

        second = auth_service.register_manufacturer(db_path, email, "Corp B", "ValidPass123!")
        assert second["ok"] is False
        assert second["error"] == "email_already_registered"
    finally:
        try:
            _os.unlink(db_path)
            _os.rmdir(tmp_dir)
        except OSError:
            pass