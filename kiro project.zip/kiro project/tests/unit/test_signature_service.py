﻿"""
tests/unit/test_signature_service.py
Unit and property-based tests for services/signature_service.py.

Tasks covered: 3.2 (Property 1), 3.3 (Property 2), 3.4 (unit tests)
Requirements:  10.1, 10.3, 10.4, 10.5, 10.6, 4.2, 4.4, 13.1, 13.4
"""

from __future__ import annotations

import base64
import json
import os
import tempfile

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

import trust_trace.services.signature_service as svc


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

def _write_temp_key() -> str:
    """Generate a P-256 key, write it to a temp file, return the path."""
    private_key = ec.generate_private_key(ec.SECP256R1())
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    tmp.write(pem)
    tmp.close()
    return tmp.name


@pytest.fixture(autouse=True)
def reset_key_cache():
    """Reset module-level key cache before and after every test."""
    svc.reset_keys()
    yield
    svc.reset_keys()


@pytest.fixture()
def key_file(tmp_path):
    """Write a fresh P-256 key into a temp directory and load it."""
    path = str(tmp_path / "private.pem")
    private_key = ec.generate_private_key(ec.SECP256R1())
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(path, "wb") as fh:
        fh.write(pem)
    svc.load_private_key(path)
    return path


def _valid_payload(
    product_id: str = "abc123",
    name: str = "Widget",
    serial_number: str = "SN-001",
    manufacturer_id: int = 1,
    registered_at: str = "2024-01-01T10:00:00Z",
) -> dict:
    return {
        "product_id": product_id,
        "name": name,
        "serial_number": serial_number,
        "manufacturer_id": manufacturer_id,
        "registered_at": registered_at,
    }


# ---------------------------------------------------------------------------
# Task 3.4 -- Unit tests
# ---------------------------------------------------------------------------

class TestLoadPrivateKey:
    def test_loads_valid_key(self, key_file):
        # key_file fixture already called load_private_key()
        # Verify the cache is populated
        assert svc._private_key is not None
        assert svc._public_key is not None

    def test_missing_key_file_raises_runtime_error(self, tmp_path):
        missing = str(tmp_path / "nonexistent.pem")
        with pytest.raises(RuntimeError, match="not found"):
            svc.load_private_key(missing)

    def test_invalid_key_file_raises_runtime_error(self, tmp_path):
        bad_file = tmp_path / "bad.pem"
        bad_file.write_bytes(b"this is not a pem key")
        with pytest.raises(RuntimeError, match="parse"):
            svc.load_private_key(str(bad_file))

    def test_non_ec_key_raises_runtime_error(self, tmp_path):
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.backends import default_backend
        rsa_key = rsa.generate_private_key(
            public_exponent=65537, key_size=2048, backend=default_backend()
        )
        pem = rsa_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        rsa_file = tmp_path / "rsa.pem"
        rsa_file.write_bytes(pem)
        with pytest.raises(RuntimeError):
            svc.load_private_key(str(rsa_file))

    def test_wrong_curve_raises_runtime_error(self, tmp_path):
        key_384 = ec.generate_private_key(ec.SECP384R1())
        pem = key_384.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        path = tmp_path / "p384.pem"
        path.write_bytes(pem)
        with pytest.raises(RuntimeError, match="SECP256R1"):
            svc.load_private_key(str(path))


class TestSignPayload:
    def test_sign_returns_string(self, key_file):
        sig = svc.sign_payload(_valid_payload())
        assert isinstance(sig, str)

    def test_sign_non_empty(self, key_file):
        sig = svc.sign_payload(_valid_payload())
        assert len(sig) > 0

    def test_sign_base64url_no_plus(self, key_file):
        """Requirement 10.6: Base64url output must not contain + characters."""
        sig = svc.sign_payload(_valid_payload())
        assert "+" not in sig

    def test_sign_base64url_no_slash(self, key_file):
        """Requirement 10.6: Base64url output must not contain / characters."""
        sig = svc.sign_payload(_valid_payload())
        assert "/" not in sig

    def test_sign_base64url_no_padding(self, key_file):
        """Requirement 10.6: Base64url output must not contain = padding."""
        sig = svc.sign_payload(_valid_payload())
        assert "=" not in sig

    def test_sign_missing_field_raises_key_error(self, key_file):
        incomplete = {
            "product_id": "abc",
            "name": "Widget",
            # serial_number, manufacturer_id, registered_at missing
        }
        with pytest.raises(KeyError):
            svc.sign_payload(incomplete)

    def test_sign_ignores_extra_fields(self, key_file):
        """Extra fields (e.g. 'sig') must not cause an error."""
        payload = _valid_payload()
        payload["sig"] = "some_previous_sig"
        payload["extra"] = "ignored"
        sig = svc.sign_payload(payload)
        assert isinstance(sig, str)

    def test_sign_without_loaded_key_raises(self):
        # key cache has been reset by autouse fixture
        with pytest.raises(RuntimeError, match="not been loaded"):
            svc.sign_payload(_valid_payload())


class TestVerifyPayload:
    def test_valid_signature_returns_true(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        assert svc.verify_payload(payload, sig) is True

    def test_invalid_signature_string_returns_false(self, key_file):
        payload = _valid_payload()
        assert svc.verify_payload(payload, "completelywrongsignature") is False

    def test_empty_signature_returns_false(self, key_file):
        assert svc.verify_payload(_valid_payload(), "") is False

    def test_tampered_product_id_returns_false(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["product_id"] = "tampered_product_id"
        assert svc.verify_payload(payload, sig) is False

    def test_tampered_name_returns_false(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["name"] = "Counterfeit Widget"
        assert svc.verify_payload(payload, sig) is False

    def test_tampered_serial_number_returns_false(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["serial_number"] = "TAMPERED-SN"
        assert svc.verify_payload(payload, sig) is False

    def test_tampered_manufacturer_id_returns_false(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["manufacturer_id"] = 9999
        assert svc.verify_payload(payload, sig) is False

    def test_tampered_registered_at_returns_false(self, key_file):
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["registered_at"] = "2099-12-31T23:59:59Z"
        assert svc.verify_payload(payload, sig) is False

    def test_extra_fields_in_payload_do_not_affect_verification(self, key_file):
        """Verification must ignore extra keys (e.g. the 'sig' field itself)."""
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        payload["sig"] = sig
        payload["unrelated"] = "extra"
        assert svc.verify_payload(payload, sig) is True

    def test_signature_with_padding_is_accepted(self, key_file):
        """verify_payload must tolerate Base64url signatures that still have = padding."""
        payload = _valid_payload()
        sig = svc.sign_payload(payload)
        padded = sig + "=" * (4 - len(sig) % 4 if len(sig) % 4 else 0)
        assert svc.verify_payload(payload, padded) is True

    def test_verify_without_loaded_key_raises(self):
        with pytest.raises(RuntimeError, match="not available"):
            svc.verify_payload(_valid_payload(), "anysig")


class TestCanonicalisation:
    def test_canonical_is_deterministic(self, key_file):
        """Signing the same payload twice must produce identical canonical bytes."""
        payload = _valid_payload()
        # Sign twice with the same key -- the DER signature bytes will differ
        # (ECDSA is probabilistic) but we can verify both are valid.
        sig1 = svc.sign_payload(payload)
        sig2 = svc.sign_payload(payload)
        # Both signatures are valid over the same canonical bytes
        assert svc.verify_payload(payload, sig1) is True
        assert svc.verify_payload(payload, sig2) is True

    def test_canonical_key_order_independent(self, key_file):
        """Payload with keys in different order must verify identically."""
        p1 = _valid_payload()
        sig = svc.sign_payload(p1)
        # Build p2 with reversed insertion order
        p2 = {k: p1[k] for k in reversed(list(p1.keys()))}
        assert svc.verify_payload(p2, sig) is True


# ---------------------------------------------------------------------------
# Task 3.2 -- Property 1: Signature Round-Trip
# Feature: trust-trace, Property 1: Signature Round-Trip
# Validates: Requirements 10.1, 10.4, 13.4
# ---------------------------------------------------------------------------

# Text strategy that generates printable non-null strings (avoids JSON issues)
_text = st.text(
    alphabet=st.characters(
        whitelist_categories=("Lu", "Ll", "Nd", "Pc", "Pd"),
        whitelist_characters="-_.",
    ),
    min_size=1,
    max_size=80,
)

_payload_strategy = st.fixed_dictionaries(
    {
        "product_id": _text,
        "name": _text,
        "serial_number": _text,
        "manufacturer_id": st.integers(min_value=1, max_value=10_000),
        "registered_at": st.datetimes().map(lambda d: d.strftime("%Y-%m-%dT%H:%M:%SZ")),
    }
)



# ---------------------------------------------------------------------------
# Task 3.2 -- Property 1: Signature Round-Trip
# Feature: trust-trace, Property 1: Signature Round-Trip
# Validates: Requirements 10.1, 10.4, 13.4
# ---------------------------------------------------------------------------

# Text strategy that generates printable non-null strings (avoids JSON issues)
_text = st.text(
    alphabet=st.characters(
        whitelist_categories=("Lu", "Ll", "Nd", "Pc", "Pd"),
        whitelist_characters="-_.",
    ),
    min_size=1,
    max_size=80,
)

_payload_strategy = st.fixed_dictionaries(
    {
        "product_id": _text,
        "name": _text,
        "serial_number": _text,
        "manufacturer_id": st.integers(min_value=1, max_value=10_000),
        "registered_at": st.datetimes().map(lambda d: d.strftime("%Y-%m-%dT%H:%M:%SZ")),
    }
)


def _make_key_in_tempdir() -> str:
    """Write a fresh P-256 private key to a temporary file and return the path.

    Uses tempfile directly (not a pytest fixture) so Hypothesis does not
    flag function-scoped fixture reuse across generated examples.
    """
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    private_key = ec.generate_private_key(ec.SECP256R1())
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    tmp.write(pem)
    tmp.close()
    return tmp.name


@given(payload=_payload_strategy)
@settings(max_examples=100)
def test_property1_signature_round_trip(payload):
    # Feature: trust-trace, Property 1: Signature Round-Trip
    """For any valid canonical payload, sign_payload then verify_payload returns True."""
    svc.reset_keys()
    key_path = _make_key_in_tempdir()
    try:
        svc.load_private_key(key_path)
        sig = svc.sign_payload(payload)
        assert svc.verify_payload(payload, sig) is True
    finally:
        svc.reset_keys()
        try:
            os.unlink(key_path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Task 3.3 -- Property 2: Tampered Payload Fails Verification
# Feature: trust-trace, Property 2: Tampered Payload Fails Verification
# Validates: Requirements 5.3, 10.5
# ---------------------------------------------------------------------------

_tamper_field = st.sampled_from(list(svc.SIGNED_FIELDS))

_tamper_value = st.one_of(
    _text,
    st.integers(min_value=1, max_value=99_999).map(str),
)


@given(payload=_payload_strategy, field=_tamper_field, new_value=_tamper_value)
@settings(max_examples=100)
def test_property2_tampered_payload_fails(payload, field, new_value):
    # Feature: trust-trace, Property 2: Tampered Payload Fails Verification
    """Modifying any single signed field must cause verify_payload to return False."""
    # Skip the trivial case where the "tampered" value equals the original
    if str(payload[field]) == str(new_value):
        return

    svc.reset_keys()
    key_path = _make_key_in_tempdir()
    try:
        svc.load_private_key(key_path)
        sig = svc.sign_payload(payload)

        # Tamper with one field
        tampered = dict(payload)
        if field == "manufacturer_id":
            # manufacturer_id is int -- cast new_value to int with a fallback
            try:
                tampered[field] = int(new_value)
            except ValueError:
                tampered[field] = payload[field] + 1
            if tampered[field] == payload[field]:
                tampered[field] += 1
        else:
            tampered[field] = str(new_value)

        assert svc.verify_payload(tampered, sig) is False
    finally:
        svc.reset_keys()
        try:
            os.unlink(key_path)
        except OSError:
            pass