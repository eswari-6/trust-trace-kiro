﻿"""
tests/unit/test_verification_service.py
Unit tests for services/verification_service.py.

Task: 10.2
Requirements: 5.1-5.6, 13.5
"""

from __future__ import annotations

import base64
import json
import os
import tempfile

import flask_bcrypt as _bcrypt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

from trust_trace.database import apply_migrations, get_db, init_db
from trust_trace.services import verification_service
import trust_trace.services.signature_service as sig_svc


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    path = str(tmp_path / "verify_unit.db")
    init_db(path)
    apply_migrations(path)
    return path


@pytest.fixture()
def key_path(tmp_path):
    sig_svc.reset_keys()
    path = str(tmp_path / "verify.pem")
    pk = ec.generate_private_key(ec.SECP256R1())
    pem = pk.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(path, "wb") as fh:
        fh.write(pem)
    sig_svc.load_private_key(path)
    yield path
    sig_svc.reset_keys()


@pytest.fixture()
def registered_product(db_path, key_path):
    """Insert a manufacturer + signed product; return the product dict."""
    hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
    db = get_db(db_path)
    db.execute(
        "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
        ("verify@example.com", "Verify Corp", hashed),
    )
    db.commit()
    mfg_id = db.execute(
        "SELECT id FROM manufacturers WHERE email = ?", ("verify@example.com",)
    ).fetchone()["id"]

    from trust_trace.services import product_service
    result = product_service.register_product(
        db_path, mfg_id,
        name="Verified Widget", category="Electronics",
        serial_number="SN-VFY-001", brand="TrustBrand", model="VFY-1",
    )
    assert result["ok"]

    db2 = get_db(db_path)
    row = db2.execute("SELECT * FROM products WHERE product_id = ?",
                      (result["product_id"],)).fetchone()
    db2.close()
    return dict(row)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_payload_b64(product: dict, sig: str) -> str:
    obj = {
        "product_id":      product["product_id"],
        "serial_number":   product["serial_number"],
        "name":            product["name"],
        "manufacturer_id": product["manufacturer_id"],
        "registered_at":   product["registered_at"],
        "sig":             sig,
    }
    raw = json.dumps(obj, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


# ---------------------------------------------------------------------------
# Successful verification
# ---------------------------------------------------------------------------

class TestVerifyAuthentic:
    def test_authentic_product_returns_authentic_status(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "authentic"

    def test_authentic_response_includes_product_details(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        product = result["product"]
        assert product["product_id"] == registered_product["product_id"]
        assert product["name"] == registered_product["name"]
        assert product["serial_number"] == registered_product["serial_number"]
        assert product["registered_at"] == registered_product["registered_at"]

    def test_authentic_response_excludes_password_hash(self, db_path, registered_product):
        """Requirement 4.4 / 11.5: sensitive data must not appear in the response."""
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        result_str = json.dumps(result)
        assert "password_hash" not in result_str
        assert "password" not in result_str.lower().replace("password_hash", "")

    def test_authentic_response_excludes_private_key(self, db_path, registered_product, key_path):
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        result_str = json.dumps(result)
        assert "BEGIN PRIVATE KEY" not in result_str

    def test_scan_event_recorded_for_authentic(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        verification_service.verify_product(db_path, payload_b64, "9.9.9.9")
        db = get_db(db_path)
        row = db.execute(
            "SELECT * FROM scan_events WHERE product_id = ?",
            (registered_product["product_id"],),
        ).fetchone()
        db.close()
        assert row is not None
        assert row["outcome"] == "authentic"
        assert row["ip_address"] == "9.9.9.9"


# ---------------------------------------------------------------------------
# Invalid signatures (tampered payloads)
# ---------------------------------------------------------------------------

class TestVerifyInvalid:
    def test_tampered_name_returns_invalid(self, db_path, registered_product):
        tampered = dict(registered_product)
        tampered["name"] = "COUNTERFEIT WIDGET"
        payload_b64 = _make_payload_b64(tampered, registered_product["qr_payload_hash"])
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "invalid"

    def test_tampered_serial_returns_invalid(self, db_path, registered_product):
        tampered = dict(registered_product)
        tampered["serial_number"] = "FAKE-SN"
        payload_b64 = _make_payload_b64(tampered, registered_product["qr_payload_hash"])
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "invalid"

    def test_wrong_signature_returns_invalid(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(registered_product, "invalidsignature")
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "invalid"

    def test_empty_sig_returns_invalid(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(registered_product, "")
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "invalid"

    def test_empty_payload_returns_invalid(self, db_path):
        result = verification_service.verify_product(db_path, "", "1.2.3.4")
        assert result["status"] == "invalid"

    def test_garbage_payload_returns_invalid(self, db_path):
        result = verification_service.verify_product(db_path, "notbase64!!", "1.2.3.4")
        assert result["status"] == "invalid"

    def test_invalid_response_contains_message(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(registered_product, "badsig")
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert "message" in result
        assert len(result["message"]) > 0

    def test_scan_event_recorded_for_invalid(self, db_path, registered_product):
        payload_b64 = _make_payload_b64(registered_product, "badsig")
        verification_service.verify_product(db_path, payload_b64, "3.3.3.3")
        db = get_db(db_path)
        row = db.execute(
            "SELECT * FROM scan_events WHERE product_id = ? AND outcome = 'invalid'",
            (registered_product["product_id"],),
        ).fetchone()
        db.close()
        assert row is not None


# ---------------------------------------------------------------------------
# Not-found products
# ---------------------------------------------------------------------------

class TestVerifyNotFound:
    def test_unknown_product_id_returns_not_found(self, db_path, registered_product):
        unknown = dict(registered_product)
        unknown["product_id"] = "f" * 32
        sig = sig_svc.sign_payload(unknown)
        payload_b64 = _make_payload_b64(unknown, sig)
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert result["status"] == "not_found"

    def test_not_found_response_contains_message(self, db_path, registered_product):
        unknown = dict(registered_product)
        unknown["product_id"] = "e" * 32
        sig = sig_svc.sign_payload(unknown)
        payload_b64 = _make_payload_b64(unknown, sig)
        result = verification_service.verify_product(db_path, payload_b64, "1.2.3.4")
        assert "message" in result
        assert len(result["message"]) > 0


# ---------------------------------------------------------------------------
# Scan event persistence (Requirement 5.5)
# ---------------------------------------------------------------------------

class TestScanEventPersistence:
    def test_every_verification_records_scan_event(self, db_path, registered_product):
        """Requirement 5.5: every verification attempt must produce a scan_event."""
        pid = registered_product["product_id"]
        payload_b64 = _make_payload_b64(
            registered_product, registered_product["qr_payload_hash"]
        )
        for _ in range(3):
            verification_service.verify_product(db_path, payload_b64, "2.2.2.2")

        db = get_db(db_path)
        count = db.execute(
            "SELECT COUNT(*) FROM scan_events WHERE product_id = ?", (pid,)
        ).fetchone()[0]
        db.close()
        assert count == 3