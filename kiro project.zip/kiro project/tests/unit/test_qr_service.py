﻿"""
tests/unit/test_qr_service.py
Unit tests for services/qr_service.py.

Tasks covered: 8.2 (Property 6: QR idempotency), 8.3 (unit tests)
Requirements:  4.1, 4.3, 4.4, 4.5, 4.6
"""

from __future__ import annotations

import base64
import io
import json
import os
import tempfile

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from hypothesis import given, settings
from hypothesis import strategies as st
from PIL import Image

from trust_trace.database import get_db, init_db, apply_migrations
from trust_trace.services import qr_service, product_service
import trust_trace.services.signature_service as sig_svc


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    path = str(tmp_path / "qr_test.db")
    init_db(path)
    apply_migrations(path)
    return path


@pytest.fixture()
def key_path(tmp_path):
    """Load a fresh P-256 key into signature_service; yield path."""
    sig_svc.reset_keys()
    path = str(tmp_path / "qr_test.pem")
    pk = ec.generate_private_key(ec.SECP256R1())
    pem = pk.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(path, "wb") as fh:
        fh.write(pem)
    sig_svc.load_private_key(path)
    yield path
    sig_svc.reset_keys()


@pytest.fixture()
def mfg_id(db_path):
    import flask_bcrypt as _bcrypt
    hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
    db = get_db(db_path)
    db.execute(
        "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
        ("qrmfg@example.com", "QR Corp", hashed),
    )
    db.commit()
    row = db.execute("SELECT id FROM manufacturers WHERE email = ?",
                     ("qrmfg@example.com",)).fetchone()
    db.close()
    return row["id"]


@pytest.fixture()
def registered_product(db_path, mfg_id, key_path):
    """Register a product (key loaded) and return the registration result dict."""
    result = product_service.register_product(
        db_path, mfg_id,
        name="QR Widget", category="Electronics",
        serial_number="SN-QR-001", brand="Acme", model="QR-100",
    )
    assert result["ok"] is True
    return result


# ---------------------------------------------------------------------------
# Helper: decode the URL embedded in a QR PNG
# ---------------------------------------------------------------------------

def _decode_qr_url(png_bytes: bytes) -> str:
    """Decode the URL from a QR code PNG using pyzbar or a fallback method."""
    try:
        from pyzbar import pyzbar
        img = Image.open(io.BytesIO(png_bytes))
        decoded = pyzbar.decode(img)
        if decoded:
            return decoded[0].data.decode("utf-8")
    except ImportError:
        pass  # pyzbar not installed — fall back to content inspection below
    # Fallback: we cannot decode the QR pixel data without pyzbar, so skip
    return ""


# ---------------------------------------------------------------------------
# 8.3 Unit tests -- PNG generation
# ---------------------------------------------------------------------------

class TestGenerateQrPng:
    def test_returns_png_bytes(self, db_path, mfg_id, registered_product):
        pid = registered_product["product_id"]
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        assert png is not None
        assert isinstance(png, bytes)
        assert len(png) > 0

    def test_bytes_are_valid_png(self, db_path, mfg_id, registered_product):
        pid = registered_product["product_id"]
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        # PNG magic bytes: \x89PNG\r\n\x1a\n
        assert png[:8] == b"\x89PNG\r\n\x1a\n"

    def test_png_minimum_300x300(self, db_path, mfg_id, registered_product):
        """Requirement 4.3: PNG must be at least 300x300 pixels."""
        pid = registered_product["product_id"]
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        img = Image.open(io.BytesIO(png))
        w, h = img.size
        assert w >= 300, f"PNG width {w} < 300"
        assert h >= 300, f"PNG height {h} < 300"

    def test_png_is_square(self, db_path, mfg_id, registered_product):
        pid = registered_product["product_id"]
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        img = Image.open(io.BytesIO(png))
        assert img.size[0] == img.size[1], "QR PNG should be square"


class TestQrUrlContent:
    def _get_stored_sig_and_product(self, db_path, product_id):
        db = get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?",
                         (product_id,)).fetchone()
        db.close()
        return dict(row)

    def test_verification_url_contains_product_id(self, db_path, mfg_id, registered_product):
        """The URL payload must embed the product_id (Requirement 4.1)."""
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="testhost")
        assert "payload=" in url
        # Decode payload
        b64 = url.split("payload=")[1]
        padded = b64 + "=" * (4 - len(b64) % 4 if len(b64) % 4 else 0)
        decoded = json.loads(base64.urlsafe_b64decode(padded).decode())
        assert decoded["product_id"] == pid

    def test_verification_url_contains_signature(self, db_path, mfg_id, registered_product):
        """The URL must carry the signature (public proof), not the private key."""
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="testhost")
        b64 = url.split("payload=")[1]
        padded = b64 + "=" * (4 - len(b64) % 4 if len(b64) % 4 else 0)
        decoded = json.loads(base64.urlsafe_b64decode(padded).decode())
        assert "sig" in decoded
        assert decoded["sig"] == sig

    def test_verification_url_does_not_contain_private_key(self, db_path, mfg_id, registered_product, key_path):
        """Requirement 4.4: the private key PEM must never appear in the URL."""
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="testhost")
        with open(key_path, "r") as fh:
            private_pem = fh.read()
        # The raw PEM content must not be in the URL
        assert "BEGIN PRIVATE KEY" not in url
        assert private_pem.strip() not in url

    def test_payload_does_not_contain_password_hash(self, db_path, mfg_id, registered_product):
        """Sensitive manufacturer data (password_hash) must not leak into QR."""
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="testhost")
        assert "password_hash" not in url
        assert "password" not in url

    def test_url_uses_verify_path(self, db_path, mfg_id, registered_product):
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="example.com")
        assert "/verify?payload=" in url

    def test_payload_signature_verifiable(self, db_path, mfg_id, registered_product):
        """The signature embedded in the URL must verify against the payload fields."""
        pid = registered_product["product_id"]
        product = self._get_stored_sig_and_product(db_path, pid)
        sig = product["qr_payload_hash"]
        url = qr_service._build_verification_url(product, sig, host="testhost")
        b64 = url.split("payload=")[1]
        padded = b64 + "=" * (4 - len(b64) % 4 if len(b64) % 4 else 0)
        decoded = json.loads(base64.urlsafe_b64decode(padded).decode())
        assert sig_svc.verify_payload(decoded, decoded["sig"]) is True


class TestQrOwnershipAndErrors:
    def test_wrong_manufacturer_returns_none(self, db_path, mfg_id, registered_product):
        """Requirement 4.5: product not owned by caller returns None."""
        pid = registered_product["product_id"]
        result = qr_service.get_or_create_qr(db_path, pid, manufacturer_id=9999)
        assert result is None

    def test_nonexistent_product_returns_none(self, db_path, mfg_id):
        result = qr_service.get_or_create_qr(db_path, "nonexistentproductid00000000000000", mfg_id)
        assert result is None

    def test_no_key_loaded_returns_none(self, db_path, mfg_id):
        """When key is not loaded and no stored signature, None is returned."""
        sig_svc.reset_keys()
        # Register without key so qr_payload_hash is NULL
        result = product_service.register_product(
            db_path, mfg_id,
            name="No Key Widget", category="Cat", serial_number="SN-NOKEY-001"
        )
        pid = result["product_id"]
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        assert png is None

    def test_late_sign_when_key_loaded_after_registration(self, db_path, mfg_id, key_path):
        """If qr_payload_hash is NULL but key is now loaded, get_or_create_qr
        signs on-the-fly and returns valid PNG bytes."""
        # Register with key already loaded (key_path fixture loads it)
        # Force a NULL signature by directly clearing it after registration
        result = product_service.register_product(
            db_path, mfg_id,
            name="Late Sign Widget", category="Cat", serial_number="SN-LATE-001"
        )
        pid = result["product_id"]
        # Clear the stored signature to simulate "registered before key was loaded"
        db = get_db(db_path)
        db.execute("UPDATE products SET qr_payload_hash = NULL WHERE product_id = ?", (pid,))
        db.commit()
        db.close()

        # Now request QR — key IS loaded, so it should sign on-the-fly
        png = qr_service.get_or_create_qr(db_path, pid, mfg_id)
        assert png is not None
        assert png[:8] == b"\x89PNG\r\n\x1a\n"


# ---------------------------------------------------------------------------
# Task 8.2 -- Property 6: QR Code Idempotency
# Feature: trust-trace, Property 6: QR Code Idempotency
# Validates: Requirements 4.6
# ---------------------------------------------------------------------------

def _make_signed_product(db_path: str, mfg_id: int, serial_suffix: str) -> str:
    """Register a product with the key already loaded; return product_id."""
    result = product_service.register_product(
        db_path, mfg_id,
        name=f"Idem Widget {serial_suffix}",
        category="Electronics",
        serial_number=f"SN-IDEM-{serial_suffix}",
    )
    assert result["ok"] is True
    return result["product_id"]


@given(call_count=st.integers(min_value=2, max_value=5))
@settings(max_examples=30, deadline=None)
def test_property6_qr_idempotency(call_count):
    """Feature: trust-trace, Property 6: QR Code Idempotency.

    For any product that already has qr_payload_hash set, calling
    get_or_create_qr multiple times must return the same PNG bytes
    (same payload, same signature — Requirement 4.6).
    """
    tmp_dir = tempfile.mkdtemp()
    db_path = os.path.join(tmp_dir, "idem.db")
    key_path = os.path.join(tmp_dir, "idem.pem")
    try:
        init_db(db_path)
        apply_migrations(db_path)

        # Generate and load a key
        sig_svc.reset_keys()
        pk = ec.generate_private_key(ec.SECP256R1())
        pem = pk.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        with open(key_path, "wb") as fh:
            fh.write(pem)
        sig_svc.load_private_key(key_path)

        # Create manufacturer
        import flask_bcrypt as _bcrypt
        hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
        db = get_db(db_path)
        db.execute(
            "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
            ("idem@example.com", "Idem Corp", hashed),
        )
        db.commit()
        mfg_id = db.execute(
            "SELECT id FROM manufacturers WHERE email = ?", ("idem@example.com",)
        ).fetchone()["id"]
        db.close()

        pid = _make_signed_product(db_path, mfg_id, f"{call_count}")

        # Verify the stored signature before calling get_or_create_qr
        db = get_db(db_path)
        row = db.execute("SELECT qr_payload_hash FROM products WHERE product_id = ?",
                         (pid,)).fetchone()
        db.close()
        assert row["qr_payload_hash"] is not None, "Pre-condition: signature must be stored"

        # Call get_or_create_qr multiple times and verify PNG content is stable
        results = [qr_service.get_or_create_qr(db_path, pid, mfg_id) for _ in range(call_count)]
        assert all(r is not None for r in results), "All calls must return PNG bytes"

        # All returned PNGs must be identical (same URL → same QR)
        assert len(set(results)) == 1, \
            f"Expected identical PNGs on {call_count} calls; got {len(set(results))} distinct results"

    finally:
        sig_svc.reset_keys()
        try:
            for f in [db_path, key_path]:
                if os.path.exists(f):
                    os.unlink(f)
            os.rmdir(tmp_dir)
        except OSError:
            pass