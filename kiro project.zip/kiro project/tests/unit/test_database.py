﻿"""
tests/unit/test_database.py -- Unit tests for database.py (Tasks 2.1, 2.2).

Tests verify:
- All six tables are created by init_db().
- All four indexes are created.
- Foreign-key enforcement is active on every connection.
- CHECK constraints on scan_events.outcome are enforced.
- CHECK constraints on suspicious_activity_alerts.alert_type are enforced.
- The UNIQUE constraint on (manufacturer_id, serial_number) is enforced.
- init_db() is idempotent (safe to call twice).
"""

import sqlite3
import pytest

from trust_trace.database import get_db, init_db


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _table_names(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    ).fetchall()
    return {row[0] for row in rows}


def _index_names(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'index'"
    ).fetchall()
    return {row[0] for row in rows}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_conn():
    """Return a fresh in-memory connection with the schema applied."""
    init_db(":memory:")
    conn = get_db(":memory:")
    init_db(":memory:")   # Ensure helper works standalone too
    # Use a fresh single connection for assertions
    c = get_db(":memory:")
    from trust_trace.database import _SCHEMA_SQL
    c.executescript(_SCHEMA_SQL)
    yield c
    c.close()


# ---------------------------------------------------------------------------
# Table existence
# ---------------------------------------------------------------------------

class TestTablesCreated:
    EXPECTED_TABLES = {
        "manufacturers",
        "sessions",
        "login_attempts",
        "products",
        "scan_events",
        "suspicious_activity_alerts",
    }

    def test_all_tables_exist(self, db_conn):
        assert self.EXPECTED_TABLES.issubset(_table_names(db_conn))


# ---------------------------------------------------------------------------
# Index existence
# ---------------------------------------------------------------------------

class TestIndexesCreated:
    EXPECTED_INDEXES = {
        "idx_sessions_token",
        "idx_login_attempts_email",
        "idx_scan_events_product",
        "idx_products_manufacturer",
    }

    def test_all_indexes_exist(self, db_conn):
        assert self.EXPECTED_INDEXES.issubset(_index_names(db_conn))


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------

class TestIdempotency:
    def test_init_db_twice_does_not_raise(self):
        """init_db() uses IF NOT EXISTS so calling it twice must not raise."""
        conn = get_db(":memory:")
        from trust_trace.database import _SCHEMA_SQL
        conn.executescript(_SCHEMA_SQL)
        # Second call -- should be a no-op
        conn.executescript(_SCHEMA_SQL)
        conn.close()


# ---------------------------------------------------------------------------
# PRAGMA foreign_keys
# ---------------------------------------------------------------------------

class TestForeignKeys:
    def test_foreign_key_violation_raises(self, db_conn):
        """Inserting a session for a non-existent manufacturer must fail."""
        with pytest.raises(sqlite3.IntegrityError):
            db_conn.execute(
                "INSERT INTO sessions (token, manufacturer_id, created_at, last_active) "
                "VALUES (?, ?, datetime('now'), datetime('now'))",
                ("tok-abc", 9999),
            )
            db_conn.commit()


# ---------------------------------------------------------------------------
# CHECK constraints
# ---------------------------------------------------------------------------

class TestCheckConstraints:
    def _insert_manufacturer(self, conn) -> int:
        conn.execute(
            "INSERT INTO manufacturers (email, display_name, password_hash) "
            "VALUES (?, ?, ?)",
            ("mfg@example.com", "Acme", "hash"),
        )
        conn.commit()
        row = conn.execute("SELECT id FROM manufacturers WHERE email = ?", ("mfg@example.com",)).fetchone()
        return row[0]

    def _insert_product(self, conn, mfg_id: int) -> str:
        product_id = "a" * 32
        conn.execute(
            "INSERT INTO products (product_id, manufacturer_id, name, category, serial_number, registered_at) "
            "VALUES (?, ?, ?, ?, ?, datetime('now'))",
            (product_id, mfg_id, "Widget", "Electronics", "SN-001"),
        )
        conn.commit()
        return product_id

    def test_scan_event_invalid_outcome_raises(self, db_conn):
        mfg_id = self._insert_manufacturer(db_conn)
        product_id = self._insert_product(db_conn, mfg_id)
        with pytest.raises(sqlite3.IntegrityError):
            db_conn.execute(
                "INSERT INTO scan_events (product_id, ip_address, outcome, occurred_at) "
                "VALUES (?, ?, ?, datetime('now'))",
                (product_id, "1.2.3.4", "BOGUS"),
            )
            db_conn.commit()

    def test_scan_event_valid_outcomes_accepted(self, db_conn):
        mfg_id = self._insert_manufacturer(db_conn)
        product_id = self._insert_product(db_conn, mfg_id)
        for outcome in ("authentic", "invalid", "not_found"):
            db_conn.execute(
                "INSERT INTO scan_events (product_id, ip_address, outcome, occurred_at) "
                "VALUES (?, ?, ?, datetime('now'))",
                (product_id, "1.2.3.4", outcome),
            )
        db_conn.commit()

    def test_alert_invalid_type_raises(self, db_conn):
        mfg_id = self._insert_manufacturer(db_conn)
        product_id = self._insert_product(db_conn, mfg_id)
        with pytest.raises(sqlite3.IntegrityError):
            db_conn.execute(
                "INSERT INTO suspicious_activity_alerts "
                "(product_id, alert_type, detected_at, scan_count, ip_addresses) "
                "VALUES (?, ?, datetime('now'), ?, ?)",
                (product_id, "INVALID_TYPE", 15, '["1.2.3.4"]'),
            )
            db_conn.commit()

    def test_alert_valid_types_accepted(self, db_conn):
        mfg_id = self._insert_manufacturer(db_conn)
        product_id = self._insert_product(db_conn, mfg_id)
        for alert_type in ("volume", "geo_distribution"):
            db_conn.execute(
                "INSERT INTO suspicious_activity_alerts "
                "(product_id, alert_type, detected_at, scan_count, ip_addresses) "
                "VALUES (?, ?, datetime('now'), ?, ?)",
                (product_id, alert_type, 15, '["1.2.3.4"]'),
            )
        db_conn.commit()


# ---------------------------------------------------------------------------
# UNIQUE constraint
# ---------------------------------------------------------------------------

class TestUniqueConstraints:
    def test_duplicate_serial_number_per_manufacturer_raises(self, db_conn):
        db_conn.execute(
            "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
            ("mfg2@example.com", "Beta Corp", "hash2"),
        )
        db_conn.commit()
        mfg_id = db_conn.execute(
            "SELECT id FROM manufacturers WHERE email = ?", ("mfg2@example.com",)
        ).fetchone()[0]

        db_conn.execute(
            "INSERT INTO products (product_id, manufacturer_id, name, category, serial_number, registered_at) "
            "VALUES (?, ?, ?, ?, ?, datetime('now'))",
            ("b" * 32, mfg_id, "Gadget", "Tech", "SN-DUP"),
        )
        db_conn.commit()

        with pytest.raises(sqlite3.IntegrityError):
            db_conn.execute(
                "INSERT INTO products (product_id, manufacturer_id, name, category, serial_number, registered_at) "
                "VALUES (?, ?, ?, ?, ?, datetime('now'))",
                ("c" * 32, mfg_id, "Gadget2", "Tech", "SN-DUP"),  # Same serial, same manufacturer
            )
            db_conn.commit()

    def test_same_serial_number_different_manufacturer_allowed(self, db_conn):
        for i, email in enumerate(["mfg3@example.com", "mfg4@example.com"]):
            db_conn.execute(
                "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
                (email, f"Corp {i}", "hash"),
            )
        db_conn.commit()

        mfg_ids = [
            db_conn.execute("SELECT id FROM manufacturers WHERE email = ?", (e,)).fetchone()[0]
            for e in ["mfg3@example.com", "mfg4@example.com"]
        ]

        for j, mfg_id in enumerate(mfg_ids):
            db_conn.execute(
                "INSERT INTO products (product_id, manufacturer_id, name, category, serial_number, registered_at) "
                "VALUES (?, ?, ?, ?, ?, datetime('now'))",
                ("d" * 31 + str(j), mfg_id, "Item", "Cat", "SN-SHARED"),
            )
        db_conn.commit()   # Must NOT raise