﻿"""
tests/unit/test_scan_monitor.py
Unit tests for services/scan_monitor.py.

Tasks covered: 9.2 (Property 7), 9.3 (Property 8), 9.4 (Property 9), 9.5
Requirements:  5.5, 6.1-6.4
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timedelta, timezone

import flask_bcrypt as _bcrypt
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from trust_trace.database import apply_migrations, get_db, init_db
from trust_trace.services import scan_monitor


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    path = str(tmp_path / "scan_test.db")
    init_db(path)
    apply_migrations(path)
    return path


@pytest.fixture()
def product_id(db_path):
    """Insert a manufacturer + product and return the product_id."""
    hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
    db = get_db(db_path)
    db.execute(
        "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
        ("scan@example.com", "Scan Corp", hashed),
    )
    db.commit()
    mfg_id = db.execute(
        "SELECT id FROM manufacturers WHERE email = ?", ("scan@example.com",)
    ).fetchone()["id"]
    pid = "a" * 32
    db.execute(
        "INSERT INTO products "
        "(product_id, manufacturer_id, name, category, serial_number, registered_at) "
        "VALUES (?, ?, ?, ?, ?, datetime('now'))",
        (pid, mfg_id, "Test Widget", "Electronics", "SN-SCAN-001"),
    )
    db.commit()
    db.close()
    return pid


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Task 9.5 -- Unit tests: record_scan_event
# ---------------------------------------------------------------------------

class TestRecordScanEvent:
    def test_inserts_row_into_scan_events(self, db_path, product_id):
        scan_monitor.record_scan_event(db_path, product_id, "1.2.3.4", "authentic")
        db = get_db(db_path)
        row = db.execute("SELECT * FROM scan_events WHERE product_id = ?", (product_id,)).fetchone()
        db.close()
        assert row is not None
        assert row["outcome"] == "authentic"
        assert row["ip_address"] == "1.2.3.4"

    def test_empty_ip_stored_as_unavailable(self, db_path, product_id):
        scan_monitor.record_scan_event(db_path, product_id, "", "invalid")
        db = get_db(db_path)
        row = db.execute("SELECT ip_address FROM scan_events WHERE product_id = ?",
                         (product_id,)).fetchone()
        db.close()
        assert row["ip_address"] == "unavailable"

    def test_none_ip_stored_as_unavailable(self, db_path, product_id):
        scan_monitor.record_scan_event(db_path, product_id, None, "not_found")
        db = get_db(db_path)
        row = db.execute("SELECT ip_address FROM scan_events WHERE product_id = ?",
                         (product_id,)).fetchone()
        db.close()
        assert row["ip_address"] == "unavailable"

    def test_all_valid_outcomes_accepted(self, db_path, product_id):
        for outcome in ("authentic", "invalid", "not_found"):
            scan_monitor.record_scan_event(db_path, product_id, "1.2.3.4", outcome)
        db = get_db(db_path)
        count = db.execute("SELECT COUNT(*) FROM scan_events WHERE product_id = ?",
                            (product_id,)).fetchone()[0]
        db.close()
        assert count == 3

    def test_custom_timestamp_stored(self, db_path, product_id):
        ts = datetime(2024, 6, 1, 12, 0, 0, tzinfo=timezone.utc)
        scan_monitor.record_scan_event(db_path, product_id, "5.5.5.5", "authentic", timestamp=ts)
        db = get_db(db_path)
        row = db.execute("SELECT occurred_at FROM scan_events WHERE product_id = ?",
                         (product_id,)).fetchone()
        db.close()
        assert "2024-06-01" in row["occurred_at"]


# ---------------------------------------------------------------------------
# Task 9.5 -- Unit tests: check_for_alerts volume
# ---------------------------------------------------------------------------

class TestVolumeAlerts:
    def _add_scans(self, db_path, product_id, count: int, ip: str = "1.2.3.4"):
        for _ in range(count):
            scan_monitor.record_scan_event(db_path, product_id, ip, "authentic")

    def test_exactly_10_scans_no_volume_alert(self, db_path, product_id):
        self._add_scans(db_path, product_id, 10)
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        volume_alerts = [a for a in alerts if a["alert_type"] == "volume"]
        assert len(volume_alerts) == 0

    def test_11_scans_triggers_volume_alert(self, db_path, product_id):
        self._add_scans(db_path, product_id, 11)
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        volume_alerts = [a for a in alerts if a["alert_type"] == "volume"]
        assert len(volume_alerts) == 1

    def test_volume_alert_contains_required_fields(self, db_path, product_id):
        self._add_scans(db_path, product_id, 11)
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        alert = next(a for a in alerts if a["alert_type"] == "volume")
        assert alert["product_id"] == product_id
        assert alert["alert_type"] == "volume"
        assert alert["detected_at"]
        assert alert["scan_count"] == 11
        ips = json.loads(alert["ip_addresses"])
        assert isinstance(ips, list)

    def test_duplicate_volume_alert_not_created(self, db_path, product_id):
        """Only one unresolved volume alert per product per window."""
        self._add_scans(db_path, product_id, 12)
        scan_monitor.check_for_alerts(db_path, product_id)
        self._add_scans(db_path, product_id, 3)
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        volume_alerts = [a for a in alerts if a["alert_type"] == "volume"]
        assert len(volume_alerts) == 1

    def test_alert_does_not_mark_product_counterfeit(self, db_path, product_id):
        """Requirement 6.2: alerts must never add a 'counterfeit' flag to the product."""
        self._add_scans(db_path, product_id, 15)
        scan_monitor.check_for_alerts(db_path, product_id)
        db = get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?", (product_id,)).fetchone()
        db.close()
        product_dict = dict(row)
        for key in product_dict:
            assert "counterfeit" not in str(key).lower(), f"Column '{key}' suggests counterfeit marking"


# ---------------------------------------------------------------------------
# Task 9.5 -- Unit tests: check_for_alerts geo-distribution
# ---------------------------------------------------------------------------

class TestGeoDistributionAlerts:
    def test_exactly_5_ips_no_geo_alert(self, db_path, product_id):
        for i in range(1, 6):
            scan_monitor.record_scan_event(db_path, product_id, f"10.0.0.{i}", "authentic")
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        geo_alerts = [a for a in alerts if a["alert_type"] == "geo_distribution"]
        assert len(geo_alerts) == 0

    def test_6_distinct_ips_triggers_geo_alert(self, db_path, product_id):
        for i in range(1, 7):
            scan_monitor.record_scan_event(db_path, product_id, f"10.0.0.{i}", "authentic")
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        geo_alerts = [a for a in alerts if a["alert_type"] == "geo_distribution"]
        assert len(geo_alerts) == 1

    def test_geo_alert_ip_addresses_is_json_array(self, db_path, product_id):
        for i in range(1, 7):
            scan_monitor.record_scan_event(db_path, product_id, f"10.0.0.{i}", "authentic")
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        geo = next(a for a in alerts if a["alert_type"] == "geo_distribution")
        parsed = json.loads(geo["ip_addresses"])
        assert isinstance(parsed, list)
        assert len(parsed) == 6

    def test_duplicate_geo_alert_not_created(self, db_path, product_id):
        for i in range(1, 8):
            scan_monitor.record_scan_event(db_path, product_id, f"10.0.0.{i}", "authentic")
        scan_monitor.check_for_alerts(db_path, product_id)
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        geo_alerts = [a for a in alerts if a["alert_type"] == "geo_distribution"]
        assert len(geo_alerts) == 1

    def test_unavailable_ips_not_counted_in_geo(self, db_path, product_id):
        """'unavailable' IP should not count toward distinct IP threshold."""
        for _ in range(6):
            scan_monitor.record_scan_event(db_path, product_id, "unavailable", "authentic")
        scan_monitor.check_for_alerts(db_path, product_id)
        alerts = scan_monitor.get_alerts_for_product(db_path, product_id)
        geo_alerts = [a for a in alerts if a["alert_type"] == "geo_distribution"]
        assert len(geo_alerts) == 0


# ---------------------------------------------------------------------------
# Task 9.2 -- Property 7: Volume Alert Threshold
# Feature: trust-trace, Property 7: Volume Alert Threshold
# Validates: Requirements 6.1
# ---------------------------------------------------------------------------

def _setup_db_with_product(tmp_dir: str) -> tuple[str, str]:
    """Create a fresh DB with one manufacturer and product. Return (db_path, product_id)."""
    db_path = os.path.join(tmp_dir, "prop.db")
    init_db(db_path)
    apply_migrations(db_path)
    hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
    db = get_db(db_path)
    db.execute(
        "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
        ("prop@example.com", "Corp", hashed),
    )
    db.commit()
    mfg_id = db.execute(
        "SELECT id FROM manufacturers WHERE email = ?", ("prop@example.com",)
    ).fetchone()["id"]
    pid = "b" * 32
    db.execute(
        "INSERT INTO products "
        "(product_id, manufacturer_id, name, category, serial_number, registered_at) "
        "VALUES (?, ?, ?, ?, ?, datetime('now'))",
        (pid, mfg_id, "Prop Widget", "Cat", "SN-PROP"),
    )
    db.commit()
    db.close()
    return db_path, pid


@given(scan_count=st.integers(min_value=11, max_value=50))
@settings(max_examples=30, deadline=None)
def test_property7_volume_alert_threshold(scan_count):
    # Feature: trust-trace, Property 7: Volume Alert Threshold
    """For any product_id with >10 scans in a 60-min window, check_for_alerts
    must create a volume alert."""
    tmp_dir = tempfile.mkdtemp()
    try:
        db_path, pid = _setup_db_with_product(tmp_dir)
        for _ in range(scan_count):
            scan_monitor.record_scan_event(db_path, pid, "1.2.3.4", "authentic")
        scan_monitor.check_for_alerts(db_path, pid)
        alerts = scan_monitor.get_alerts_for_product(db_path, pid)
        volume_alerts = [a for a in alerts if a["alert_type"] == "volume"]
        assert len(volume_alerts) >= 1, \
            f"Expected >=1 volume alert for {scan_count} scans, got {len(volume_alerts)}"
    finally:
        try:
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Task 9.3 -- Property 8: Geographic Distribution Alert Threshold
# Feature: trust-trace, Property 8: Geographic Distribution Alert Threshold
# Validates: Requirements 6.3
# ---------------------------------------------------------------------------

@given(extra_ips=st.integers(min_value=1, max_value=20))
@settings(max_examples=30, deadline=None)
def test_property8_geo_distribution_alert_threshold(extra_ips):
    # Feature: trust-trace, Property 8: Geographic Distribution Alert Threshold
    """For any product_id with >5 distinct IPs in a 60-min window,
    check_for_alerts must create a geo_distribution alert."""
    total_ips = 5 + extra_ips   # always >5
    tmp_dir = tempfile.mkdtemp()
    try:
        db_path, pid = _setup_db_with_product(tmp_dir)
        for i in range(total_ips):
            scan_monitor.record_scan_event(db_path, pid, f"10.0.{i // 256}.{i % 256}", "authentic")
        scan_monitor.check_for_alerts(db_path, pid)
        alerts = scan_monitor.get_alerts_for_product(db_path, pid)
        geo_alerts = [a for a in alerts if a["alert_type"] == "geo_distribution"]
        assert len(geo_alerts) >= 1, \
            f"Expected >=1 geo alert for {total_ips} distinct IPs, got {len(geo_alerts)}"
    finally:
        try:
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Task 9.4 -- Property 9: Scan Event Persistence Round-Trip
# Feature: trust-trace, Property 9: Scan Event Persistence Round-Trip
# Validates: Requirements 5.5
# ---------------------------------------------------------------------------

_ip_strategy = st.from_regex(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", fullmatch=True)
_outcome_strategy = st.sampled_from(["authentic", "invalid", "not_found"])


@given(ip=_ip_strategy, outcome=_outcome_strategy)
@settings(max_examples=50, deadline=None)
def test_property9_scan_event_persistence_round_trip(ip, outcome):
    # Feature: trust-trace, Property 9: Scan Event Persistence Round-Trip
    """After record_scan_event, querying scan_events must include a record
    matching all recorded fields."""
    tmp_dir = tempfile.mkdtemp()
    try:
        db_path, pid = _setup_db_with_product(tmp_dir)
        scan_monitor.record_scan_event(db_path, pid, ip, outcome)
        db = get_db(db_path)
        rows = db.execute(
            "SELECT * FROM scan_events WHERE product_id = ?", (pid,)
        ).fetchall()
        db.close()
        assert len(rows) >= 1
        last = rows[-1]
        assert last["product_id"] == pid
        assert last["ip_address"] == ip
        assert last["outcome"] == outcome
    finally:
        try:
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass