﻿"""
tests/unit/test_product_service.py
Unit tests for services/product_service.py.

Tasks covered: 6.2 (Property 5), 6.3 (unit tests)
Requirements:  3.1-3.6, 11.1, 4.2
"""

from __future__ import annotations

import os
import tempfile

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from hypothesis import given, settings
from hypothesis import strategies as st

from trust_trace.database import get_db, init_db
from trust_trace.services import product_service
import trust_trace.services.signature_service as sig_svc


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    """Fresh file-based SQLite DB with schema applied."""
    path = str(tmp_path / "test_products.db")
    init_db(path)
    # Apply migrations to add brand/model columns
    from trust_trace.database import apply_migrations
    apply_migrations(path)
    return path


@pytest.fixture()
def mfg_id(db_path):
    """Insert a test manufacturer and return its id."""
    import flask_bcrypt as _bcrypt
    hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
    db = get_db(db_path)
    db.execute(
        "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
        ("mfg@example.com", "Test Corp", hashed),
    )
    db.commit()
    row = db.execute("SELECT id FROM manufacturers WHERE email = ?", ("mfg@example.com",)).fetchone()
    db.close()
    return row["id"]


@pytest.fixture()
def key_path(tmp_path):
    """Write a fresh P-256 key; load it into signature_service; yield path."""
    sig_svc.reset_keys()
    path = str(tmp_path / "test.pem")
    pk = ec.generate_private_key(ec.SECP256R1())
    pem = pk.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(path, "wb") as fh:
        fh.write(pem)
    sig_svc.load_private_key(path)
    yield path
    sig_svc.reset_keys()


def _reg(db_path, mfg_id, **kwargs):
    """Convenience wrapper with sensible defaults."""
    defaults = dict(
        name="Widget Pro",
        category="Electronics",
        serial_number="SN-001",
        brand="Acme",
        model="WP-100",
    )
    defaults.update(kwargs)
    return product_service.register_product(db_path, mfg_id, **defaults)


# ---------------------------------------------------------------------------
# 6.3 Unit tests -- successful registration
# ---------------------------------------------------------------------------

class TestRegisterProduct:
    def test_successful_registration_returns_ok(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        assert result["ok"] is True
        assert "product_id" in result
        assert "registered_at" in result

    def test_product_id_is_32_hex_chars(self, db_path, mfg_id):
        """Requirement 3.2: 128-bit CSPRNG -> 32 hex characters."""
        result = _reg(db_path, mfg_id)
        pid = result["product_id"]
        assert len(pid) == 32
        assert all(c in "0123456789abcdef" for c in pid)

    def test_product_ids_are_unique_across_registrations(self, db_path, mfg_id):
        ids = {_reg(db_path, mfg_id, serial_number=f"SN-{i}")["product_id"] for i in range(20)}
        assert len(ids) == 20   # all unique

    def test_product_persisted_in_db(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()
        assert row is not None
        assert row["name"] == "Widget Pro"
        assert row["category"] == "Electronics"
        assert row["serial_number"] == "SN-001"
        assert row["brand"] == "Acme"
        assert row["model"] == "WP-100"
        assert row["manufacturer_id"] == mfg_id

    def test_registration_timestamp_stored(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT registered_at FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()
        assert row["registered_at"] == result["registered_at"]

    def test_brand_and_model_optional(self, db_path, mfg_id):
        result = product_service.register_product(
            db_path, mfg_id,
            name="Plain Product", category="General", serial_number="SN-PLAIN"
        )
        assert result["ok"] is True
        db = get_db(db_path)
        row = db.execute("SELECT brand, model FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()
        assert row["brand"] is None
        assert row["model"] is None

    def test_product_associated_with_manufacturer(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        product = product_service.get_product(db_path, result["product_id"],
                                              manufacturer_id=mfg_id)
        assert product is not None
        assert product["manufacturer_id"] == mfg_id


# ---------------------------------------------------------------------------
# 6.3 Unit tests -- validation errors
# ---------------------------------------------------------------------------

class TestProductValidation:
    def test_missing_name_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, name="")
        assert result["ok"] is False
        assert result["field"] == "name"

    def test_missing_category_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, category="")
        assert result["ok"] is False
        assert result["field"] == "category"

    def test_missing_serial_number_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, serial_number="")
        assert result["ok"] is False
        assert result["field"] == "serial_number"

    def test_name_over_255_chars_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, name="A" * 256)
        assert result["ok"] is False
        assert result["error"] == "field_too_long"
        assert result["field"] == "name"

    def test_category_over_255_chars_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, category="C" * 256)
        assert result["ok"] is False
        assert result["error"] == "field_too_long"

    def test_serial_over_255_chars_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, serial_number="S" * 256)
        assert result["ok"] is False
        assert result["error"] == "field_too_long"

    def test_brand_over_255_chars_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, brand="B" * 256)
        assert result["ok"] is False
        assert result["field"] == "brand"

    def test_model_over_255_chars_returns_error(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id, model="M" * 256)
        assert result["ok"] is False
        assert result["field"] == "model"


# ---------------------------------------------------------------------------
# 6.3 Unit tests -- duplicate serial number (Requirement 3.3)
# ---------------------------------------------------------------------------

class TestDuplicateSerialNumber:
    def test_duplicate_serial_same_manufacturer_returns_error(self, db_path, mfg_id):
        _reg(db_path, mfg_id, serial_number="DUP-001")
        result = _reg(db_path, mfg_id, serial_number="DUP-001")
        assert result["ok"] is False
        assert result["error"] == "duplicate_serial_number"
        assert result["field"] == "serial_number"

    def test_same_serial_different_manufacturer_allowed(self, db_path):
        """Requirement 3.3: uniqueness is per-manufacturer, not global."""
        import flask_bcrypt as _bcrypt
        hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
        db = get_db(db_path)
        for email in ("mfgA@example.com", "mfgB@example.com"):
            db.execute(
                "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
                (email, "Corp", hashed),
            )
        db.commit()
        ids = [db.execute("SELECT id FROM manufacturers WHERE email = ?", (e,)).fetchone()["id"]
               for e in ("mfgA@example.com", "mfgB@example.com")]
        db.close()

        r1 = _reg(db_path, ids[0], serial_number="SHARED-SN")
        r2 = _reg(db_path, ids[1], serial_number="SHARED-SN")
        assert r1["ok"] is True
        assert r2["ok"] is True


# ---------------------------------------------------------------------------
# 6.3 Unit tests -- get_product and list_products
# ---------------------------------------------------------------------------

class TestGetAndListProducts:
    def test_get_product_returns_correct_record(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        product = product_service.get_product(db_path, result["product_id"])
        assert product is not None
        assert product["product_id"] == result["product_id"]

    def test_get_product_with_wrong_manufacturer_returns_none(self, db_path, mfg_id):
        result = _reg(db_path, mfg_id)
        product = product_service.get_product(db_path, result["product_id"],
                                              manufacturer_id=9999)
        assert product is None

    def test_get_nonexistent_product_returns_none(self, db_path, mfg_id):
        assert product_service.get_product(db_path, "nonexistent") is None

    def test_list_products_returns_all_for_manufacturer(self, db_path, mfg_id):
        for i in range(3):
            _reg(db_path, mfg_id, serial_number=f"LIST-{i}")
        products = product_service.list_products(db_path, mfg_id)
        assert len(products) == 3

    def test_list_products_empty_for_unknown_manufacturer(self, db_path):
        products = product_service.list_products(db_path, 9999)
        assert products == []


# ---------------------------------------------------------------------------
# 6.3 Unit tests -- signature stored at registration (Requirement 4.2)
# ---------------------------------------------------------------------------

class TestProductSignature:
    def test_signature_stored_when_key_loaded(self, db_path, mfg_id, key_path):
        """When the private key is loaded, qr_payload_hash holds the ECDSA sig."""
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT qr_payload_hash FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()
        sig = row["qr_payload_hash"]
        assert sig is not None
        # Must be Base64url (no +, /, =)
        assert "+" not in sig
        assert "/" not in sig
        assert "=" not in sig

    def test_stored_signature_verifies_against_product_data(self, db_path, mfg_id, key_path):
        """The stored signature must verify against the canonical product payload."""
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()

        canonical = {
            "product_id": row["product_id"],
            "serial_number": row["serial_number"],
            "name": row["name"],
            "manufacturer_id": row["manufacturer_id"],
            "registered_at": row["registered_at"],
        }
        assert sig_svc.verify_payload(canonical, row["qr_payload_hash"]) is True

    def test_tampered_payload_fails_verification(self, db_path, mfg_id, key_path):
        """A tampered field must cause signature verification to fail."""
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()

        canonical = {
            "product_id": row["product_id"],
            "serial_number": "TAMPERED-SN",   # tampered
            "name": row["name"],
            "manufacturer_id": row["manufacturer_id"],
            "registered_at": row["registered_at"],
        }
        assert sig_svc.verify_payload(canonical, row["qr_payload_hash"]) is False

    def test_signature_none_when_key_not_loaded(self, db_path, mfg_id):
        """When no key is loaded (SKIP_KEY_CHECK tests), signature is stored as None."""
        sig_svc.reset_keys()  # ensure key is not loaded
        result = _reg(db_path, mfg_id)
        db = get_db(db_path)
        row = db.execute("SELECT qr_payload_hash FROM products WHERE product_id = ?",
                         (result["product_id"],)).fetchone()
        db.close()
        assert row["qr_payload_hash"] is None


# ---------------------------------------------------------------------------
# Task 6.2 -- Property 5: Duplicate Serial Number Per Manufacturer Rejected
# Feature: trust-trace, Property 5: Duplicate Serial Number Per Manufacturer Is Rejected
# Validates: Requirements 3.3
# ---------------------------------------------------------------------------

@given(serial=st.text(min_size=1, max_size=50,
                      alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd"),
                                             whitelist_characters="-_.")))
@settings(max_examples=100, deadline=None)
def test_property5_duplicate_serial_number_rejected(serial):
    # Feature: trust-trace, Property 5: Duplicate Serial Number Per Manufacturer Is Rejected
    """For any serial_number already registered under a manufacturer, a second
    registration with the same serial_number must return duplicate_serial_number."""
    tmp_dir = tempfile.mkdtemp()
    db_path = os.path.join(tmp_dir, "prop5.db")
    try:
        init_db(db_path)
        from trust_trace.database import apply_migrations
        apply_migrations(db_path)

        import flask_bcrypt as _bcrypt
        hashed = _bcrypt.generate_password_hash("TestPass123!", rounds=4).decode()
        db = get_db(db_path)
        db.execute(
            "INSERT INTO manufacturers (email, display_name, password_hash) VALUES (?, ?, ?)",
            ("prop5@example.com", "Corp", hashed),
        )
        db.commit()
        mfg_id = db.execute(
            "SELECT id FROM manufacturers WHERE email = ?", ("prop5@example.com",)
        ).fetchone()["id"]
        db.close()

        first = product_service.register_product(
            db_path, mfg_id, name="Widget", category="Cat", serial_number=serial
        )
        if not first["ok"]:
            return  # validation error -- skip this example

        second = product_service.register_product(
            db_path, mfg_id, name="Widget2", category="Cat", serial_number=serial
        )
        assert second["ok"] is False
        assert second["error"] == "duplicate_serial_number"
    finally:
        try:
            os.unlink(db_path)
            os.rmdir(tmp_dir)
        except OSError:
            pass