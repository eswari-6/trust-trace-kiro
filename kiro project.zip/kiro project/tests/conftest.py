﻿"""
tests/conftest.py -- Shared pytest fixtures for the TrustTrace test suite.

Fixtures:
  app      -- Flask test application with in-memory SQLite and SKIP_KEY_CHECK.
  client   -- Flask test client.
  db_path  -- Path to the in-memory DB used by the test app (shared fixture).
"""

from __future__ import annotations

import os
import sys
import tempfile

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

# Ensure the project root is on sys.path when pytest is invoked from any CWD.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from trust_trace.app import create_app
from trust_trace.database import init_db
import trust_trace.services.signature_service as sig_svc


def _write_temp_key(directory: str) -> str:
    """Generate a fresh P-256 key in *directory* and return its path."""
    key_path = os.path.join(directory, "test_private.pem")
    private_key = ec.generate_private_key(ec.SECP256R1())
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(key_path, "wb") as fh:
        fh.write(pem)
    return key_path


@pytest.fixture(scope="session")
def _session_tmp(tmp_path_factory):
    """Session-scoped temp directory for shared resources."""
    return tmp_path_factory.mktemp("session")


@pytest.fixture()
def app(tmp_path):
    """Return a Flask test application.

    Uses:
    * A fresh file-based SQLite DB per test (in tmp_path) so tests are isolated.
    * SKIP_KEY_CHECK=True so the auth service tests do not need a real key file.
    """
    db_file = str(tmp_path / "test_trust_trace.db")
    init_db(db_file)

    flask_app = create_app(
        env="testing",
        test_overrides={
            "DATABASE_PATH": db_file,
            "SKIP_KEY_CHECK": True,
            "TESTING": True,
            "SECRET_KEY": "test-secret",
        },
    )
    yield flask_app


@pytest.fixture()
def client(app):
    """Return a Flask test client."""
    return app.test_client()


@pytest.fixture()
def app_with_key(tmp_path):
    """Flask test app with a real P-256 key loaded (for QR/verify tests)."""
    db_file = str(tmp_path / "test_trust_trace_key.db")
    key_path = _write_temp_key(str(tmp_path))
    init_db(db_file)

    sig_svc.reset_keys()
    flask_app = create_app(
        env="testing",
        test_overrides={
            "DATABASE_PATH": db_file,
            "PRIVATE_KEY_PATH": key_path,
            "SKIP_KEY_CHECK": False,
            "TESTING": True,
            "SECRET_KEY": "test-secret",
        },
    )
    yield flask_app
    sig_svc.reset_keys()


@pytest.fixture()
def client_with_key(app_with_key):
    return app_with_key.test_client()


@pytest.fixture()
def auth_headers(client):
    """Register + login a test manufacturer; return Authorization header dict."""
    client.post(
        "/api/auth/register",
        json={
            "email": "fixture@example.com",
            "display_name": "Fixture Corp",
            "password": "FixturePass123!",
        },
    )
    resp = client.post(
        "/api/auth/login",
        json={"email": "fixture@example.com", "password": "FixturePass123!"},
    )
    token = resp.get_json()["session_token"]
    return {"Authorization": f"Bearer {token}"}