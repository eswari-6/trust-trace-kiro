﻿"""
tests/integration/test_auth_flow.py
Integration tests for the auth Blueprint endpoints.

Task: 21.3 (auth flow integration tests)
Requirements: 1.1-1.6, 2.1-2.6
"""

from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REGISTER_URL = "/api/auth/register"
LOGIN_URL = "/api/auth/login"
LOGOUT_URL = "/api/auth/logout"

DEFAULT_USER = {
    "email": "integ@example.com",
    "display_name": "Integration Corp",
    "password": "IntegPass123!",
}


def register(client, **kwargs):
    data = {**DEFAULT_USER, **kwargs}
    return client.post(REGISTER_URL, json=data)


def login(client, email=DEFAULT_USER["email"], password=DEFAULT_USER["password"]):
    return client.post(LOGIN_URL, json={"email": email, "password": password})


def logout(client, token):
    return client.post(LOGOUT_URL, headers={"Authorization": f"Bearer {token}"})


# ---------------------------------------------------------------------------
# Registration endpoint
# ---------------------------------------------------------------------------

class TestRegisterEndpoint:
    def test_successful_registration_returns_201(self, client):
        resp = register(client)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["ok"] is True
        assert "manufacturer_id" in data

    def test_duplicate_email_returns_409(self, client):
        register(client)
        resp = register(client)
        assert resp.status_code == 409
        data = resp.get_json()
        assert data["error"] == "email_already_registered"

    def test_short_password_returns_422(self, client):
        resp = register(client, password="short")
        assert resp.status_code == 422
        data = resp.get_json()
        assert data["error"] == "password_too_short"

    def test_invalid_email_returns_422(self, client):
        resp = register(client, email="not-an-email")
        assert resp.status_code == 422
        data = resp.get_json()
        assert data["error"] == "invalid_email_format"

    def test_missing_display_name_returns_422(self, client):
        resp = register(client, display_name="")
        assert resp.status_code == 422

    def test_missing_email_returns_422(self, client):
        resp = client.post(REGISTER_URL, json={"display_name": "Corp", "password": "ValidPass123!"})
        assert resp.status_code == 422

    def test_extra_fields_are_ignored(self, client):
        resp = register(client, extra_field="ignored", another_extra=123)
        assert resp.status_code == 201

    def test_no_json_body_returns_422(self, client):
        resp = client.post(REGISTER_URL, data="not json", content_type="text/plain")
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# Login endpoint
# ---------------------------------------------------------------------------

class TestLoginEndpoint:
    def test_successful_login_returns_200_with_token(self, client):
        register(client)
        resp = login(client)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["ok"] is True
        assert "session_token" in data
        assert len(data["session_token"]) == 64

    def test_wrong_password_returns_401(self, client):
        register(client)
        resp = login(client, password="WrongPassword!")
        assert resp.status_code == 401
        data = resp.get_json()
        assert data["error"] == "authentication_failed"

    def test_unknown_email_returns_401(self, client):
        resp = login(client, email="nobody@example.com")
        assert resp.status_code == 401

    def test_error_does_not_reveal_which_field_is_wrong(self, client):
        register(client)
        resp = login(client, password="WrongPassword!")
        data = resp.get_json()
        # Error key must be generic, not "wrong_password" or "wrong_email"
        assert data["error"] == "authentication_failed"

    def test_five_failures_trigger_lockout_429(self, client):
        register(client)
        for _ in range(4):
            r = login(client, password="BadPass123!")
            assert r.status_code == 401
        # 5th failure triggers lockout
        resp = login(client, password="BadPass123!")
        assert resp.status_code == 429
        data = resp.get_json()
        assert data["error"] == "account_locked"
        assert "locked_until" in data

    def test_locked_account_rejects_correct_password(self, client):
        register(client)
        for _ in range(5):
            login(client, password="BadPass123!")
        resp = login(client, password=DEFAULT_USER["password"])
        assert resp.status_code == 429


# ---------------------------------------------------------------------------
# Logout endpoint
# ---------------------------------------------------------------------------

class TestLogoutEndpoint:
    def test_logout_returns_200(self, client):
        register(client)
        resp = login(client)
        token = resp.get_json()["session_token"]
        resp = logout(client, token)
        assert resp.status_code == 200
        assert resp.get_json()["ok"] is True

    def test_token_invalidated_after_logout(self, client):
        """Requirement 2.6: token must be unusable immediately after logout."""
        register(client)
        login_resp = login(client)
        token = login_resp.get_json()["session_token"]
        logout(client, token)

        # Any subsequent call that validates the session should fail.
        # We verify by calling logout again -- it should still 200 but
        # validate_session called internally will return None.
        # More directly: validate_session returns None after logout.
        from trust_trace.services import auth_service
        from trust_trace.database import init_db
        db_path = client.application.config["DATABASE_PATH"]
        result = auth_service.validate_session(db_path, token)
        assert result is None

    def test_logout_without_token_returns_200(self, client):
        """Logout with no Bearer header is a no-op, not an error."""
        resp = client.post(LOGOUT_URL)
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Session validation (via service, tested through full register-login cycle)
# ---------------------------------------------------------------------------

class TestSessionLifecycle:
    def test_full_register_login_logout_cycle(self, client):
        # Register
        r = register(client)
        assert r.status_code == 201

        # Login
        r = login(client)
        assert r.status_code == 200
        token = r.get_json()["session_token"]

        # Session is valid
        from trust_trace.services import auth_service
        db_path = client.application.config["DATABASE_PATH"]
        mfg = auth_service.validate_session(db_path, token)
        assert mfg is not None
        assert mfg["email"] == DEFAULT_USER["email"].lower()

        # Logout
        logout(client, token)

        # Session is invalid
        mfg = auth_service.validate_session(db_path, token)
        assert mfg is None

    def test_duplicate_email_different_case_rejected(self, client):
        register(client, email="upper@example.com")
        resp = register(client, email="UPPER@example.com")
        assert resp.status_code == 409