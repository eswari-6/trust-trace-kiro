﻿"""
tests/integration/test_product_flow.py
Integration tests for product registration endpoints and signature verification.

Task: 21.2 (product flow integration tests), partial 21.4
Requirements: 3.1-3.6, 4.2, 11.1-11.3
"""

from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REGISTER_URL = "/api/auth/register"
LOGIN_URL    = "/api/auth/login"
PRODUCTS_URL = "/api/products"

AUTH_USER = {
    "email":        "prod_test@example.com",
    "display_name": "Product Tester Corp",
    "password":     "ProdTestPass123!",
}

PRODUCT_DEFAULTS = {
    "name":          "Widget Pro",
    "category":      "Electronics",
    "serial_number": "SN-INTEG-001",
    "brand":         "Acme",
    "model":         "WP-100",
}


def _register_and_login(client):
    client.post(REGISTER_URL, json=AUTH_USER)
    resp = client.post(LOGIN_URL, json={
        "email": AUTH_USER["email"], "password": AUTH_USER["password"]
    })
    token = resp.get_json()["session_token"]
    return {"Authorization": f"Bearer {token}"}


def _create_product(client, headers, **overrides):
    data = {**PRODUCT_DEFAULTS, **overrides}
    return client.post(PRODUCTS_URL, json=data, headers=headers)


# ---------------------------------------------------------------------------
# POST /api/products
# ---------------------------------------------------------------------------

class TestCreateProduct:
    def test_successful_registration_returns_201(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["ok"] is True
        assert len(data["product_id"]) == 32
        assert "registered_at" in data

    def test_response_product_id_is_hex(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers)
        pid = resp.get_json()["product_id"]
        assert all(c in "0123456789abcdef" for c in pid)

    def test_unauthenticated_request_returns_401(self, client):
        resp = client.post(PRODUCTS_URL, json=PRODUCT_DEFAULTS)
        assert resp.status_code == 401

    def test_invalid_token_returns_401(self, client):
        resp = client.post(PRODUCTS_URL, json=PRODUCT_DEFAULTS,
                           headers={"Authorization": "Bearer faketoken"})
        assert resp.status_code == 401

    def test_missing_name_returns_422(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers, name="")
        assert resp.status_code == 422

    def test_missing_category_returns_422(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers, category="")
        assert resp.status_code == 422

    def test_missing_serial_number_returns_422(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers, serial_number="")
        assert resp.status_code == 422

    def test_name_too_long_returns_422(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers, name="N" * 256)
        assert resp.status_code == 422

    def test_duplicate_serial_number_returns_409(self, client):
        headers = _register_and_login(client)
        _create_product(client, headers, serial_number="DUP-SN")
        resp = _create_product(client, headers, serial_number="DUP-SN")
        assert resp.status_code == 409
        data = resp.get_json()
        assert data["error"] == "duplicate_serial_number"

    def test_extra_fields_are_ignored(self, client):
        headers = _register_and_login(client)
        resp = _create_product(client, headers, extra_ignored_field="whatever", another=123)
        assert resp.status_code == 201

    def test_brand_and_model_optional(self, client):
        headers = _register_and_login(client)
        resp = client.post(PRODUCTS_URL, headers=headers, json={
            "name": "Minimal Product",
            "category": "General",
            "serial_number": "SN-MINIMAL",
        })
        assert resp.status_code == 201

    def test_multiple_products_different_serials(self, client):
        headers = _register_and_login(client)
        for i in range(3):
            resp = _create_product(client, headers, serial_number=f"SN-MULTI-{i}")
            assert resp.status_code == 201


# ---------------------------------------------------------------------------
# GET /api/products
# ---------------------------------------------------------------------------

class TestListProducts:
    def test_list_returns_empty_for_new_account(self, client):
        headers = _register_and_login(client)
        resp = client.get(PRODUCTS_URL, headers=headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["ok"] is True
        assert data["products"] == []

    def test_list_returns_registered_products(self, client):
        headers = _register_and_login(client)
        for i in range(3):
            _create_product(client, headers, serial_number=f"SN-LIST-{i}")
        resp = client.get(PRODUCTS_URL, headers=headers)
        assert resp.status_code == 200
        assert len(resp.get_json()["products"]) == 3

    def test_list_unauthenticated_returns_401(self, client):
        resp = client.get(PRODUCTS_URL)
        assert resp.status_code == 401

    def test_list_does_not_include_other_manufacturer_products(self, client):
        """Products are scoped to the authenticated manufacturer."""
        # Register two separate manufacturers
        client.post(REGISTER_URL, json={
            "email": "mfg_a@example.com", "display_name": "Corp A", "password": "PassA123456!"
        })
        resp_a = client.post(LOGIN_URL, json={"email": "mfg_a@example.com", "password": "PassA123456!"})
        headers_a = {"Authorization": f"Bearer {resp_a.get_json()['session_token']}"}

        client.post(REGISTER_URL, json={
            "email": "mfg_b@example.com", "display_name": "Corp B", "password": "PassB123456!"
        })
        resp_b = client.post(LOGIN_URL, json={"email": "mfg_b@example.com", "password": "PassB123456!"})
        headers_b = {"Authorization": f"Bearer {resp_b.get_json()['session_token']}"}

        # A registers a product
        _create_product(client, headers_a, serial_number="SN-A-ONLY")

        # B should see 0 products
        resp = client.get(PRODUCTS_URL, headers=headers_b)
        assert resp.get_json()["products"] == []


# ---------------------------------------------------------------------------
# GET /api/products/<product_id>
# ---------------------------------------------------------------------------

class TestGetProduct:
    def test_get_existing_product_returns_200(self, client):
        headers = _register_and_login(client)
        create_resp = _create_product(client, headers)
        pid = create_resp.get_json()["product_id"]

        resp = client.get(f"{PRODUCTS_URL}/{pid}", headers=headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["ok"] is True
        assert data["product"]["product_id"] == pid

    def test_get_product_contains_all_fields(self, client):
        headers = _register_and_login(client)
        create_resp = _create_product(client, headers)
        pid = create_resp.get_json()["product_id"]

        resp = client.get(f"{PRODUCTS_URL}/{pid}", headers=headers)
        product = resp.get_json()["product"]
        for field in ("product_id", "name", "category", "serial_number",
                      "registered_at", "manufacturer_id"):
            assert field in product

    def test_get_nonexistent_product_returns_404(self, client):
        headers = _register_and_login(client)
        resp = client.get(f"{PRODUCTS_URL}/nonexistentproductid12", headers=headers)
        assert resp.status_code == 404

    def test_get_other_manufacturers_product_returns_404(self, client):
        """Ownership check: manufacturer B cannot see manufacturer A's product."""
        client.post(REGISTER_URL, json={
            "email": "owner@example.com", "display_name": "Owner", "password": "OwnerPass123!"
        })
        resp = client.post(LOGIN_URL, json={"email": "owner@example.com", "password": "OwnerPass123!"})
        headers_owner = {"Authorization": f"Bearer {resp.get_json()['session_token']}"}

        create_resp = _create_product(client, headers_owner, serial_number="SN-OWNER")
        pid = create_resp.get_json()["product_id"]

        # Attacker account
        client.post(REGISTER_URL, json={
            "email": "attacker@example.com", "display_name": "Attacker", "password": "AttackPass123!"
        })
        resp2 = client.post(LOGIN_URL, json={"email": "attacker@example.com", "password": "AttackPass123!"})
        headers_attacker = {"Authorization": f"Bearer {resp2.get_json()['session_token']}"}

        resp = client.get(f"{PRODUCTS_URL}/{pid}", headers=headers_attacker)
        assert resp.status_code == 404

    def test_get_product_unauthenticated_returns_401(self, client):
        resp = client.get(f"{PRODUCTS_URL}/someproductid12345678901234567890")
        assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Signature verification (with real key -- uses app_with_key fixture)
# ---------------------------------------------------------------------------

class TestProductSignatureIntegration:
    def test_signature_verified_after_registration(self, client_with_key, app_with_key):
        """After product registration with a real key, the stored signature
        must verify against the canonical product payload."""
        import trust_trace.services.signature_service as sig_svc_local
        from trust_trace.database import get_db as _get_db

        # Register + login
        client_with_key.post(REGISTER_URL, json={
            "email": "sigtest@example.com",
            "display_name": "Sig Corp",
            "password": "SigTestPass123!",
        })
        resp = client_with_key.post(LOGIN_URL, json={
            "email": "sigtest@example.com", "password": "SigTestPass123!"
        })
        headers = {"Authorization": f"Bearer {resp.get_json()['session_token']}"}

        # Create product
        create_resp = client_with_key.post(PRODUCTS_URL, headers=headers, json={
            "name": "Signed Widget",
            "category": "Electronics",
            "serial_number": "SN-SIG-001",
            "brand": "TrustBrand",
            "model": "TM-1",
        })
        assert create_resp.status_code == 201
        pid = create_resp.get_json()["product_id"]

        # Fetch the stored record and verify signature
        db_path = app_with_key.config["DATABASE_PATH"]
        db = _get_db(db_path)
        row = db.execute("SELECT * FROM products WHERE product_id = ?", (pid,)).fetchone()
        db.close()

        canonical = {
            "product_id": row["product_id"],
            "serial_number": row["serial_number"],
            "name": row["name"],
            "manufacturer_id": row["manufacturer_id"],
            "registered_at": row["registered_at"],
        }
        assert sig_svc_local.verify_payload(canonical, row["qr_payload_hash"]) is True