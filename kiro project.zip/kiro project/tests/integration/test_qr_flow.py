﻿"""
tests/integration/test_qr_flow.py
Integration tests for the QR code generation endpoint.

Requirements covered: 4.1, 4.3, 4.4, 4.5, 4.6, 13.3
"""

from __future__ import annotations

import base64
import json
import io

import pytest
from PIL import Image


# ---------------------------------------------------------------------------
# Constants / helpers
# ---------------------------------------------------------------------------

AUTH_REGISTER = "/api/auth/register"
AUTH_LOGIN    = "/api/auth/login"
PRODUCTS_URL  = "/api/products"
QR_URL        = "/api/qr"

_USER_A = {"email": "qr_a@example.com", "display_name": "QR Corp A", "password": "QrPassA1234!"}
_USER_B = {"email": "qr_b@example.com", "display_name": "QR Corp B", "password": "QrPassB1234!"}


def _register_and_login(client, user: dict) -> dict:
    client.post(AUTH_REGISTER, json=user)
    resp = client.post(AUTH_LOGIN, json={"email": user["email"], "password": user["password"]})
    token = resp.get_json()["session_token"]
    return {"Authorization": f"Bearer {token}"}


def _create_product(client, headers: dict, serial: str = "SN-QR-INTEG-001") -> str:
    resp = client.post(PRODUCTS_URL, headers=headers, json={
        "name": "QR Test Widget",
        "category": "Electronics",
        "serial_number": serial,
        "brand": "TrustBrand",
        "model": "TM-QR-1",
    })
    assert resp.status_code == 201, f"Product creation failed: {resp.get_json()}"
    return resp.get_json()["product_id"]


def _decode_qr_payload(url: str) -> dict:
    """Extract and decode the JSON payload from a /verify?payload=... URL."""
    b64 = url.split("payload=")[1]
    padded = b64 + "=" * (4 - len(b64) % 4 if len(b64) % 4 else 0)
    return json.loads(base64.urlsafe_b64decode(padded).decode())


# ---------------------------------------------------------------------------
# Tests using app_with_key (real P-256 key loaded)
# ---------------------------------------------------------------------------

class TestQrEndpointWithKey:
    """Tests that require a real ECDSA key (use client_with_key fixture)."""

    def test_qr_returns_200_and_png_content_type(self, client_with_key):
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers)
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        assert resp.status_code == 200
        assert resp.content_type == "image/png"

    def test_qr_response_is_valid_png(self, client_with_key):
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-PNG-VALID")
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        assert resp.data[:8] == b"\x89PNG\r\n\x1a\n"

    def test_qr_png_minimum_300x300(self, client_with_key):
        """Requirement 4.3: PNG must be at least 300x300 pixels."""
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-300PX")
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        img = Image.open(io.BytesIO(resp.data))
        assert img.size[0] >= 300
        assert img.size[1] >= 300

    def test_qr_content_disposition_attachment(self, client_with_key):
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-DISP")
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        cd = resp.headers.get("Content-Disposition", "")
        assert "attachment" in cd
        assert pid in cd

    def test_qr_second_call_same_bytes(self, client_with_key):
        """Requirement 4.6: QR must be idempotent — same bytes on repeated calls."""
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-IDEM-INTEG")
        resp1 = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        resp2 = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        assert resp1.data == resp2.data

    def test_qr_url_embeds_product_id(self, client_with_key, app_with_key):
        """Requirement 4.1: QR code must contain a verification URL with product_id."""
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-EMBED-PID")

        # Read stored signature and reconstruct URL directly (no QR decode needed)
        from trust_trace.database import get_db
        from trust_trace.services.qr_service import _build_verification_url
        db = get_db(app_with_key.config["DATABASE_PATH"])
        row = db.execute("SELECT * FROM products WHERE product_id = ?", (pid,)).fetchone()
        db.close()
        url = _build_verification_url(dict(row), row["qr_payload_hash"], host="test")
        payload = _decode_qr_payload(url)
        assert payload["product_id"] == pid

    def test_qr_url_does_not_expose_private_key(self, client_with_key, app_with_key):
        """Requirement 4.4: private key must never appear in the QR URL."""
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-NO-KEY")

        from trust_trace.database import get_db
        from trust_trace.services.qr_service import _build_verification_url
        db = get_db(app_with_key.config["DATABASE_PATH"])
        row = db.execute("SELECT * FROM products WHERE product_id = ?", (pid,)).fetchone()
        db.close()
        url = _build_verification_url(dict(row), row["qr_payload_hash"], host="test")

        key_path = app_with_key.config["PRIVATE_KEY_PATH"]
        with open(key_path, "r") as fh:
            pem_content = fh.read()
        assert "BEGIN PRIVATE KEY" not in url
        assert pem_content.strip() not in url

    def test_qr_embedded_signature_is_verifiable(self, client_with_key, app_with_key):
        """The signature in the QR payload must pass ECDSA verification."""
        import trust_trace.services.signature_service as svc
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-VERIFY-SIG")

        from trust_trace.database import get_db
        from trust_trace.services.qr_service import _build_verification_url
        db = get_db(app_with_key.config["DATABASE_PATH"])
        row = db.execute("SELECT * FROM products WHERE product_id = ?", (pid,)).fetchone()
        db.close()
        url = _build_verification_url(dict(row), row["qr_payload_hash"], host="test")
        payload = _decode_qr_payload(url)
        sig = payload.pop("sig")
        assert svc.verify_payload(payload, sig) is True


# ---------------------------------------------------------------------------
# Access control tests (no key required — use base client fixture)
# ---------------------------------------------------------------------------

class TestQrAccessControl:
    def test_unauthenticated_request_returns_401(self, client):
        resp = client.get(f"{QR_URL}/someproductid1234567890123456789")
        assert resp.status_code == 401

    def test_invalid_token_returns_401(self, client):
        resp = client.get(
            f"{QR_URL}/someproductid1234567890123456789",
            headers={"Authorization": "Bearer badtoken"},
        )
        assert resp.status_code == 401

    def test_nonexistent_product_returns_404(self, client_with_key):
        headers = _register_and_login(client_with_key, _USER_B)
        resp = client_with_key.get(
            f"{QR_URL}/nonexistentproductid00000000000000",
            headers=headers,
        )
        assert resp.status_code == 404

    def test_other_manufacturers_product_returns_403(self, client_with_key):
        """Requirement 4.5: manufacturer B cannot get QR for manufacturer A's product."""
        headers_a = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers_a, serial="SN-OWNER-QR")

        headers_b = _register_and_login(client_with_key, _USER_B)
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers_b)
        assert resp.status_code == 403

    def test_correct_manufacturer_gets_200(self, client_with_key):
        headers = _register_and_login(client_with_key, _USER_A)
        pid = _create_product(client_with_key, headers, serial="SN-CORRECT-AUTH")
        resp = client_with_key.get(f"{QR_URL}/{pid}", headers=headers)
        assert resp.status_code == 200