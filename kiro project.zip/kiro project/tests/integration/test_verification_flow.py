﻿"""
tests/integration/test_verification_flow.py
Integration tests for the public product verification endpoint and scan monitor.

Task: 21.4 (verification flow integration), partial 21.2
Requirements: 5.1-5.6, 6.1-6.3, 13.3, 13.5
"""

from __future__ import annotations

import base64
import json


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

AUTH_REGISTER = "/api/auth/register"
AUTH_LOGIN    = "/api/auth/login"
PRODUCTS_URL  = "/api/products"
QR_URL        = "/api/qr"
VERIFY_URL    = "/api/verify"
VERIFY_PAGE   = "/verify"


def _register_and_login(client, email: str, password: str = "VerifyPass1234!"):
    client.post(AUTH_REGISTER, json={
        "email": email, "display_name": "Verify Corp", "password": password,
    })
    resp = client.post(AUTH_LOGIN, json={"email": email, "password": password})
    token = resp.get_json()["session_token"]
    return {"Authorization": f"Bearer {token}"}


def _create_product(client, headers: dict, serial: str = "SN-VFY-INTEG-001") -> str:
    resp = client.post(PRODUCTS_URL, headers=headers, json={
        "name": "Verifiable Widget",
        "category": "Electronics",
        "serial_number": serial,
        "brand": "TrustBrand",
        "model": "VFY-100",
    })
    assert resp.status_code == 201, resp.get_json()
    return resp.get_json()["product_id"]


def _build_payload_b64(product_dict: dict, sig: str) -> str:
    obj = {
        "product_id":      product_dict["product_id"],
        "serial_number":   product_dict["serial_number"],
        "name":            product_dict["name"],
        "manufacturer_id": product_dict["manufacturer_id"],
        "registered_at":   product_dict["registered_at"],
        "sig":             sig,
    }
    raw = json.dumps(obj, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _get_product_row(app, pid: str) -> dict:
    from trust_trace.database import get_db
    db = get_db(app.config["DATABASE_PATH"])
    row = db.execute("SELECT * FROM products WHERE product_id = ?", (pid,)).fetchone()
    db.close()
    return dict(row)


# ---------------------------------------------------------------------------
# No authentication required
# ---------------------------------------------------------------------------

class TestVerifyEndpointPublicAccess:
    def test_verify_endpoint_accessible_without_login(self, client_with_key):
        resp = client_with_key.get(VERIFY_URL + "?payload=abc123")
        # Must not return 401
        assert resp.status_code != 401

    def test_missing_payload_returns_400(self, client_with_key):
        resp = client_with_key.get(VERIFY_URL)
        assert resp.status_code == 400

    def test_garbage_payload_returns_invalid(self, client_with_key):
        resp = client_with_key.get(VERIFY_URL + "?payload=notvalidbase64!!!")
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "invalid"


# ---------------------------------------------------------------------------
# Authentic verification
# ---------------------------------------------------------------------------

class TestVerifyAuthentic:
    def test_valid_qr_payload_returns_authentic(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "vfya@example.com")
        pid = _create_product(client_with_key, headers)
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["status"] == "authentic"
        assert data["product"]["product_id"] == pid

    def test_authentic_response_includes_product_details(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "vfyb@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-DETAIL")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        product = resp.get_json()["product"]
        assert "name" in product
        assert "serial_number" in product
        assert "registered_at" in product
        assert "manufacturer_name" in product

    def test_authentic_response_no_password_hash(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "vfyc@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-NO-HASH")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        result_str = json.dumps(resp.get_json())
        assert "password_hash" not in result_str
        assert "BEGIN PRIVATE KEY" not in result_str


# ---------------------------------------------------------------------------
# Tampered data — invalid
# ---------------------------------------------------------------------------

class TestVerifyInvalid:
    def test_tampered_name_returns_invalid(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "tampa@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-TAMPER-NAME")
        row = _get_product_row(app_with_key, pid)
        tampered = dict(row)
        tampered["name"] = "FAKE PRODUCT"
        payload_b64 = _build_payload_b64(tampered, row["qr_payload_hash"])

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        assert resp.get_json()["status"] == "invalid"

    def test_tampered_serial_returns_invalid(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "tampb@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-TAMPER-SER")
        row = _get_product_row(app_with_key, pid)
        tampered = dict(row)
        tampered["serial_number"] = "FORGED-SN"
        payload_b64 = _build_payload_b64(tampered, row["qr_payload_hash"])

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        assert resp.get_json()["status"] == "invalid"

    def test_bad_signature_returns_invalid(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "tampc@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-BAD-SIG")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, "invalidsig")

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        assert resp.get_json()["status"] == "invalid"

    def test_invalid_response_has_message_field(self, client_with_key, app_with_key):
        headers = _register_and_login(client_with_key, "tampd@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-MSG-CHK")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, "bad")

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        data = resp.get_json()
        assert "message" in data
        assert len(data["message"]) > 0


# ---------------------------------------------------------------------------
# Unknown product ID — not_found
# ---------------------------------------------------------------------------

class TestVerifyNotFound:
    def test_unknown_product_id_returns_not_found(self, client_with_key, app_with_key):
        import trust_trace.services.signature_service as svc
        headers = _register_and_login(client_with_key, "nfnd@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-REAL-NFND")
        row = _get_product_row(app_with_key, pid)
        # Build a payload for a product that doesn't exist
        fake = dict(row)
        fake["product_id"] = "d" * 32
        sig = svc.sign_payload(fake)
        payload_b64 = _build_payload_b64(fake, sig)

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        assert resp.get_json()["status"] == "not_found"

    def test_not_found_response_has_message(self, client_with_key, app_with_key):
        import trust_trace.services.signature_service as svc
        headers = _register_and_login(client_with_key, "nfne@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-NFND-MSG")
        row = _get_product_row(app_with_key, pid)
        fake = dict(row)
        fake["product_id"] = "c" * 32
        sig = svc.sign_payload(fake)
        payload_b64 = _build_payload_b64(fake, sig)

        resp = client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")
        data = resp.get_json()
        assert "message" in data


# ---------------------------------------------------------------------------
# Scan event recording (Requirements 5.5, 5.6)
# ---------------------------------------------------------------------------

class TestScanEventRecording:
    def test_authentic_verification_records_scan_event(self, client_with_key, app_with_key):
        from trust_trace.database import get_db
        headers = _register_and_login(client_with_key, "scna@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-SCNA")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")

        db = get_db(app_with_key.config["DATABASE_PATH"])
        events = db.execute(
            "SELECT * FROM scan_events WHERE product_id = ?", (pid,)
        ).fetchall()
        db.close()
        assert len(events) == 1
        assert events[0]["outcome"] == "authentic"

    def test_repeated_scans_trigger_suspicious_alert(self, client_with_key, app_with_key):
        """Requirement 6.1: >10 scans in 60 min triggers a volume alert.
        Alert must NOT automatically declare product counterfeit (Requirement 6.2)."""
        from trust_trace.database import get_db
        headers = _register_and_login(client_with_key, "scnb@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-REPEAT")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        # Trigger 11 scans
        for _ in range(11):
            client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")

        db = get_db(app_with_key.config["DATABASE_PATH"])
        alerts = db.execute(
            "SELECT * FROM suspicious_activity_alerts WHERE product_id = ? AND alert_type = 'volume'",
            (pid,),
        ).fetchall()
        db.close()
        assert len(alerts) >= 1, "Expected a volume alert after 11 scans"
        # Product itself must not be marked counterfeit
        prod_row = db.execute if False else get_db(app_with_key.config["DATABASE_PATH"]).execute(
            "SELECT * FROM products WHERE product_id = ?", (pid,)
        ).fetchone()
        assert "counterfeit" not in str(dict(prod_row)).lower()

    def test_alert_message_does_not_say_counterfeit(self, client_with_key, app_with_key):
        """Requirement 6.5: alert details must not assert the product is counterfeit."""
        from trust_trace.database import get_db
        headers = _register_and_login(client_with_key, "scnc@example.com")
        pid = _create_product(client_with_key, headers, serial="SN-NO-FAKE")
        row = _get_product_row(app_with_key, pid)
        payload_b64 = _build_payload_b64(row, row["qr_payload_hash"])

        for _ in range(11):
            client_with_key.get(f"{VERIFY_URL}?payload={payload_b64}")

        db = get_db(app_with_key.config["DATABASE_PATH"])
        alert = db.execute(
            "SELECT * FROM suspicious_activity_alerts WHERE product_id = ?", (pid,)
        ).fetchone()
        db.close()
        if alert:
            alert_str = json.dumps(dict(alert))
            assert "counterfeit" not in alert_str.lower()


# ---------------------------------------------------------------------------
# Verify HTML page (Requirement 12.3)
# ---------------------------------------------------------------------------

class TestVerifyPage:
    def test_verify_page_returns_200(self, client_with_key):
        resp = client_with_key.get(VERIFY_PAGE)
        assert resp.status_code == 200

    def test_verify_page_is_html(self, client_with_key):
        resp = client_with_key.get(VERIFY_PAGE)
        assert "text/html" in resp.content_type

    def test_verify_page_contains_trusttrace_branding(self, client_with_key):
        resp = client_with_key.get(VERIFY_PAGE)
        assert b"TrustTrace" in resp.data