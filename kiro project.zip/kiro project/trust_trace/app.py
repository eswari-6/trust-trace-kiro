﻿
"""
app.py — Flask application factory for TrustTrace.

Creates and configures the Flask application, initializes the database,
applies database migrations, validates the private key, and registers
application blueprints and JSON error handlers.
"""

from __future__ import annotations

import logging

from flask import Flask, jsonify, render_template

from trust_trace.config import get_config
from trust_trace.database import init_db

logger = logging.getLogger(__name__)


def create_app(
    env: str | None = None,
    test_overrides: dict | None = None,
) -> Flask:
    """Create and configure the TrustTrace Flask application.

    Args:
        env: Environment name, such as development, production, or testing.
        test_overrides: Optional configuration overrides, useful for tests.

    Returns:
        The configured Flask application.
    """

    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    # ---------------------------------------------------------------
    # Configuration
    # ---------------------------------------------------------------
    cfg = get_config(env)
    app.config.from_object(cfg)

    if test_overrides:
        app.config.update(test_overrides)
    
    # ---------------------------------------------------------------
    # QR Code Host Configuration (Mobile Verification)
    # ---------------------------------------------------------------
    if not app.config.get("QR_HOST"):
        app.config["QR_HOST"] = "192.168.58.42:5000"

    # ---------------------------------------------------------------
    # Database initialization and migrations
    # ---------------------------------------------------------------
    from trust_trace.database import init_db_and_migrate

    database_path = app.config["DATABASE_PATH"]
    init_db_and_migrate(database_path)

    # ---------------------------------------------------------------
    # Private key startup check
    # ---------------------------------------------------------------
    # Testing configurations may skip this check when explicitly set.
    if not app.config.get("SKIP_KEY_CHECK", False):
        from trust_trace.services import signature_service

        try:
            signature_service.load_private_key(
                app.config["PRIVATE_KEY_PATH"]
            )
        except RuntimeError as exc:
            logger.critical("Startup failed: %s", exc)
            raise SystemExit(1) from exc

    # ---------------------------------------------------------------
    # Blueprint registration
    # ---------------------------------------------------------------
    from trust_trace.routes.auth_routes import auth_bp
    from trust_trace.routes.product_routes import product_bp
    from trust_trace.routes.qr_routes import qr_bp
    from trust_trace.routes.verify_routes import verify_bp, page_bp
    from trust_trace.routes.admin_routes import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(product_bp)
    app.register_blueprint(qr_bp)
    app.register_blueprint(verify_bp)
    app.register_blueprint(page_bp)
    app.register_blueprint(admin_bp)

    # ---------------------------------------------------------------
    # Global JSON error handlers
    # ---------------------------------------------------------------
    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({
            "ok": False,
            "error": "bad_request",
        }), 400

    @app.errorhandler(401)
    def unauthorized(error):
        return jsonify({
            "ok": False,
            "error": "unauthorized",
        }), 401

    @app.errorhandler(403)
    def forbidden(error):
        return jsonify({
            "ok": False,
            "error": "forbidden",
        }), 403

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            "ok": False,
            "error": "not_found",
        }), 404

    @app.errorhandler(422)
    def unprocessable(error):
        return jsonify({
            "ok": False,
            "error": "unprocessable_entity",
        }), 422

    @app.errorhandler(429)
    def too_many_requests(error):
        return jsonify({
            "ok": False,
            "error": "too_many_requests",
        }), 429

    @app.errorhandler(500)
    def internal_error(error):
        logger.error("Unhandled server error: %s", error)

        return jsonify({
            "ok": False,
            "error": "internal_error",
        }), 500
# Register page route
    @app.route("/register", methods=["GET"])
    def register_page():
        return render_template("register.html")

    return app
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)