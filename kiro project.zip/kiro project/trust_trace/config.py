﻿"""
config.py — Environment-based configuration for TrustTrace.

All values that differ between development and production are read from
environment variables so the application binary can be deployed unchanged.
"""

import os


class Config:
    """Base configuration.  Values are read from environment variables
    with safe, non-production defaults where appropriate."""

    # ------------------------------------------------------------------ #
    # Cryptography
    # ------------------------------------------------------------------ #
    # Absolute or relative path to the ECDSA P-256 private key PEM file.
    PRIVATE_KEY_PATH: str = os.environ.get("PRIVATE_KEY_PATH", "keys/private.pem")

    # ------------------------------------------------------------------ #
    # Database
    # ------------------------------------------------------------------ #
    DATABASE_PATH: str = os.environ.get("DATABASE_PATH", "trust_trace.db")

    # ------------------------------------------------------------------ #
    # Flask / sessions
    # ------------------------------------------------------------------ #
    # Must be set to a long random value in production.
    SECRET_KEY: str = os.environ.get("SECRET_KEY", "dev-secret-key-do-not-use-in-production")

    # ------------------------------------------------------------------ #
    # Environment flag
    # ------------------------------------------------------------------ #
    FLASK_ENV: str = os.environ.get("FLASK_ENV", "development")
    DEBUG: bool = FLASK_ENV == "development"
    TESTING: bool = False


class TestingConfig(Config):
    """Configuration used by the pytest test suite.

    Uses an in-memory SQLite database so tests run in isolation and leave no
    files on disk.  A temporary key pair is generated in the test fixtures.
    """

    TESTING: bool = True
    DATABASE_PATH: str = ":memory:"
    SECRET_KEY: str = "testing-secret-key"
    DEBUG: bool = False


# ------------------------------------------------------------------ #
# Config registry — select with FLASK_ENV or explicitly in create_app()
# ------------------------------------------------------------------ #
_CONFIG_MAP = {
    "development": Config,
    "production": Config,
    "testing": TestingConfig,
}


def get_config(env: str | None = None) -> type[Config]:
    """Return the Config class for the given environment name.

    Falls back to the value of the FLASK_ENV environment variable, then
    to *development* if neither is supplied.
    """
    key = (env or os.environ.get("FLASK_ENV", "development")).lower()
    return _CONFIG_MAP.get(key, Config)
