﻿"""
routes/product_routes.py -- Flask Blueprint for product management endpoints.

Endpoints (Requirements 3.1-3.6, 11.1, 11.2, 11.3):
  POST /api/products                   -- Register a new product
  GET  /api/products                   -- List manufacturer's products
  GET  /api/products/<product_id>      -- Get a single product

All endpoints require a valid Bearer session token.
Extraneous JSON fields are silently ignored (Requirement 11.3).
"""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

from trust_trace.routes.utils import require_auth
from trust_trace.services import product_service

product_bp = Blueprint("products", __name__, url_prefix="/api/products")


def _db_path() -> str:
    return current_app.config["DATABASE_PATH"]


# ---------------------------------------------------------------------------
# POST /api/products  -- Register a product
# ---------------------------------------------------------------------------

@product_bp.route("", methods=["POST"])
@require_auth
def create_product(manufacturer):
    data = request.get_json(silent=True) or {}

    # Extract only defined fields; extras are silently ignored (Req 11.3)
    name          = str(data.get("name",          "")).strip()
    category      = str(data.get("category",      "")).strip()
    serial_number = str(data.get("serial_number", "")).strip()
    brand         = data.get("brand")
    model         = data.get("model")

    # Normalise optional fields
    brand = str(brand).strip() if brand else None
    model = str(model).strip() if model else None

    result = product_service.register_product(
        _db_path(),
        manufacturer_id=manufacturer["id"],
        name=name,
        category=category,
        serial_number=serial_number,
        brand=brand,
        model=model,
    )

    if result["ok"]:
        return jsonify(result), 201

    error = result.get("error")
    if error == "duplicate_serial_number":
        return jsonify(result), 409
    if error in ("missing_field", "field_too_long"):
        return jsonify(result), 422
    return jsonify(result), 400


# ---------------------------------------------------------------------------
# GET /api/products  -- List products for the authenticated manufacturer
# ---------------------------------------------------------------------------

@product_bp.route("", methods=["GET"])
@require_auth
def list_products(manufacturer):
    products = product_service.list_products(_db_path(), manufacturer["id"])
    return jsonify({"ok": True, "products": products}), 200


# ---------------------------------------------------------------------------
# GET /api/products/<product_id>  -- Get one product
# ---------------------------------------------------------------------------

@product_bp.route("/<product_id>", methods=["GET"])
@require_auth
def get_product(manufacturer, product_id):
    product = product_service.get_product(
        _db_path(), product_id, manufacturer_id=manufacturer["id"]
    )
    if product is None:
        return jsonify({"ok": False, "error": "not_found"}), 404
    return jsonify({"ok": True, "product": product}), 200