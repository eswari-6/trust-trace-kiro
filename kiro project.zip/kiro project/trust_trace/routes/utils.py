﻿"""
routes/utils.py -- Shared Flask route utilities for TrustTrace.

Provides:
  require_auth  -- Decorator that validates the Bearer session token and
                   injects the manufacturer dict as the first argument.
"""

from __future__ import annotations

import functools
from typing import Callable

from flask import current_app, jsonify, request

from trust_trace.services import auth_service


def require_auth(fn: Callable) -> Callable:
    """Decorator: validate the Bearer session token; reject with 401 if invalid.

    Injects ``manufacturer`` (dict with id, email, display_name) as the
    first positional argument of the decorated view function.

    Usage::

        @product_bp.route("/api/products", methods=["POST"])
        @require_auth
        def create_product(manufacturer):
            ...
    """
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"ok": False, "error": "unauthorized"}), 401

        token = auth_header[7:].strip()
        db_path = current_app.config["DATABASE_PATH"]
        manufacturer = auth_service.validate_session(db_path, token)

        if manufacturer is None:
            return jsonify({"ok": False, "error": "unauthorized"}), 401

        return fn(manufacturer, *args, **kwargs)

    return wrapper