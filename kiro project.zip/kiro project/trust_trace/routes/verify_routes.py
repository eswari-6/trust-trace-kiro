﻿
"""
routes/verify_routes.py -- Public verification and page routes for TrustTrace.

Endpoints:
    GET /api/verify?payload=<base64url>
        Public product verification API.

    GET /verify
        Public product verification page.

    GET /admin
        Admin dashboard page.

    GET /register
        Manufacturer registration page.
"""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, render_template, request

from trust_trace.services import verification_service


# Public product verification API.
verify_bp = Blueprint("verify", __name__, url_prefix="/api")

# Browser pages that do not use the /api prefix.
page_bp = Blueprint("pages", __name__)


# ---------------------------------------------------------------------------
# GET /verify -- Public product verification page
# ---------------------------------------------------------------------------

@page_bp.route("/verify", methods=["GET"])
def verify_page():
    return render_template("verify.html")


# ---------------------------------------------------------------------------
# GET /admin -- Admin dashboard and login page
# ---------------------------------------------------------------------------

@page_bp.route("/admin", methods=["GET"])
def admin_dashboard_page():
    return render_template("admin_dashboard.html")


# ---------------------------------------------------------------------------
# GET /register -- Manufacturer registration page
# ---------------------------------------------------------------------------

@page_bp.route("/register", methods=["GET"])
def register_page():
    return render_template("register.html")

@page_bp.route("/login", methods=["GET"])
def login_page():
    return render_template("login.html")
    
# Product management page
@page_bp.route("/products", methods=["GET"])
def products_page():
    return render_template("products.html")

# ---------------------------------------------------------------------------
# Helpers for public product verification
# ---------------------------------------------------------------------------

def _db_path() -> str:
    return current_app.config["DATABASE_PATH"]


def _source_ip() -> str:
    """Return the request source IP."""

    # Use the direct client address by default.
    # Only trust X-Forwarded-For when the application is configured
    # behind a trusted proxy that sanitizes that header.
    return request.remote_addr or "unavailable"


# ---------------------------------------------------------------------------
# GET /api/verify -- Public product verification API
# ---------------------------------------------------------------------------

@verify_bp.route("/verify", methods=["GET"])
def verify():
    """
    Verify a product using the Base64url-encoded signed QR payload.

    Authentication is not required for public product verification.

    Possible results include:
        {"status": "authentic", "product": {...}}
        {"status": "invalid", "message": "..."}
        {"status": "not_found", "message": "..."}
    """

    payload_b64 = request.args.get("payload", "").strip()

    if not payload_b64:
        return jsonify({
            "status": "invalid",
            "message": "Missing payload parameter.",
        }), 400

    result = verification_service.verify_product(
        _db_path(),
        signed_payload_b64=payload_b64,
        source_ip=_source_ip(),
    )

    return jsonify(result), 200
