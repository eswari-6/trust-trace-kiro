﻿
"""
routes/qr_routes.py -- Flask Blueprint for QR code generation endpoint.

GET /api/qr/<product_id>
    Download the QR code PNG for a product.

Requires a valid Bearer session token.
Returns:
    200 -- QR code PNG
    403 -- Product exists but belongs to another manufacturer
    404 -- Product does not exist
    503 -- QR code cannot be generated because the signing key is unavailable
"""

from __future__ import annotations

from flask import Blueprint, Response, current_app, jsonify, request

from trust_trace.routes.utils import require_auth
from trust_trace.services import qr_service


qr_bp = Blueprint(
    "qr",
    __name__,
    url_prefix="/api/qr",
)


def _db_path() -> str:
    """Return the configured SQLite database path."""
    return current_app.config["DATABASE_PATH"]


def _host() -> str:
    """
    Determine the hostname used in the verification URL.

    QR_HOST should contain the computer's LAN IP and Flask port
    for mobile scanning on the same Wi-Fi network.

    Example:
        QR_HOST = "192.168.58.42:5000"
    """

    # Prefer the explicitly configured QR host.
    configured_host = current_app.config.get("QR_HOST")

    if configured_host:
        return str(configured_host).strip()

    # Fall back to SERVER_NAME if configured.
    server_name = current_app.config.get("SERVER_NAME")

    if server_name:
        return str(server_name).strip()

    # Otherwise, use the incoming request's Host header.
    return request.host or "localhost:5000"


# ---------------------------------------------------------
# GET /api/qr/<product_id>
# ---------------------------------------------------------

@qr_bp.route("/<product_id>", methods=["GET"])
@require_auth
def get_qr(manufacturer, product_id):
    """
    Generate or retrieve the QR code for a product owned by
    the authenticated manufacturer.
    """

    database_path = _db_path()

    png_bytes = qr_service.get_or_create_qr(
        database_path,
        product_id=product_id,
        manufacturer_id=manufacturer["id"],
        host=_host(),
    )

    if png_bytes is None:
        from trust_trace.services import product_service

        # Check whether the product belongs to this manufacturer.
        product = product_service.get_product(
            database_path,
            product_id,
            manufacturer_id=manufacturer["id"],
        )

        if product is None:
            # Distinguish a product owned by another manufacturer
            # from a product that does not exist.
            product_any = product_service.get_product(
                database_path,
                product_id,
            )

            if product_any is not None:
                return jsonify({
                    "ok": False,
                    "error": "forbidden",
                    "message": (
                        "You do not have permission to access this product."
                    ),
                }), 403

            return jsonify({
                "ok": False,
                "error": "not_found",
                "message": "Product not found.",
            }), 404

        # The product exists and is owned by this manufacturer,
        # but QR generation is unavailable.
        return jsonify({
            "ok": False,
            "error": "qr_unavailable",
            "message": (
                "QR code cannot be generated because the signing key "
                "is unavailable."
            ),
        }), 503

    # Return the QR image as a downloadable PNG.
    return Response(
        png_bytes,
        status=200,
        mimetype="image/png",
        headers={
            "Content-Disposition": (
                f'attachment; filename="{product_id}.png"'
            ),
            "Content-Length": str(len(png_bytes)),
        },
    )
