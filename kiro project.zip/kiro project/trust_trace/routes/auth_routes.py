﻿
"""
routes/auth_routes.py -- Flask Blueprint for authentication endpoints.

Endpoints:
    POST /api/auth/register -- Create a customer or manufacturer account
    POST /api/auth/login    -- Authenticate and receive a session token
    POST /api/auth/logout   -- Invalidate the current session token

All endpoints:
    - Ignore extraneous JSON fields.
    - Return application/json responses with appropriate HTTP status codes.
    - Do not reveal whether email or password was incorrect on login failure.
"""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

from trust_trace.services import auth_service

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def _db_path() -> str:
    return current_app.config["DATABASE_PATH"]


def _bearer_token() -> str | None:
    """Extract the Bearer token from the Authorization header, if present."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:].strip()
    return None


# ---------------------------------------------------------------------------
# POST /api/auth/register
# ---------------------------------------------------------------------------

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}

    # Read only the fields required for registration.
    email = str(data.get("email", "")).strip()
    display_name = str(data.get("display_name", "")).strip()
    password = str(data.get("password", ""))

    # Default to manufacturer for compatibility with the existing frontend.
    account_type = str(data.get("account_type", "manufacturer")).strip().lower()

    if not email:
        return jsonify({
            "ok": False,
            "error": "missing_field",
            "field": "email",
        }), 422

    if not display_name:
        return jsonify({
            "ok": False,
            "error": "missing_field",
            "field": "display_name",
        }), 422

    if not password:
        return jsonify({
            "ok": False,
            "error": "missing_field",
            "field": "password",
        }), 422

    # Register the selected account type.
    if account_type == "customer":
        result = auth_service.register_customer(
            _db_path(),
            email,
            display_name,
            password,
        )

    elif account_type == "manufacturer":
        result = auth_service.register_manufacturer(
            _db_path(),
            email,
            display_name,
            password,
        )

    else:
        return jsonify({
            "ok": False,
            "error": "invalid_account_type",
        }), 400

    if result.get("ok"):
        return jsonify(result), 201

    error = result.get("error")

    if error == "email_already_registered":
        return jsonify(result), 409

    if error in (
        "password_too_short",
        "invalid_email_format",
        "missing_field",
        "field_too_long",
    ):
        return jsonify(result), 422

    return jsonify(result), 400


# ---------------------------------------------------------------------------
# POST /api/auth/login
# ---------------------------------------------------------------------------

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}

    email = str(data.get("email", "")).strip()
    password = str(data.get("password", ""))

    result = auth_service.login(
        _db_path(),
        email,
        password,
    )

    if result.get("ok"):
        return jsonify(result), 200

    error = result.get("error")

    if error == "account_locked":
        return jsonify(result), 429

    # Keep login failure messages generic.
    return jsonify({
        "ok": False,
        "error": error if error == "too_many_attempts" else "invalid_credentials",
    }), 401


# ---------------------------------------------------------------------------
# POST /api/auth/logout
# ---------------------------------------------------------------------------

@auth_bp.route("/logout", methods=["POST"])
def logout():
    token = _bearer_token()

    if token:
        auth_service.logout(_db_path(), token)

    return jsonify({"ok": True}), 200
