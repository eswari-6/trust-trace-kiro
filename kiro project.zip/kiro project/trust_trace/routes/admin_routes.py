
"""Admin routes for the TrustTrace application."""

from flask import Blueprint, current_app, jsonify

from trust_trace.database import get_db
from trust_trace.routes.utils import require_auth

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


def _is_admin(manufacturer):
    """Return whether the authenticated manufacturer is an admin."""
    return bool(manufacturer.get("is_admin", 0))


@admin_bp.route("/dashboard", methods=["GET"])
@require_auth
def admin_dashboard(manufacturer):
    """Return dashboard statistics for administrators."""

    if not _is_admin(manufacturer):
        return jsonify({
            "ok": False,
            "error": "admin_permission_required",
        }), 403

    db = get_db(current_app.config["DATABASE_PATH"])

    try:
        products_count = db.execute(
            "SELECT COUNT(*) FROM products"
        ).fetchone()[0]

        manufacturers_count = db.execute(
            "SELECT COUNT(*) FROM manufacturers"
        ).fetchone()[0]

        scans_count = db.execute(
            "SELECT COUNT(*) FROM scan_events"
        ).fetchone()[0]

        alerts_count = db.execute(
            """
            SELECT COUNT(*)
            FROM suspicious_activity_alerts
            WHERE resolved = 0
            """
        ).fetchone()[0]

        return jsonify({
            "ok": True,
            "products_count": products_count,
            "manufacturers_count": manufacturers_count,
            "scans_count": scans_count,
            "unresolved_alerts_count": alerts_count,
        }), 200

    finally:
        db.close()


@admin_bp.route("/alerts", methods=["GET"])
@require_auth
def admin_alerts(manufacturer):
    """List suspicious activity alerts for administrators."""

    if not _is_admin(manufacturer):
        return jsonify({
            "ok": False,
            "error": "admin_permission_required",
        }), 403

    db = get_db(current_app.config["DATABASE_PATH"])

    try:
        rows = db.execute(
            """
            SELECT id, product_id, alert_type, detected_at,
                   scan_count, ip_addresses, resolved, resolved_at
            FROM suspicious_activity_alerts
            ORDER BY detected_at DESC
            """
        ).fetchall()

        return jsonify({
            "ok": True,
            "alerts": [dict(row) for row in rows],
        }), 200

    finally:
        db.close()
