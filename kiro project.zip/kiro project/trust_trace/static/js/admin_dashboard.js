
const loginForm = document.getElementById("adminLoginForm");
const loginSection = document.getElementById("loginSection");
const loginMessage = document.getElementById("loginMessage");
const loginButton = document.getElementById("loginBtn");
const dashboardContent = document.getElementById("dashboardContent");
const messageElement = document.getElementById("message");
const refreshButton = document.getElementById("refreshBtn");

function getSessionToken() {
    return sessionStorage.getItem("session_token");
}

async function apiRequest(url) {
    const token = getSessionToken();

    if (!token) {
        throw new Error("Please log in first.");
    }

    const response = await fetch(url, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json"
        }
    });

    if (response.status === 401) {
        sessionStorage.removeItem("session_token");
        throw new Error("Session expired. Please log in again.");
    }

    if (response.status === 403) {
        throw new Error("Admin access required. This account is not an administrator.");
    }

    if (!response.ok) {
        throw new Error(`Request failed (${response.status}).`);
    }

    return response.json();
}

function displayValue(id, value) {
    const element = document.getElementById(id);
    const number = Number(value);

    element.textContent =
        Number.isFinite(number) ? number.toLocaleString() : "0";
}

function renderAlerts(alerts) {
    const table = document.getElementById("alertsTable");
    table.replaceChildren();

    if (!Array.isArray(alerts) || alerts.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 2;
        cell.textContent = "No security alerts found.";

        row.appendChild(cell);
        table.appendChild(row);
        return;
    }

    alerts.forEach((alert) => {
        const row = document.createElement("tr");
        const detailsCell = document.createElement("td");
        const statusCell = document.createElement("td");

        detailsCell.textContent =
            alert.description ||
            alert.message ||
            alert.activity_type ||
            `Alert #${alert.id ?? "-"}`;

        statusCell.textContent =
            alert.status ||
            (alert.resolved ? "Resolved" : "Unresolved");

        row.append(detailsCell, statusCell);
        table.appendChild(row);
    });
}

async function loadDashboard() {
    refreshButton.disabled = true;
    messageElement.textContent = "Loading dashboard data...";

    try {
        const [dashboard, alertsResponse] = await Promise.all([
            apiRequest("/api/admin/dashboard"),
            apiRequest("/api/admin/alerts")
        ]);

        displayValue("manufacturersCount", dashboard.manufacturers_count);
        displayValue("productsCount", dashboard.products_count);
        displayValue("scansCount", dashboard.scans_count);
        displayValue("alertsCount", dashboard.unresolved_alerts_count);

        const alerts = Array.isArray(alertsResponse)
            ? alertsResponse
            : alertsResponse.alerts;

        renderAlerts(alerts);
        messageElement.textContent = "Dashboard data loaded successfully.";
    } catch (error) {
        messageElement.textContent = error.message;

        if (
            error.message.includes("Session expired") ||
            error.message.includes("Please log in first")
        ) {
            showLogin();
        }
    } finally {
        refreshButton.disabled = false;
    }
}

function showLogin() {
    dashboardContent.hidden = true;
    loginSection.hidden = false;
}

function showDashboard() {
    loginSection.hidden = true;
    dashboardContent.hidden = false;
}

loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    loginButton.disabled = true;
    loginMessage.textContent = "Checking login details...";

    const email = document.getElementById("adminEmail").value.trim();
    const password = document.getElementById("adminPassword").value;

    try {
        const response = await fetch("/api/auth/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            },
            body: JSON.stringify({ email, password })
        });

        const result = await response.json();

        if (!response.ok || !result.ok || !result.session_token) {
            if (response.status === 429) {
                throw new Error("Account temporarily locked. Please try later.");
            }

            throw new Error("Invalid email or password.");
        }

        sessionStorage.setItem("session_token", result.session_token);

        // Verify administrator access before showing dashboard information.
        await apiRequest("/api/admin/dashboard");

        loginForm.reset();
        showDashboard();
        await loadDashboard();

    } catch (error) {
        sessionStorage.removeItem("session_token");
        showLogin();
        loginMessage.textContent = error.message;
    } finally {
        loginButton.disabled = false;
    }
});

refreshButton.addEventListener("click", loadDashboard);

// Initially show login; do not expose dashboard data before authentication.
showLogin();
