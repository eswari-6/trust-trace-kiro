﻿
/**
 * verify.js -- Public product verification page logic
 *
 * Preserves the existing verification flow:
 * 1. Reads ?payload= from the current URL.
 * 2. Calls GET /api/verify?payload=...
 * 3. Displays authentic, invalid, or not_found results.
 *
 * Security:
 * Dynamic content is inserted using textContent.
 * No dynamic innerHTML is used.
 */

(function () {
  "use strict";

  /* DOM references */
  var spinner = document.getElementById("spinner");
  var badge = document.getElementById("status-badge");
  var statusText = document.getElementById("status-text");
  var message = document.getElementById("result-message");
  var detailsEl = document.getElementById("product-details");
  var disclaimerEl = document.getElementById("disclaimer");

  /* Validate required page elements */
  if (
    !spinner ||
    !badge ||
    !statusText ||
    !message ||
    !detailsEl ||
    !disclaimerEl
  ) {
    console.error(
      "TrustTrace verification page is missing required HTML elements."
    );
    return;
  }

  /* Helpers */

  function safeText(value) {
    if (value === null || value === undefined || value === "") {
      return "—";
    }

    return String(value);
  }

  function detailRow(label, value) {
    var row = document.createElement("div");
    var labelElement = document.createElement("span");
    var valueElement = document.createElement("span");

    row.className = "detail-row";
    labelElement.className = "detail-label";
    valueElement.className = "detail-value";

    labelElement.textContent = label;
    valueElement.textContent = safeText(value);

    row.appendChild(labelElement);
    row.appendChild(valueElement);

    return row;
  }

  function formatDate(value) {
    if (!value) {
      return "—";
    }

    var date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return safeText(value);
    }

    return date.toLocaleString();
  }

  function setStatus(statusClass, icon, title, description) {
    spinner.hidden = true;

    badge.className = "status-badge " + statusClass;

    var iconElement = badge.querySelector(".status-icon");

    if (iconElement) {
      iconElement.textContent = icon;
    }

    statusText.textContent = title;
    message.textContent = description;
  }

  function clearProductDetails() {
    while (detailsEl.firstChild) {
      detailsEl.removeChild(detailsEl.firstChild);
    }

    detailsEl.hidden = true;
    disclaimerEl.hidden = true;
  }

  /* Render an authentic product */

  function showAuthentic(product) {
    clearProductDetails();

    setStatus(
      "authentic",
      "✅",
      "Authentic Product",
      "This product's digital record has been verified as genuine."
    );

    var heading = document.createElement("h2");
    heading.textContent = "Product Details";
    detailsEl.appendChild(heading);

    var rows = [
      ["Product Name", product.name],
      ["Category", product.category],
      ["Brand", product.brand],
      ["Model", product.model],
      ["Serial Number", product.serial_number],
      ["Manufacturer", product.manufacturer_name],
      ["Registered", formatDate(product.registered_at)]
    ];

    rows.forEach(function (item) {
      if (
        item[1] !== null &&
        item[1] !== undefined &&
        item[1] !== ""
      ) {
        detailsEl.appendChild(detailRow(item[0], item[1]));
      }
    });

    detailsEl.hidden = false;
    disclaimerEl.hidden = false;
  }

  /* Render an invalid or tampered payload */

  function showInvalid(serverMessage) {
    clearProductDetails();

    setStatus(
      "invalid",
      "❌",
      "Verification Failed",
      serverMessage ||
        "This product record could not be verified. The QR code may have been tampered with."
    );
  }

  /* Render a product that is not in the registry */

  function showNotFound(serverMessage) {
    clearProductDetails();

    setStatus(
      "not_found",
      "❓",
      "Product Not Found",
      serverMessage ||
        "This product was not found in the registry."
    );
  }

  /* Render a request or server error */

  function showError(errorMessage) {
    clearProductDetails();

    setStatus(
      "invalid",
      "⚠️",
      "Verification Error",
      errorMessage ||
        "Could not complete verification. Please try again later."
    );
  }

  /* Main verification flow */

  function verifyPayload(payload) {
    if (!payload) {
      showError(
        "No verification payload found in the URL. Please scan a valid TrustTrace QR code."
      );
      return;
    }

    spinner.hidden = false;
    clearProductDetails();

    badge.className = "status-badge loading";

    var loadingIcon = badge.querySelector(".status-icon");

    if (loadingIcon) {
      loadingIcon.textContent = "⏳";
    }

    statusText.textContent = "Verifying Product";
    message.textContent = "Checking the product's digital signature...";

    fetch("/api/verify?payload=" + encodeURIComponent(payload), {
      method: "GET",
      headers: {
        "Accept": "application/json"
      }
    })
      .then(function (response) {
        return response.json().then(function (data) {
          if (!response.ok) {
            var error = new Error(
              data.message || "Server returned status " + response.status
            );

            error.responseData = data;
            throw error;
          }

          return data;
        });
      })
      .then(function (data) {
        if (data.status === "authentic") {
          showAuthentic(data.product || {});
        } else if (data.status === "invalid") {
          showInvalid(data.message);
        } else if (data.status === "not_found") {
          showNotFound(data.message);
        } else {
          showError(
            data.message ||
              "Unexpected response from the verification server."
          );
        }
      })
      .catch(function (error) {
        console.error("TrustTrace verification request failed:", error);

        if (error.responseData) {
          var responseData = error.responseData;

          if (responseData.status === "invalid") {
            showInvalid(responseData.message);
            return;
          }

          if (responseData.status === "not_found") {
            showNotFound(responseData.message);
            return;
          }
        }

        showError(
          "Could not reach the verification server. Please try again later."
        );
      });
  }

  /* Read the existing QR payload from the page URL */

  var params = new URLSearchParams(window.location.search);
  var payload = params.get("payload") || "";

  verifyPayload(payload);
})();
