﻿"""
services/scan_monitor.py -- Scan event recording and suspicious-activity detection.

Requirements covered: 5.5, 5.6, 6.1-6.4
Design reference: Scan Monitor section of design.md

Design contract
---------------
* record_scan_event() inserts a row into scan_events using parameterised queries.
* check_for_alerts() evaluates 60-minute rolling windows and creates
  suspicious_activity_alerts rows when thresholds are exceeded.
* Alerts are NEVER used to automatically mark a product counterfeit (Req 6.2);
  they are anomaly flags for manufacturer review only.
* All DB calls use parameterised ? placeholders (Requirement 11.1).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone

from trust_trace.database import get_db

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds (Requirement 6.1, 6.3)
# ---------------------------------------------------------------------------
VOLUME_THRESHOLD      = 10   # >10 scans in 60 min triggers volume alert
GEO_IP_THRESHOLD      = 5    # >5 distinct IPs in 60 min triggers geo alert
WINDOW_MINUTES        = 60
MAX_IP_ENTRIES        = 500  # cap on stored IP list (Requirement 6.4)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _window_start() -> str:
    return _iso(_now_utc() - timedelta(minutes=WINDOW_MINUTES))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def record_scan_event(
    db_path: str,
    product_id: str,
    ip_address: str,
    outcome: str,
    timestamp: datetime | None = None,
) -> None:
    """Insert a scan event into the database.

    Args:
        db_path:    SQLite database path.
        product_id: Product that was scanned.
        ip_address: Source IP of the request; stored as "unavailable" if empty.
        outcome:    One of "authentic", "invalid", "not_found".
        timestamp:  UTC datetime of the scan; defaults to now if omitted.
    """
    resolved_ip = (ip_address or "").strip() or "unavailable"
    ts = _iso(timestamp if timestamp is not None else _now_utc())

    db = get_db(db_path)
    try:
        db.execute(
            "INSERT INTO scan_events (product_id, ip_address, outcome, occurred_at) "
            "VALUES (?, ?, ?, ?)",
            (product_id, resolved_ip, outcome, ts),
        )
        db.commit()
    finally:
        db.close()


def check_for_alerts(db_path: str, product_id: str) -> None:
    """Evaluate the 60-minute rolling window and create alerts if thresholds exceeded.

    Creates at most one unresolved alert per type per product per window.
    Alerts indicate scanning anomalies for manufacturer review only —
    they do NOT automatically classify the product as counterfeit (Req 6.2).

    Args:
        db_path:    SQLite database path.
        product_id: Product to evaluate.
    """
    window = _window_start()
    now_str = _iso(_now_utc())

    db = get_db(db_path)
    try:
        # Fetch all scan events in the rolling window
        rows = db.execute(
            "SELECT ip_address FROM scan_events "
            "WHERE product_id = ? AND occurred_at >= ?",
            (product_id, window),
        ).fetchall()

        total_scans = len(rows)
        distinct_ips = {
            r["ip_address"] for r in rows if r["ip_address"] != "unavailable"
        }
        ip_list = sorted(distinct_ips)[:MAX_IP_ENTRIES]
        ip_json = json.dumps(ip_list)

        # ---- Volume alert ------------------------------------------------
        if total_scans > VOLUME_THRESHOLD:
            existing = db.execute(
                "SELECT id FROM suspicious_activity_alerts "
                "WHERE product_id = ? AND alert_type = 'volume' AND resolved = 0 "
                "AND detected_at >= ?",
                (product_id, window),
            ).fetchone()
            if existing is None:
                db.execute(
                    "INSERT INTO suspicious_activity_alerts "
                    "(product_id, alert_type, detected_at, scan_count, ip_addresses) "
                    "VALUES (?, 'volume', ?, ?, ?)",
                    (product_id, now_str, total_scans, ip_json),
                )
                db.commit()
                logger.info(
                    "Volume alert created: product=%s scans=%d", product_id, total_scans
                )

        # ---- Geographic distribution alert --------------------------------
        if len(distinct_ips) > GEO_IP_THRESHOLD:
            existing = db.execute(
                "SELECT id FROM suspicious_activity_alerts "
                "WHERE product_id = ? AND alert_type = 'geo_distribution' AND resolved = 0 "
                "AND detected_at >= ?",
                (product_id, window),
            ).fetchone()
            if existing is None:
                db.execute(
                    "INSERT INTO suspicious_activity_alerts "
                    "(product_id, alert_type, detected_at, scan_count, ip_addresses) "
                    "VALUES (?, 'geo_distribution', ?, ?, ?)",
                    (product_id, now_str, total_scans, ip_json),
                )
                db.commit()
                logger.info(
                    "Geo-distribution alert created: product=%s distinct_ips=%d",
                    product_id,
                    len(distinct_ips),
                )
    finally:
        db.close()


def get_alerts_for_product(db_path: str, product_id: str) -> list[dict]:
    """Return all unresolved alerts for *product_id* (used by tests and dashboard)."""
    db = get_db(db_path)
    try:
        rows = db.execute(
            "SELECT * FROM suspicious_activity_alerts "
            "WHERE product_id = ? AND resolved = 0 ORDER BY detected_at DESC",
            (product_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        db.close()