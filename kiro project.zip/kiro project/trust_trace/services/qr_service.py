﻿
"""
services/qr_service.py -- QR code generation for TrustTrace.

Requirements covered: 4.1, 4.3, 4.4, 4.5, 4.6
Design reference: QR Service section of design.md
"""

from __future__ import annotations

import base64
import io
import json
import logging

import qrcode
from PIL import Image

from trust_trace.database import get_db
from trust_trace.services import signature_service

logger = logging.getLogger(__name__)

# Minimum PNG dimension required by Requirement 4.3
_MIN_SIZE_PX = 300

# Fallback host used when no host is provided.
_DEFAULT_HOST = "localhost:5000"


def _build_verification_url(
    product: dict,
    sig: str,
    host: str | None = None,
) -> str:
    """Build the verification URL embedded in the QR code.

    The URL contains the signed product payload and its signature.
    The private key is never included in the QR code.

    Args:
        product: Dictionary containing product database columns.
        sig: Base64url ECDSA signature.
        host: Hostname and optional port for the verification URL.

    Returns:
        Full verification URL string.
    """

    resolved_host = host or _DEFAULT_HOST

    # Local development: Flask is served over HTTP.
    # Use HTTPS only when an HTTPS-enabled deployment is configured.
    if current_app_https_enabled():
        scheme = "https"
    else:
        scheme = "http"

    payload_obj = {
        "product_id": product["product_id"],
        "serial_number": product["serial_number"],
        "name": product["name"],
        "manufacturer_id": product["manufacturer_id"],
        "registered_at": product["registered_at"],
        "sig": sig,
    }

    payload_json = json.dumps(payload_obj, separators=(",", ":"))

    payload_b64 = (
        base64.urlsafe_b64encode(payload_json.encode())
        .rstrip(b"=")
        .decode()
    )

    return f"{scheme}://{resolved_host}/verify?payload={payload_b64}"


def current_app_https_enabled() -> bool:
    """Return whether HTTPS URL generation is explicitly enabled."""

    from flask import current_app, has_app_context

    if not has_app_context():
        return False

    return bool(current_app.config.get("QR_USE_HTTPS", False))


def _render_png(url: str) -> bytes:
    """Render a QR code PNG with a minimum dimension of 300 × 300 pixels."""

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )

    qr.add_data(url)
    qr.make(fit=True)

    img: Image.Image = qr.make_image(
        fill_color="black",
        back_color="white",
    ).get_image()

    # Upscale if necessary to meet the 300 × 300 minimum.
    width, height = img.size

    if width < _MIN_SIZE_PX or height < _MIN_SIZE_PX:
        new_size = max(_MIN_SIZE_PX, width, height)
        img = img.resize((new_size, new_size), Image.NEAREST)

    buffer = io.BytesIO()
    img.save(buffer, format="PNG")

    return buffer.getvalue()


def generate_qr_png(
    db_path: str,
    product_id: str,
    manufacturer_id: int,
    host: str | None = None,
) -> bytes | None:
    """Generate a QR PNG using the signature stored for the product."""

    db = get_db(db_path)

    try:
        row = db.execute(
            """
            SELECT *
            FROM products
            WHERE product_id = ? AND manufacturer_id = ?
            """,
            (product_id, manufacturer_id),
        ).fetchone()
    finally:
        db.close()

    if row is None:
        return None

    sig = row["qr_payload_hash"]

    if not sig:
        logger.warning(
            "No signature stored for product %s; cannot generate QR",
            product_id,
        )
        return None

    url = _build_verification_url(dict(row), sig, host)

    return _render_png(url)


def get_or_create_qr(
    db_path: str,
    product_id: str,
    manufacturer_id: int,
    host: str | None = None,
) -> bytes | None:
    """Return the QR PNG, reusing the existing signature where available."""

    db = get_db(db_path)

    try:
        row = db.execute(
            """
            SELECT *
            FROM products
            WHERE product_id = ? AND manufacturer_id = ?
            """,
            (product_id, manufacturer_id),
        ).fetchone()
    finally:
        db.close()

    if row is None:
        return None

    sig = row["qr_payload_hash"]

    if not sig:
        # Attempt to sign the product if the key is available.
        canonical = {
            "product_id": row["product_id"],
            "serial_number": row["serial_number"],
            "name": row["name"],
            "manufacturer_id": row["manufacturer_id"],
            "registered_at": row["registered_at"],
        }

        try:
            sig = signature_service.sign_payload(canonical)

            db2 = get_db(db_path)

            try:
                db2.execute(
                    """
                    UPDATE products
                    SET qr_payload_hash = ?
                    WHERE product_id = ?
                    """,
                    (sig, product_id),
                )
                db2.commit()
            finally:
                db2.close()

        except RuntimeError:
            logger.warning(
                "Key not loaded; cannot sign product %s for QR generation",
                product_id,
            )
            return None

    url = _build_verification_url(dict(row), sig, host)

    return _render_png(url)
