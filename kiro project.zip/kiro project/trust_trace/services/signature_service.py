﻿"""
services/signature_service.py -- ECDSA P-256 signing and verification for TrustTrace.

Design contract (Requirements 10.1 -- 10.6, 4.2, 4.4)
------------------------------------------------------
* Curve:      SECP256R1 (P-256)
* Digest:     SHA-256
* Encoding:   DER-encoded signature, then Base64url without padding
* Canonical payload: JSON serialised with sort_keys=True and no whitespace
  so the byte sequence is deterministic across Python versions and platforms.
* Private key: loaded from the filesystem path given by config.PRIVATE_KEY_PATH.
  It is NEVER returned to callers, logged, or included in any HTTP response.
* Startup guard: load_private_key() raises RuntimeError (and logs CRITICAL)
  when the key file is absent or unreadable.  The application factory calls
  this at startup and exits with code 1 on failure.
"""

from __future__ import annotations

import base64
import json
import logging
import os
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import (
    decode_dss_signature,
    encode_dss_signature,
)
from cryptography.exceptions import InvalidSignature

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level key cache
# ---------------------------------------------------------------------------
# The private key object is loaded once at startup and kept in memory.
# It is never serialised or returned through any public interface.
_private_key: ec.EllipticCurvePrivateKey | None = None
_public_key: ec.EllipticCurvePublicKey | None = None

# Fields that form the canonical signed payload -- order is fixed by sort_keys,
# but we declare them here for documentation and validation purposes.
SIGNED_FIELDS = frozenset(
    {"product_id", "serial_number", "name", "manufacturer_id", "registered_at"}
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_private_key(key_path: str | None = None) -> ec.EllipticCurvePrivateKey:
    """Load the ECDSA P-256 private key from *key_path* and cache it.

    If *key_path* is None the value from the ``PRIVATE_KEY_PATH`` environment
    variable is used, falling back to ``"keys/private.pem"``.

    Raises:
        RuntimeError: If the file does not exist, is not readable, or does not
                      contain a valid EC private key.

    Returns:
        The loaded ``EllipticCurvePrivateKey``.  The object is also cached in
        the module-level ``_private_key`` / ``_public_key`` variables so that
        ``sign_payload`` and ``verify_payload`` can use it without re-reading
        the file on every call.
    """
    global _private_key, _public_key

    resolved_path = key_path or os.environ.get("PRIVATE_KEY_PATH", "keys/private.pem")

    if not os.path.exists(resolved_path):
        msg = f"CRITICAL: Private key file not found at '{resolved_path}'"
        logger.critical(msg)
        raise RuntimeError(msg)

    try:
        with open(resolved_path, "rb") as fh:
            pem_data = fh.read()
    except OSError as exc:
        msg = f"CRITICAL: Private key file unreadable at '{resolved_path}': {exc}"
        logger.critical(msg)
        raise RuntimeError(msg) from exc

    try:
        key = serialization.load_pem_private_key(pem_data, password=None)
    except Exception as exc:
        msg = f"CRITICAL: Failed to parse private key at '{resolved_path}': {exc}"
        logger.critical(msg)
        raise RuntimeError(msg) from exc

    if not isinstance(key, ec.EllipticCurvePrivateKey):
        msg = f"CRITICAL: Key at '{resolved_path}' is not an EC private key"
        logger.critical(msg)
        raise RuntimeError(msg)

    if not isinstance(key.curve, ec.SECP256R1):
        msg = (
            f"CRITICAL: Key at '{resolved_path}' uses curve "
            f"'{key.curve.name}'; expected SECP256R1 (P-256)"
        )
        logger.critical(msg)
        raise RuntimeError(msg)

    _private_key = key
    _public_key = key.public_key()
    logger.info("Private key loaded successfully from '%s'", resolved_path)
    return _private_key


def _get_private_key() -> ec.EllipticCurvePrivateKey:
    """Return the cached private key, or raise if not yet loaded."""
    if _private_key is None:
        raise RuntimeError(
            "Private key has not been loaded. Call load_private_key() first."
        )
    return _private_key


def _get_public_key() -> ec.EllipticCurvePublicKey:
    """Return the cached public key, or raise if not yet loaded."""
    if _public_key is None:
        raise RuntimeError(
            "Public key is not available. Call load_private_key() first."
        )
    return _public_key


def _canonicalise(payload: dict[str, Any]) -> bytes:
    """Serialise *payload* to a deterministic UTF-8 byte string.

    Rules (Requirement 10.4):
    * Keys are sorted in ascending lexicographic order (``sort_keys=True``).
    * No insignificant whitespace (``separators=(',', ':')``.
    * Only the five signed fields are included; any extra keys are silently
      dropped so that the QR payload JSON (which also carries ``sig``) can be
      passed in directly without raising an error.
    """
    canonical = {k: payload[k] for k in sorted(SIGNED_FIELDS) if k in payload}
    return json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_payload(payload: dict[str, Any]) -> str:
    """Sign the canonical form of *payload* and return a Base64url signature.

    The signature covers only the five signed fields (``product_id``,
    ``serial_number``, ``name``, ``manufacturer_id``, ``registered_at``).
    Additional keys in *payload* (e.g. ``sig``) are ignored.

    Args:
        payload: A dict containing at minimum the five signed fields.

    Returns:
        A Base64url-encoded DER signature string with no padding characters.

    Raises:
        RuntimeError: If the private key has not been loaded.
        KeyError: If any of the five required fields is missing from *payload*.
    """
    missing = SIGNED_FIELDS - payload.keys()
    if missing:
        raise KeyError(f"Payload is missing required fields: {sorted(missing)}")

    canonical_bytes = _canonicalise(payload)
    private_key = _get_private_key()

    der_sig = private_key.sign(canonical_bytes, ec.ECDSA(hashes.SHA256()))
    b64url_sig = base64.urlsafe_b64encode(der_sig).rstrip(b"=").decode("ascii")
    return b64url_sig


def verify_payload(payload: dict[str, Any], signature_b64url: str) -> bool:
    """Verify that *signature_b64url* is a valid signature over *payload*.

    The same canonical serialisation used by ``sign_payload`` is applied before
    verification, so the caller may pass the full QR payload (including the
    ``sig`` field) without issue.

    Args:
        payload: Dict containing the five signed fields (extra keys ignored).
        signature_b64url: Base64url DER signature, with or without padding.

    Returns:
        ``True`` if the signature is valid; ``False`` otherwise.
    """
    try:
        # Re-pad to a multiple of 4 before decoding
        padding = "=" * (4 - len(signature_b64url) % 4) if len(signature_b64url) % 4 else ""
        der_sig = base64.urlsafe_b64decode(signature_b64url + padding)
    except Exception:
        return False

    canonical_bytes = _canonicalise(payload)
    public_key = _get_public_key()

    try:
        public_key.verify(der_sig, canonical_bytes, ec.ECDSA(hashes.SHA256()))
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


def reset_keys() -> None:
    """Clear the cached key objects.

    Intended for use in tests that need to swap in a fresh key pair without
    restarting the process.
    """
    global _private_key, _public_key
    _private_key = None
    _public_key = None