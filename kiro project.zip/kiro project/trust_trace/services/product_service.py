﻿"""
services/product_service.py -- Product registration and retrieval for TrustTrace.

Requirements covered: 3.1-3.6, 11.1, 4.2
Design reference: Product Service section of design.md

Design notes
------------
* product_id is generated with secrets.token_hex(16) -- 128 bits of CSPRNG
  entropy rendered as 32 hex characters (Requirement 3.2).
* Duplicate serial numbers per manufacturer are rejected at the DB UNIQUE
  constraint level AND by an explicit pre-check to return a clear error dict
  (Requirement 3.3).
* All DB calls use parameterised ? placeholders (Requirement 11.1).
* At registration time the product payload is signed with the ECDSA P-256
  private key so the signature is ready for QR code generation without
  re-signing (Requirement 4.2).  The signature is stored in the products row.
* The private key is accessed only through signature_service -- it never
  leaves the server (Requirement 4.4).
"""

from __future__ import annotations

import logging
import secrets
from datetime import datetime, timezone

from trust_trace.database import get_db
from trust_trace.services import signature_service

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MAX_FIELD_LENGTH = 255


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _validate_text_field(value: str | None, field_name: str) -> dict | None:
    """Return an error dict if *value* is missing or too long, else None."""
    if not value or not str(value).strip():
        return {"ok": False, "error": "missing_field", "field": field_name}
    if len(str(value)) > MAX_FIELD_LENGTH:
        return {
            "ok": False,
            "error": "field_too_long",
            "field": field_name,
            "max_length": MAX_FIELD_LENGTH,
        }
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def register_product(
    db_path: str,
    manufacturer_id: int,
    name: str,
    category: str,
    serial_number: str,
    brand: str | None = None,
    model: str | None = None,
) -> dict:
    """Register a new product for *manufacturer_id*.

    Validates all required fields, generates a 128-bit random product_id,
    signs the canonical product payload with ECDSA P-256, and persists the
    record to the database.

    Args:
        db_path:         SQLite database path.
        manufacturer_id: ID of the authenticated manufacturer.
        name:            Product name (required, max 255 chars).
        category:        Product category (required, max 255 chars).
        serial_number:   Unique serial number within this manufacturer account
                         (required, max 255 chars).
        brand:           Optional brand / manufacturer label (max 255 chars).
        model:           Optional model identifier (max 255 chars).

    Returns:
        {"ok": True,  "product_id": str, "registered_at": str}
        {"ok": False, "error": str, ...}
    """
    # --- Required field validation ---
    for value, field in [(name, "name"), (category, "category"), (serial_number, "serial_number")]:
        err = _validate_text_field(value, field)
        if err:
            return err

    # --- Optional field length validation ---
    for value, field in [(brand, "brand"), (model, "model")]:
        if value is not None:
            if len(str(value)) > MAX_FIELD_LENGTH:
                return {
                    "ok": False,
                    "error": "field_too_long",
                    "field": field,
                    "max_length": MAX_FIELD_LENGTH,
                }

    name = str(name).strip()
    category = str(category).strip()
    serial_number = str(serial_number).strip()
    brand = str(brand).strip() if brand else None
    model = str(model).strip() if model else None

    db = get_db(db_path)
    try:
        # --- Duplicate serial number check (Requirement 3.3) ---
        existing = db.execute(
            "SELECT product_id FROM products "
            "WHERE manufacturer_id = ? AND serial_number = ?",
            (manufacturer_id, serial_number),
        ).fetchone()
        if existing:
            return {
                "ok": False,
                "error": "duplicate_serial_number",
                "field": "serial_number",
            }

        # --- Generate product ID (Requirement 3.2) ---
        product_id = secrets.token_hex(16)   # 128-bit entropy, 32 hex chars

        registered_at = _now_utc_iso()

        # --- Sign the canonical payload (Requirement 4.2) ---
        # The signature is computed here so QR generation is purely a
        # rendering step that never re-signs (idempotency, Requirement 4.6).
        canonical_payload = {
            "product_id": product_id,
            "serial_number": serial_number,
            "name": name,
            "manufacturer_id": manufacturer_id,
            "registered_at": registered_at,
        }

        try:
            signature = signature_service.sign_payload(canonical_payload)
        except RuntimeError:
            # Key not loaded (e.g. in tests with SKIP_KEY_CHECK=True).
            # Store a sentinel so QR generation can detect it later.
            signature = None

        # --- Persist ---
        db.execute(
            "INSERT INTO products "
            "(product_id, manufacturer_id, name, category, brand, model, "
            " serial_number, registered_at, qr_payload_hash) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                product_id,
                manufacturer_id,
                name,
                category,
                brand,
                model,
                serial_number,
                registered_at,
                signature,   # stored in qr_payload_hash column for idempotency
            ),
        )
        db.commit()

        logger.info(
            "Product registered: id=%s manufacturer=%s serial=%s",
            product_id,
            manufacturer_id,
            serial_number,
        )

        return {
            "ok": True,
            "product_id": product_id,
            "registered_at": registered_at,
        }
    finally:
        db.close()


def get_product(
    db_path: str,
    product_id: str,
    manufacturer_id: int | None = None,
) -> dict | None:
    """Fetch a product record by *product_id*.

    Args:
        db_path:         SQLite database path.
        product_id:      The product's unique identifier.
        manufacturer_id: When provided, the product is only returned if it
                         belongs to this manufacturer (ownership check).
                         Pass None for unauthenticated public verification.

    Returns:
        A dict with product fields, or None if not found / not owned.
    """
    db = get_db(db_path)
    try:
        if manufacturer_id is not None:
            row = db.execute(
                "SELECT * FROM products WHERE product_id = ? AND manufacturer_id = ?",
                (product_id, manufacturer_id),
            ).fetchone()
        else:
            row = db.execute(
                "SELECT * FROM products WHERE product_id = ?",
                (product_id,),
            ).fetchone()

        if not row:
            return None

        return dict(row)
    finally:
        db.close()


def list_products(db_path: str, manufacturer_id: int) -> list[dict]:
    """Return all products belonging to *manufacturer_id*, ordered by registration date.

    Args:
        db_path:         SQLite database path.
        manufacturer_id: Manufacturer whose products to list.

    Returns:
        List of product dicts (may be empty).
    """
    db = get_db(db_path)
    try:
        rows = db.execute(
            "SELECT * FROM products WHERE manufacturer_id = ? ORDER BY registered_at DESC",
            (manufacturer_id,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        db.close()