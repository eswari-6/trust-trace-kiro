﻿"""
services/verification_service.py -- Public product verification for TrustTrace.

Requirements covered: 5.1-5.6
Design reference: Verification Service section of design.md

Design contract
---------------
* verify_product() decodes the Base64url payload from a QR scan, verifies the
  ECDSA P-256 signature, looks up the product, records a scan event, and
  triggers suspicious-activity analysis -- all before returning to the caller.
* Returns one of three statuses: "authentic", "invalid", or "not_found".
* Never exposes private keys, password hashes, or sensitive manufacturer data
  in the response (Requirements 4.4, 11.5).
* All DB calls are parameterised (Requirement 11.1).
"""

from __future__ import annotations

import base64
import json
import logging
from datetime import datetime, timezone

from trust_trace.database import get_db
from trust_trace.services import scan_monitor, signature_service

logger = logging.getLogger(__name__)

# Fields included in the public "authentic" response (no sensitive data)
_PUBLIC_PRODUCT_FIELDS = (
    "product_id", "name", "category", "brand", "model",
    "serial_number", "registered_at",
)


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _decode_payload(signed_payload_b64: str) -> dict | None:
    """Base64url-decode and JSON-parse the QR payload string.

    Returns the parsed dict, or None if decoding/parsing fails.
    """
    try:
        # Re-add padding stripped by urlsafe_b64encode().rstrip(b"=")
        padding = "=" * (4 - len(signed_payload_b64) % 4) if len(signed_payload_b64) % 4 else ""
        raw = base64.urlsafe_b64decode(signed_payload_b64 + padding)
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return None


def verify_product(db_path: str, signed_payload_b64: str, source_ip: str) -> dict:
    """Verify a product authenticity claim from a scanned QR code payload.

    Steps (Requirement 5.6 — all before returning):
    1. Decode and parse the Base64url JSON payload.
    2. Extract the ECDSA signature and verify it against the canonical fields.
    3. Look up the product_id in the database.
    4. Record a scan_event with the outcome and source IP.
    5. Run check_for_alerts() for the product.

    Args:
        db_path:             SQLite database path.
        signed_payload_b64:  Base64url-encoded JSON from the QR ``?payload=`` param.
        source_ip:           Source IP address of the request (stored in scan_event).

    Returns:
        One of:
        {"status": "authentic",  "product": {...safe fields only...}}
        {"status": "invalid",    "message": "Signature verification failed..."}
        {"status": "not_found",  "message": "Product not found in the registry."}
    """
    resolved_ip = (source_ip or "").strip() or "unavailable"

    # ------------------------------------------------------------------ #
    # Step 1: Decode the payload
    # ------------------------------------------------------------------ #
    payload = _decode_payload(signed_payload_b64) if signed_payload_b64 else None
    if not payload or not isinstance(payload, dict):
        return {
            "status": "invalid",
            "message": "Signature verification failed. This product record may have been tampered with.",
        }

    # ------------------------------------------------------------------ #
    # Step 2: Verify the ECDSA signature
    # ------------------------------------------------------------------ #
    sig = payload.get("sig")
    product_id = payload.get("product_id", "")

    if not sig:
        _record_and_alert(db_path, product_id, resolved_ip, "invalid")
        return {
            "status": "invalid",
            "message": "Signature verification failed. This product record may have been tampered with.",
        }

    # Build the canonical subset for verification (matches sign_payload contract)
    try:
        sig_valid = signature_service.verify_payload(payload, sig)
    except RuntimeError:
        # Public key not available (key not loaded) — treat as invalid
        sig_valid = False

    if not sig_valid:
        _record_and_alert(db_path, product_id, resolved_ip, "invalid")
        return {
            "status": "invalid",
            "message": "Signature verification failed. This product record may have been tampered with.",
        }

    # ------------------------------------------------------------------ #
    # Step 3: Look up the product
    # ------------------------------------------------------------------ #
    if not product_id:
        return {
            "status": "not_found",
            "message": "Product not found in the registry.",
        }

    db = get_db(db_path)
    try:
        row = db.execute(
            "SELECT p.*, m.display_name AS manufacturer_name "
            "FROM products p "
            "JOIN manufacturers m ON m.id = p.manufacturer_id "
            "WHERE p.product_id = ?",
            (product_id,),
        ).fetchone()
    finally:
        db.close()

    if row is None:
        _record_and_alert(db_path, product_id, resolved_ip, "not_found")
        return {
            "status": "not_found",
            "message": "Product not found in the registry.",
        }

    # ------------------------------------------------------------------ #
    # Step 4 + 5: Record scan event and check for alerts
    # ------------------------------------------------------------------ #
    _record_and_alert(db_path, product_id, resolved_ip, "authentic")

    # ------------------------------------------------------------------ #
    # Build safe response — no private keys, no password hashes (Req 4.4)
    # ------------------------------------------------------------------ #
    product_data = {field: row[field] for field in _PUBLIC_PRODUCT_FIELDS if field in row.keys()}
    product_data["manufacturer_name"] = row["manufacturer_name"]

    return {
        "status": "authentic",
        "product": product_data,
    }


def _record_and_alert(db_path: str, product_id: str, ip: str, outcome: str) -> None:
    """Record a scan event and trigger alert analysis, best-effort.

    If product_id is blank (malformed payload) or not in DB, the FK constraint
    would fail -- we skip recording rather than crashing (Req 5.7 fallback).
    """
    if not product_id:
        return
    try:
        scan_monitor.record_scan_event(db_path, product_id, ip, outcome)
        scan_monitor.check_for_alerts(db_path, product_id)
    except Exception as exc:
        # Scan monitor failure must not block the verification response (Req 5.7)
        logger.error("Scan monitor error for product %s: %s", product_id, exc)