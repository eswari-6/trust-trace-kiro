﻿
"""
services/auth_service.py — Manufacturer registration, login, and sessions.
"""

from __future__ import annotations

import logging
import re
import secrets
import unicodedata
from datetime import datetime, timedelta, timezone

import flask_bcrypt as _bcrypt

from trust_trace.database import get_db

logger = logging.getLogger(__name__)

MIN_PASSWORD_LENGTH = 12
MAX_FIELD_LENGTH = 255
SESSION_INACTIVITY_HOURS = 8
LOCKOUT_WINDOW_MINUTES = 10
LOCKOUT_THRESHOLD = 5
LOCKOUT_DURATION_MINUTES = 15

_EMAIL_RE = re.compile(
    r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"
)


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _validate_email(email: str) -> bool:
    return bool(_EMAIL_RE.fullmatch(email))


def _hash_password(plaintext: str) -> str:
    hashed = _bcrypt.generate_password_hash(plaintext, rounds=12)
    return hashed.decode("utf-8") if isinstance(hashed, bytes) else hashed


def _check_password(plaintext: str, hashed: str) -> bool:
    return _bcrypt.check_password_hash(hashed, plaintext)


def _count_recent_failures(db, email: str) -> int:
    window_start = _iso(
        _now_utc() - timedelta(minutes=LOCKOUT_WINDOW_MINUTES)
    )
    row = db.execute(
        """
        SELECT COUNT(*)
        FROM login_attempts
        WHERE email = ? AND success = 0 AND attempted_at >= ?
        """,
        (email, window_start),
    ).fetchone()
    return row[0] if row else 0


def _get_lockout_expiry(db, email: str) -> datetime | None:
    window_start = _iso(
        _now_utc() - timedelta(minutes=LOCKOUT_WINDOW_MINUTES)
    )
    rows = db.execute(
        """
        SELECT attempted_at
        FROM login_attempts
        WHERE email = ? AND success = 0 AND attempted_at >= ?
        ORDER BY attempted_at ASC
        """,
        (email, window_start),
    ).fetchall()

    if len(rows) < LOCKOUT_THRESHOLD:
        return None

    failure_time = datetime.strptime(
        rows[LOCKOUT_THRESHOLD - 1]["attempted_at"],
        "%Y-%m-%dT%H:%M:%SZ",
    ).replace(tzinfo=timezone.utc)

    expiry = failure_time + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
    return expiry if expiry > _now_utc() else None


def _record_attempt(db, email: str, success: bool) -> None:
    db.execute(
        """
        INSERT INTO login_attempts (email, attempted_at, success)
        VALUES (?, ?, ?)
        """,
        (email, _iso(_now_utc()), 1 if success else 0),
    )
    db.commit()


def register_manufacturer(
    db_path: str,
    email: str,
    display_name: str,
    password: str,
) -> dict:
    """Register a manufacturer with a securely hashed password."""

    if not email or not _validate_email(email.strip()):
        return {
            "ok": False,
            "error": "invalid_email_format",
            "field": "email",
        }

    email = email.strip().lower()

    if not display_name or not display_name.strip():
        return {
            "ok": False,
            "error": "missing_field",
            "field": "display_name",
        }

    if len(display_name) > MAX_FIELD_LENGTH:
        return {
            "ok": False,
            "error": "field_too_long",
            "field": "display_name",
            "max_length": MAX_FIELD_LENGTH,
        }

    if not isinstance(password, str):
        return {
            "ok": False,
            "error": "password_too_short",
            "min_length": MIN_PASSWORD_LENGTH,
        }

    meaningful_password = "".join(
        ch
        for ch in password
        if unicodedata.category(ch) not in ("Zs", "Cc")
        and ch not in " \t\n\r\x0b\x0c"
    )

    if len(password) < MIN_PASSWORD_LENGTH or not meaningful_password:
        return {
            "ok": False,
            "error": "password_too_short",
            "min_length": MIN_PASSWORD_LENGTH,
        }

    db = get_db(db_path)
    try:
        existing = db.execute(
            "SELECT id FROM manufacturers WHERE email = ?",
            (email,),
        ).fetchone()

        if existing:
            return {"ok": False, "error": "email_already_registered"}

        password_hash = _hash_password(password)

        # Admin permission is never accepted from public registration.
        db.execute(
            """
            INSERT INTO manufacturers (email, display_name, password_hash)
            VALUES (?, ?, ?)
            """,
            (email, display_name.strip(), password_hash),
        )
        db.commit()

        row = db.execute(
            "SELECT id FROM manufacturers WHERE email = ?",
            (email,),
        ).fetchone()

        return {"ok": True, "manufacturer_id": row["id"]}
    finally:
        db.close()


def register_customer(
    db_path: str,
    email: str,
    display_name: str,
    password: str,
) -> dict:
    """Register a customer with a securely hashed password."""

    # Validate email
    if not email or not _validate_email(email.strip()):
        return {
            "ok": False,
            "error": "invalid_email_format",
            "field": "email",
        }

    email = email.strip().lower()

    # Validate customer name
    if not display_name or not display_name.strip():
        return {
            "ok": False,
            "error": "missing_field",
            "field": "display_name",
        }

    display_name = display_name.strip()

    if len(display_name) > MAX_FIELD_LENGTH:
        return {
            "ok": False,
            "error": "field_too_long",
            "field": "display_name",
            "max_length": MAX_FIELD_LENGTH,
        }

    # Validate password
    if not isinstance(password, str):
        return {
            "ok": False,
            "error": "password_too_short",
            "min_length": MIN_PASSWORD_LENGTH,
        }

    meaningful_password = "".join(
        ch
        for ch in password
        if unicodedata.category(ch) not in ("Zs", "Cc")
        and ch not in " \t\n\r\x0b\x0c"
    )

    if (
        len(password) < MIN_PASSWORD_LENGTH
        or not meaningful_password
    ):
        return {
            "ok": False,
            "error": "password_too_short",
            "min_length": MIN_PASSWORD_LENGTH,
        }

    db = get_db(db_path)

    try:
        # Prevent duplicate email across both account types.
        existing = db.execute(
            """
            SELECT email
            FROM manufacturers
            WHERE email = ?

            UNION ALL

            SELECT email
            FROM customers
            WHERE email = ?

            LIMIT 1
            """,
            (email, email),
        ).fetchone()

        if existing:
            return {
                "ok": False,
                "error": "email_already_registered",
            }

        # Use the existing bcrypt password hashing method.
        password_hash = _hash_password(password)

        cursor = db.execute(
            """
            INSERT INTO customers (
                email,
                display_name,
                password_hash
            )
            VALUES (?, ?, ?)
            """,
            (email, display_name, password_hash),
        )

        db.commit()

        return {
            "ok": True,
            "customer_id": cursor.lastrowid,
        }

    except Exception:
        db.rollback()
        logger.exception("Customer registration failed")

        return {
            "ok": False,
            "error": "registration_failed",
        }

    finally:
        db.close()

def login(db_path: str, email: str, password: str) -> dict:
    """Authenticate a manufacturer and issue a session token."""

    if not email or not password:
        return {"ok": False, "error": "authentication_failed"}

    email = email.strip().lower()
    db = get_db(db_path)

    try:
        expiry = _get_lockout_expiry(db, email)
        if expiry is not None:
            return {
                "ok": False,
                "error": "account_locked",
                "locked_until": _iso(expiry),
            }

        row = db.execute(
            "SELECT id, password_hash FROM manufacturers WHERE email = ?",
            (email,),
        ).fetchone()

        # Perform a bcrypt check even when the email does not exist.
        dummy_hash = _hash_password(
            "dummy-prevent-timing-attack-placeholder!"
        )
        stored_hash = row["password_hash"] if row else dummy_hash
        password_valid = _check_password(password, stored_hash)

        if row is None or not password_valid:
            _record_attempt(db, email, success=False)

            expiry = _get_lockout_expiry(db, email)
            if expiry is not None:
                return {
                    "ok": False,
                    "error": "account_locked",
                    "locked_until": _iso(expiry),
                }

            return {"ok": False, "error": "authentication_failed"}

        _record_attempt(db, email, success=True)

        token = secrets.token_hex(32)
        now = _iso(_now_utc())

        db.execute(
            """
            INSERT INTO sessions
                (token, manufacturer_id, created_at, last_active)
            VALUES (?, ?, ?, ?)
            """,
            (token, row["id"], now, now),
        )
        db.commit()

        return {
            "ok": True,
            "session_token": token,
            "expires_in_seconds": SESSION_INACTIVITY_HOURS * 3600,
        }
    finally:
        db.close()


def logout(db_path: str, token: str) -> None:
    """Invalidate a session token."""
    if not token:
        return

    db = get_db(db_path)
    try:
        db.execute(
            "UPDATE sessions SET is_valid = 0 WHERE token = ?",
            (token,),
        )
        db.commit()
    finally:
        db.close()


def validate_session(db_path: str, token: str) -> dict | None:
    """Validate a session and return manufacturer details, or None."""

    if not token:
        return None

    db = get_db(db_path)
    try:
        # Check the actual schema so older databases do not crash.
        manufacturer_columns = {
            row["name"]
            for row in db.execute(
                "PRAGMA table_info(manufacturers)"
            ).fetchall()
        }

        admin_select = (
            "m.is_admin"
            if "is_admin" in manufacturer_columns
            else "0 AS is_admin"
        )

        query = (
            "SELECT s.manufacturer_id, s.last_active, s.is_valid, "
            "m.email, m.display_name, "
            + admin_select
            + " FROM sessions s "
            "JOIN manufacturers m ON m.id = s.manufacturer_id "
            "WHERE s.token = ?"
        )

        row = db.execute(query, (token,)).fetchone()

        if row is None or not row["is_valid"]:
            return None

        cutoff = _iso(
            _now_utc() - timedelta(hours=SESSION_INACTIVITY_HOURS)
        )

        if row["last_active"] < cutoff:
            db.execute(
                "UPDATE sessions SET is_valid = 0 WHERE token = ?",
                (token,),
            )
            db.commit()
            return None

        db.execute(
            "UPDATE sessions SET last_active = ? WHERE token = ?",
            (_iso(_now_utc()), token),
        )
        db.commit()

        return {
            "id": row["manufacturer_id"],
            "email": row["email"],
            "display_name": row["display_name"],
            "is_admin": int(row["is_admin"] or 0),
        }
    finally:
        db.close()


def get_lockout_status(db_path: str, email: str) -> dict:
    """Return the current lockout status for an email address."""

    email = email.strip().lower()
    db = get_db(db_path)

    try:
        expiry = _get_lockout_expiry(db, email)
        return {
            "locked": expiry is not None,
            "locked_until": _iso(expiry) if expiry else None,
        }
    finally:
        db.close()
