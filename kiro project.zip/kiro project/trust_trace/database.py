﻿
"""
database.py — SQLite connection helpers and schema initialisation for TrustTrace.
"""

from __future__ import annotations

import sqlite3


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS manufacturers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (
        strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
    )
);

-- ADDED: Customer accounts
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (
        strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
    )
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    manufacturer_id INTEGER NOT NULL
        REFERENCES manufacturers(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    last_active TEXT NOT NULL,
    is_valid INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    attempted_at TEXT NOT NULL,
    success INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
    product_id TEXT PRIMARY KEY,
    manufacturer_id INTEGER NOT NULL REFERENCES manufacturers(id),
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    serial_number TEXT NOT NULL,
    registered_at TEXT NOT NULL,
    qr_payload_hash TEXT,
    UNIQUE (manufacturer_id, serial_number)
);

CREATE TABLE IF NOT EXISTS scan_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id TEXT NOT NULL REFERENCES products(product_id),
    ip_address TEXT NOT NULL,
    outcome TEXT NOT NULL
        CHECK (outcome IN ('authentic', 'invalid', 'not_found')),
    occurred_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS suspicious_activity_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id TEXT NOT NULL REFERENCES products(product_id),
    alert_type TEXT NOT NULL
        CHECK (alert_type IN ('volume', 'geo_distribution')),
    detected_at TEXT NOT NULL,
    scan_count INTEGER NOT NULL,
    ip_addresses TEXT NOT NULL,
    resolved INTEGER NOT NULL DEFAULT 0,
    resolved_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_token
    ON sessions(token);

CREATE INDEX IF NOT EXISTS idx_login_attempts_email
    ON login_attempts(email, attempted_at);

CREATE INDEX IF NOT EXISTS idx_scan_events_product
    ON scan_events(product_id, occurred_at);

CREATE INDEX IF NOT EXISTS idx_products_manufacturer
    ON products(manufacturer_id);
"""


def get_db(database_path: str) -> sqlite3.Connection:
    """Open and configure a SQLite database connection."""
    conn = sqlite3.connect(
        database_path,
        detect_types=sqlite3.PARSE_DECLTYPES,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    # Enable WAL mode only for file-backed databases.
    if database_path != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")

    return conn


def _apply_migrations_to_connection(conn: sqlite3.Connection) -> None:
    """Apply incremental migrations using an existing connection."""

    # Add brand and model columns to existing products tables.
    product_cols = {
        row["name"]
        for row in conn.execute(
            "PRAGMA table_info(products)"
        ).fetchall()
    }

    if "brand" not in product_cols:
        conn.execute(
            "ALTER TABLE products ADD COLUMN brand TEXT"
        )

    if "model" not in product_cols:
        conn.execute(
            "ALTER TABLE products ADD COLUMN model TEXT"
        )

    # Add admin permission to existing manufacturers.
    manufacturer_cols = {
        row["name"]
        for row in conn.execute(
            "PRAGMA table_info(manufacturers)"
        ).fetchall()
    }

    if "is_admin" not in manufacturer_cols:
        conn.execute(
            "ALTER TABLE manufacturers "
            "ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0"
        )


def init_db(database_path: str) -> None:
    """Create tables and indexes if they do not already exist."""
    conn = get_db(database_path)
    try:
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


def apply_migrations(database_path: str) -> None:
    """Apply incremental schema changes safely and idempotently."""
    conn = get_db(database_path)
    try:
        _apply_migrations_to_connection(conn)
        conn.commit()
    finally:
        conn.close()


def init_db_and_migrate(database_path: str) -> None:
    """
    Initialize the schema and apply migrations on one connection.

    This avoids losing an in-memory database between initialization
    and migration steps when database_path is ':memory:'.
    """
    conn = get_db(database_path)
    try:
        conn.executescript(_SCHEMA_SQL)
        _apply_migrations_to_connection(conn)
        conn.commit()
    finally:
        conn.close()
