﻿"""
generate_key.py -- One-time ECDSA P-256 key generation script for TrustTrace.

Usage (PowerShell):
    python generate_key.py

Behaviour (Requirement 10.2, 14.4)
-----------------------------------
* Generates a fresh ECDSA P-256 private key using the OS CSPRNG.
* Writes PEM-encoded private key to the path given by PRIVATE_KEY_PATH
  (defaults to keys/private.pem).
* On Windows, uses icacls to restrict the file to read-only access for the
  current user only, matching the filesystem-permission requirement.
* Exits with code 0 on success, 1 on any failure.
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec


def generate_key(key_path: str) -> None:
    """Generate a P-256 private key and write it to *key_path*.

    Creates parent directories if they do not exist.
    Restricts filesystem permissions to the current user (owner-read-only).
    """
    # Resolve path relative to this script's directory if not absolute
    if not os.path.isabs(key_path):
        key_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), key_path)

    # Create parent directories if needed
    parent = os.path.dirname(key_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    # Generate key
    private_key = ec.generate_private_key(ec.SECP256R1())

    # Serialise to PEM (unencrypted -- protected by filesystem permissions)
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    # Write file
    with open(key_path, "wb") as fh:
        fh.write(pem_bytes)

    # Restrict permissions
    _restrict_permissions(key_path)

    print(f"Private key written to: {key_path}")
    print("Keep this file secure -- never commit it to source control.")


def _restrict_permissions(path: str) -> None:
    """Restrict the key file to read access for the current user only."""
    if platform.system() == "Windows":
        _restrict_permissions_windows(path)
    else:
        # POSIX: owner read-only (400)
        os.chmod(path, 0o400)


def _restrict_permissions_windows(path: str) -> None:
    """Use icacls on Windows to grant only the current user read access."""
    try:
        username = os.environ.get("USERNAME") or os.environ.get("USER", "")

        # Remove all inherited permissions and existing explicit permissions
        subprocess.run(
            ["icacls", path, "/inheritance:r"],
            check=True,
            capture_output=True,
        )
        # Grant current user read-only access
        if username:
            subprocess.run(
                ["icacls", path, "/grant:r", f"{username}:(R)"],
                check=True,
                capture_output=True,
            )
        print(f"Permissions restricted to current user ({username}) on Windows.")
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        # icacls unavailable or failed -- warn but do not abort key generation
        print(
            f"Warning: Could not set file permissions automatically: {exc}\n"
            "Please manually restrict read access to the key file.",
            file=sys.stderr,
        )


def main() -> None:
    key_path = os.environ.get("PRIVATE_KEY_PATH", "keys/private.pem")
    try:
        generate_key(key_path)
    except Exception as exc:
        print(f"Error: Key generation failed: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()