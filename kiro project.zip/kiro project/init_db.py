﻿"""
init_db.py -- Standalone script that initialises the TrustTrace SQLite database.

Usage (PowerShell):
    python init_db.py

The DATABASE_PATH environment variable controls where the file is created.
Defaults to ``trust_trace.db`` in the current working directory.
"""

import os
import sys

# Allow running from the project root without installing the package.
sys.path.insert(0, os.path.dirname(__file__))

from trust_trace.config import get_config
from trust_trace.database import init_db


def main() -> None:
    cfg = get_config()
    db_path = cfg.DATABASE_PATH
    print(f"Initialising database at: {db_path}")
    init_db(db_path)
    print("Database initialised successfully.")
    print("Tables created: manufacturers, sessions, login_attempts, products, scan_events, suspicious_activity_alerts")


if __name__ == "__main__":
    main()