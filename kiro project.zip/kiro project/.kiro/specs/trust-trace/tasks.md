# Implementation Plan: TrustTrace — Product Authenticity Verification System

## Overview

Build TrustTrace from scratch using Python Flask, SQLite, and plain HTML/CSS/JS. The implementation proceeds in layers: project scaffolding and configuration first, then the database schema and shared utilities, then each backend service and its routes, then the frontend pages, and finally tests and documentation. Every task builds directly on the previous ones so no code is left orphaned.

---

## Tasks

- [ ] 1. Scaffold project structure and configuration
  - Create the full directory tree: `trust_trace/`, `services/`, `routes/`, `static/css/`, `static/js/`, `templates/`, `keys/`, `tests/unit/`, `tests/integration/`
  - Create `config.py` reading `PRIVATE_KEY_PATH`, `DATABASE_PATH`, `SECRET_KEY`, and `FLASK_ENV` from environment variables with safe defaults for development
  - Create `requirements.txt` with pinned versions for `flask`, `flask-bcrypt`, `flask-login`, `cryptography`, `qrcode[pil]`, `Pillow`, `hypothesis`, `pytest`, and `pytest-flask`
  - Create `.env.example` documenting all required environment variables
  - _Requirements: 14.1, 14.5_

- [ ] 2. Implement database layer
  - [ ] 2.1 Write `database.py` with `get_db()` connection helper and `init_db()` that executes the full schema
    - Implement `get_db()` returning a `sqlite3.Connection` with `row_factory = sqlite3.Row` and foreign keys enabled (`PRAGMA foreign_keys = ON`)
    - Implement `init_db()` creating all six tables and indexes as specified in the design: `manufacturers`, `sessions`, `login_attempts`, `products`, `scan_events`, `suspicious_activity_alerts`
    - All SQL uses parameterised `?` placeholders — no string concatenation
    - _Requirements: 11.1, 3.1, 5.5, 6.1_
  - [ ] 2.2 Write `init_db.py` as a standalone script that calls `init_db()` and prints confirmation
    - _Requirements: 14.2, 14.3_

- [ ] 3. Implement Signature Service
  - [ ] 3.1 Write `services/signature_service.py` with `load_private_key()`, `sign_payload()`, and `verify_payload()`
    - `load_private_key()`: reads PEM file at `PRIVATE_KEY_PATH`; raises `RuntimeError` and logs `CRITICAL` if absent or unreadable
    - `sign_payload(payload)`: serialises canonical JSON with `sort_keys=True`, no whitespace; signs with ECDSA P-256 / SHA-256; returns Base64url DER signature (no padding)
    - `verify_payload(payload, signature_b64url)`: reconstructs canonical JSON, decodes Base64url signature, returns `True` if valid, `False` otherwise
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 4.2, 4.4_
  - [ ]* 3.2 Write property test for Signature Service — Property 1: Signature Round-Trip
    - File: `tests/unit/test_signature_service.py`
    - **Property 1: Signature Round-Trip** — for any valid canonical payload, `sign_payload` then `verify_payload` returns `True`
    - Use `@given(st.fixed_dictionaries(...))` with `st.text()` and `st.integers()`
    - Tag: `# Feature: trust-trace, Property 1: Signature Round-Trip`
    - **Validates: Requirements 10.1, 10.4, 13.4**
  - [ ]* 3.3 Write property test for Signature Service — Property 2: Tampered Payload Fails
    - File: `tests/unit/test_signature_service.py`
    - **Property 2: Tampered Payload Fails Verification** — modifying any single field of a validly signed payload causes `verify_payload` to return `False`
    - Use `@given` with `st.one_of` to mutate a randomly selected field
    - Tag: `# Feature: trust-trace, Property 2: Tampered Payload Fails Verification`
    - **Validates: Requirements 5.3, 10.5**
  - [ ]* 3.4 Write unit tests for Signature Service
    - Test: valid payload signs and verifies successfully
    - Test: tampered payload (each field independently) fails verification
    - Test: missing private key file raises `RuntimeError`
    - Test: Base64url output contains no `+`, `/`, or `=` characters
    - _Requirements: 10.1, 10.3, 10.5, 10.6, 13.1_

- [ ] 4. Implement key generation script
  - Write `generate_key.py` using `ec.generate_private_key(ec.SECP256R1())` and serialise to PEM at `PRIVATE_KEY_PATH`
  - On Windows, set ACL via `subprocess` / `icacls` so only the current user has read access
  - Print the output path on success
  - _Requirements: 10.2, 14.4_

- [ ] 5. Implement Auth Service
  - [ ] 5.1 Write `services/auth_service.py` with `register_manufacturer()`, `login()`, `logout()`, `validate_session()`, and `get_lockout_status()`
    - `register_manufacturer()`: validate email (RFC 5322 regex), password length ≥ 12, display_name present and ≤ 255 chars; hash with `flask_bcrypt` rounds=12; insert into `manufacturers`; return `{"ok": True, "manufacturer_id": int}` or appropriate error dict
    - `login()`: look up manufacturer by email; verify bcrypt hash; record attempt in `login_attempts`; enforce 5-failure-in-10-minutes lockout (15-minute lock); issue 32-byte hex session token (`secrets.token_hex(32)`) stored in `sessions`; return token or error
    - `logout()`: set `is_valid = 0` for the session token
    - `validate_session()`: check `is_valid = 1` and `last_active > NOW() - 8 hours`; update `last_active` on success; return manufacturer dict or `None`
    - Never log or store plaintext passwords
    - All DB calls use parameterised queries
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 11.1, 11.4_
  - [ ]* 5.2 Write property test for Auth Service — Property 3: Whitespace/Short Passwords Rejected
    - File: `tests/unit/test_auth_service.py`
    - **Property 3: Whitespace-Only Passwords Are Rejected** — any password with `len(password.strip()) == 0` or `len(password) < 12` causes `register_manufacturer` to return `{"ok": False, ...}`
    - Use `st.text(alphabet=st.characters(whitelist_categories=('Zs',)))` and `st.text(max_size=11)`
    - Tag: `# Feature: trust-trace, Property 3: Whitespace-Only Passwords Are Rejected`
    - **Validates: Requirements 1.3**
  - [ ]* 5.3 Write property test for Auth Service — Property 4: Duplicate Email Rejected
    - File: `tests/unit/test_auth_service.py`
    - **Property 4: Duplicate Email Registration Is Rejected** — any email already in `manufacturers` causes a second registration to return `{"ok": False, "error": "email_already_registered"}`
    - Use `st.emails()` with a pre-seeded test DB
    - Tag: `# Feature: trust-trace, Property 4: Duplicate Email Registration Is Rejected`
    - **Validates: Requirements 1.2**
  - [ ]* 5.4 Write unit tests for Auth Service
    - Test: password shorter than 12 chars rejected
    - Test: duplicate email rejected
    - Test: 5th consecutive failed login within 10 minutes triggers lockout
    - Test: locked account returns `account_locked` error with `locked_until`
    - Test: valid credentials return a session token
    - Test: expired session (`last_active` > 8 hours ago) is rejected
    - Test: logout invalidates session immediately
    - _Requirements: 1.1–1.6, 2.1–2.6, 13.2_

- [ ] 6. Implement Product Service
  - [ ] 6.1 Write `services/product_service.py` with `register_product()`, `get_product()`, and `list_products()`
    - `register_product()`: validate name, category, serial_number present and ≤ 255 chars; generate `product_id` as `secrets.token_hex(16)` (128-bit entropy); insert with `registered_at` timestamp; associate with `manufacturer_id`; return `{"ok": True, "product_id": str}` or error
    - `get_product()`: scoped by `manufacturer_id` when provided; returns `None` for missing or unauthorised products
    - `list_products()`: returns all products for a given `manufacturer_id`
    - All DB calls use parameterised queries
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 11.1_
  - [ ]* 6.2 Write property test for Product Service — Property 5: Duplicate Serial Number Rejected
    - File: `tests/unit/test_product_service.py`
    - **Property 5: Duplicate Serial Number Per Manufacturer Is Rejected** — for any `manufacturer_id` and `serial_number` already registered, a second registration returns `{"ok": False, "error": "duplicate_serial_number"}`
    - Use `st.text(min_size=1, max_size=50)`
    - Tag: `# Feature: trust-trace, Property 5: Duplicate Serial Number Per Manufacturer Is Rejected`
    - **Validates: Requirements 3.3**
  - [ ]* 6.3 Write unit tests for Product Service
    - Test: product registration creates record with correct fields and timestamp
    - Test: `product_id` has exactly 32 hex characters (128 bits)
    - Test: duplicate serial number for same manufacturer returns 409 error
    - Test: same serial number for different manufacturer succeeds
    - Test: field exceeding 255 characters returns validation error
    - _Requirements: 3.1–3.6_

- [ ] 7. Checkpoint — Ensure all tests pass so far
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 8. Implement QR Service
  - [ ] 8.1 Write `services/qr_service.py` with `generate_qr_png()` and `get_or_create_qr()`
    - `generate_qr_png()`: fetch product from DB; call `sign_payload()` on canonical payload; build verification URL with Base64url-encoded JSON payload (including `sig`); generate QR PNG at minimum 300×300 px using `qrcode[pil]`; store `qr_payload_hash` (SHA-256 of signed payload) in `products` table; return PNG bytes
    - `get_or_create_qr()`: check `qr_payload_hash` in DB; if set, reconstruct and return the same PNG; otherwise call `generate_qr_png()` — ensures same signature is returned for subsequent requests
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_
  - [ ]* 8.2 Write property test for QR Service — Property 6: QR Code Idempotency
    - File: `tests/unit/test_qr_service.py`
    - **Property 6: QR Code Idempotency** — for any product that already has `qr_payload_hash` set, calling `get_or_create_qr` again returns the same PNG bytes
    - Use a pre-seeded product fixture
    - Tag: `# Feature: trust-trace, Property 6: QR Code Idempotency`
    - **Validates: Requirements 4.6**
  - [ ]* 8.3 Write unit tests for QR Service
    - Test: generated PNG is at least 300×300 pixels (read with Pillow)
    - Test: QR code encodes a URL containing the `payload` query parameter
    - Test: requesting a QR for a product belonging to a different manufacturer raises authorisation error
    - _Requirements: 4.1, 4.3, 4.5_

- [ ] 9. Implement Scan Monitor
  - [ ] 9.1 Write `services/scan_monitor.py` with `record_scan_event()` and `check_for_alerts()`
    - `record_scan_event()`: insert row into `scan_events` with `product_id`, `ip_address`, `outcome`, `occurred_at`
    - `check_for_alerts()`: query `scan_events` for the 60-minute sliding window ending now; if count > 10 and no existing unresolved `volume` alert for this window, insert `Suspicious_Activity_Alert` with `alert_type='volume'`; if distinct IP count > 5 and no existing unresolved `geo_distribution` alert, insert alert with `alert_type='geo_distribution'`; include `scan_count` and JSON array of distinct IPs
    - All DB calls use parameterised queries
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 5.5_
  - [ ]* 9.2 Write property test for Scan Monitor — Property 7: Volume Alert Threshold
    - File: `tests/unit/test_scan_monitor.py`
    - **Property 7: Volume Alert Threshold** — for any `product_id`, if scan events within a 60-minute window exceed 10, `check_for_alerts` creates a `volume` alert
    - Use `st.lists(scan_event_strategy, min_size=11)` constrained to a 60-minute window
    - Tag: `# Feature: trust-trace, Property 7: Volume Alert Threshold`
    - **Validates: Requirements 6.1**
  - [ ]* 9.3 Write property test for Scan Monitor — Property 8: Geographic Distribution Alert Threshold
    - File: `tests/unit/test_scan_monitor.py`
    - **Property 8: Geographic Distribution Alert Threshold** — for any `product_id`, if distinct IP addresses in a 60-minute window exceed 5, `check_for_alerts` creates a `geo_distribution` alert
    - Use `st.lists` of distinct IPs > 5
    - Tag: `# Feature: trust-trace, Property 8: Geographic Distribution Alert Threshold`
    - **Validates: Requirements 6.3**
  - [ ]* 9.4 Write property test for Scan Monitor — Property 9: Scan Event Persistence
    - File: `tests/unit/test_scan_monitor.py`
    - **Property 9: Scan Event Persistence Round-Trip** — after `record_scan_event`, querying scan events for the product includes a record matching all recorded fields
    - Use `st.from_regex(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')` for IPs
    - Tag: `# Feature: trust-trace, Property 9: Scan Event Persistence Round-Trip`
    - **Validates: Requirements 5.5**
  - [ ]* 9.5 Write unit tests for Scan Monitor
    - Test: exactly 10 scans within 60 minutes does NOT trigger a volume alert
    - Test: 11th scan triggers `volume` alert
    - Test: exactly 5 distinct IPs does NOT trigger geo alert
    - Test: 6th distinct IP triggers `geo_distribution` alert
    - Test: alert record contains `product_id`, `alert_type`, `detected_at`, `scan_count`, and `ip_addresses`
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 13.2_

- [ ] 10. Implement Verification Service
  - [ ] 10.1 Write `services/verification_service.py` with `verify_product()`
    - Decode Base64url `signed_payload_json`; extract `sig` field; call `verify_payload()` on remaining canonical fields
    - If signature valid and `product_id` exists in DB: return `{"status": "authentic", "product": {...}}`
    - If signature invalid: return `{"status": "invalid", "message": "Signature verification failed..."}`
    - If product not found: return `{"status": "not_found", "message": "Product not found..."}`
    - Call `record_scan_event()` then `check_for_alerts()` before returning result (Requirement 5.6)
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6_
  - [ ]* 10.2 Write unit tests for Verification Service
    - Test: authentic payload returns `"authentic"` with product details
    - Test: tampered payload returns `"invalid"`
    - Test: unknown `product_id` returns `"not_found"`
    - Test: `record_scan_event` is called for every attempt
    - _Requirements: 5.1–5.6, 13.5_

- [ ] 11. Implement Dashboard Service
  - [ ] 11.1 Write `services/dashboard_service.py` with `get_product_stats()`, `get_verification_history()`, `get_security_alerts()`, and `resolve_alert()`
    - `get_product_stats()`: return total product count and total verification count for the manufacturer; include per-product stats (scan count, last scan timestamp, registration date) when a specific product is requested
    - `get_verification_history()`: paginated query of `scan_events` joined with `products` filtered by `manufacturer_id`; optional `product_id`, `date_from`, `date_to` filters; max 50 per page; ordered by `occurred_at` DESC
    - `get_security_alerts()`: return all unresolved `suspicious_activity_alerts` for the manufacturer's products
    - `resolve_alert()`: set `resolved = 1` and `resolved_at` for the given `alert_id` scoped to the manufacturer's products
    - All DB calls use parameterised queries
    - _Requirements: 7.1, 7.2, 7.3, 8.1, 8.2, 8.3, 8.4, 8.5, 9.1, 9.2, 9.3, 9.4_
  - [ ]* 11.2 Write property test for Dashboard Service — Property 10: Verification History Date Filtering
    - File: `tests/unit/test_dashboard_service.py`
    - **Property 10: Verification History Filtering Correctness** — all events returned by `get_verification_history` with `date_from`/`date_to` have `occurred_at` within `[date_from, date_to]`; no out-of-range events appear
    - Use `st.dates()` pairs for range bounds
    - Tag: `# Feature: trust-trace, Property 10: Verification History Filtering Correctness`
    - **Validates: Requirements 8.4**
  - [ ]* 11.3 Write unit tests for Dashboard Service
    - Test: stats return correct product and scan counts
    - Test: pagination returns max 50 events per page
    - Test: product filter returns only events for that product
    - Test: resolved alert is removed from unresolved view
    - Test: manufacturer with no products returns appropriate empty-state response
    - _Requirements: 7.1–7.5, 8.1–8.5, 9.1–9.5_

- [ ] 12. Checkpoint — Ensure all service-layer tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 13. Create Flask application factory and wire blueprints
  - [ ] 13.1 Write `app.py` application factory `create_app()`
    - Initialise Flask, load config from `config.py`, initialise `flask_bcrypt`, register all blueprints (`auth`, `product`, `qr`, `verify`, `dashboard`)
    - Call `signature_service.load_private_key()` at startup; catch `RuntimeError`, log `CRITICAL: Private key unavailable`, and raise `SystemExit(1)`
    - Register `@app.errorhandler` for 400, 401, 403, 404, 422, 429, 500 — all return JSON `{"ok": false, "error": "..."}` with no stack trace
    - _Requirements: 10.3, 11.2_

- [ ] 14. Implement Auth Routes
  - [ ] 14.1 Write `routes/auth_routes.py` with POST `/api/auth/register`, POST `/api/auth/login`, POST `/api/auth/logout`
    - `/register`: validate request JSON fields; call `auth_service.register_manufacturer()`; return 201 on success, 409 on duplicate email, 422 on validation error
    - `/login`: call `auth_service.login()`; return 200 with session token, 401 on auth failure, 429 on lockout
    - `/logout`: call `auth_service.logout()` with token from `Authorization` header; return 200
    - All endpoints ignore extraneous fields (Requirement 11.3)
    - _Requirements: 1.1–1.6, 2.1–2.6, 11.2, 11.3, 11.4_

- [ ] 15. Implement Product Routes
  - [ ] 15.1 Write `routes/product_routes.py` with POST `/api/products`, GET `/api/products`, GET `/api/products/<product_id>`
    - All endpoints require a valid session (call `auth_service.validate_session()` via a `@require_auth` decorator)
    - POST: validate fields; call `product_service.register_product()`; return 201 or 409/422
    - GET list: call `product_service.list_products()` scoped to `current_manufacturer_id`
    - GET detail: call `product_service.get_product()` with `manufacturer_id`; return 403 if not owned
    - _Requirements: 3.1–3.6, 11.1, 11.2, 11.3_

- [ ] 16. Implement QR Routes
  - [ ] 16.1 Write `routes/qr_routes.py` with GET `/api/qr/<product_id>`
    - Require valid session
    - Call `qr_service.get_or_create_qr(product_id, manufacturer_id)`; return PNG bytes with `Content-Type: image/png` and `Content-Disposition: attachment; filename="<product_id>.png"`
    - Return 403 if product not owned by authenticated manufacturer
    - _Requirements: 4.1, 4.3, 4.5, 4.6_

- [ ] 17. Implement Verification Routes
  - [ ] 17.1 Write `routes/verify_routes.py` with GET `/api/verify`
    - No authentication required
    - Extract `payload` query param; call `verification_service.verify_product(payload, request.remote_addr)`; return 200 with JSON result
    - Return 400 if `payload` param is missing
    - _Requirements: 5.1–5.6_

- [ ] 18. Implement Dashboard Routes
  - [ ] 18.1 Write `routes/dashboard_routes.py` with GET `/api/dashboard/stats`, GET `/api/dashboard/history`, GET `/api/dashboard/alerts`, PATCH `/api/dashboard/alerts/<alert_id>/resolve`
    - All require valid session
    - `/stats`: call `dashboard_service.get_product_stats()`; accept optional `product_id` query param
    - `/history`: pass `product_id`, `date_from`, `date_to`, `page` query params to `get_verification_history()`
    - `/alerts`: call `get_security_alerts()`
    - `/alerts/<id>/resolve`: call `resolve_alert()`; return 404 if alert not found or not owned
    - _Requirements: 7.1–7.5, 8.1–8.5, 9.1–9.4_

- [ ] 19. Checkpoint — Verify all routes are registered and respond correctly
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 20. Build HTML templates and static assets
  - [ ] 20.1 Write `static/css/style.css` with responsive layout and navy-blue/white colour scheme
    - CSS custom properties: `--navy: #0a1f44`, `--white: #ffffff`, `--accent: #1e90ff`, `--error: #d32f2f`
    - Fluid grid from 320 px to 2560 px; no horizontal scroll at any viewport width
    - `@media (max-width: 767px)` collapses navigation to hamburger menu
    - All form inputs have `<label for="...">` associations; inline error messages use `role="alert"`
    - Colour contrast meets WCAG 2.1 Level AA (minimum 4.5:1 for normal text)
    - _Requirements: 12.1, 12.2, 12.4, 12.5_
  - [ ] 20.2 Write `templates/index.html` (login page) and `templates/register.html` (registration page)
    - Login form: email, password fields; link to `/register`
    - Registration form: email, display name, password fields; inline validation error placeholders
    - All user-supplied values rendered via `textContent` (never `innerHTML`) in JS; server-side template values escaped with `markupsafe.escape()`
    - _Requirements: 12.1, 12.2, 12.5, 11.5_
  - [ ] 20.3 Write `templates/dashboard.html` and `static/js/dashboard.js`
    - Dashboard shows: product count, total scan count, product list with per-product stats, paginated verification history with product/date filters, unresolved security alerts with resolve button
    - Polls `/api/dashboard/stats` every 30 seconds via `setInterval`; updates DOM with `textContent`
    - Navigation collapses to compact menu below 768 px
    - Security alert cards include explanatory text: "This alert indicates a scanning pattern anomaly and does not confirm the physical product is counterfeit"
    - Empty state when no products: message + link to product registration
    - _Requirements: 7.1–7.5, 8.1–8.5, 9.1–9.5, 12.1, 12.2, 12.4, 12.5_
  - [ ] 20.4 Write `templates/verify.html` and `static/js/verify.js`
    - On page load, extract `?payload=` from URL; call `GET /api/verify?payload=...`
    - Render result within primary content area: authentic (green badge + product details), invalid (red warning), not_found (neutral message)
    - Result visible without scrolling on 768 px viewport
    - All values rendered via `textContent`
    - _Requirements: 5.1–5.4, 12.1, 12.2, 12.3, 11.5_
  - [ ] 20.5 Write `static/js/auth.js` handling login and registration form submissions
    - Submit forms via `fetch` to API endpoints; display inline error messages from JSON responses adjacent to the relevant field
    - On successful login, store session token and redirect to `/dashboard`
    - On successful registration, redirect to login page
    - _Requirements: 12.5, 11.5_

- [ ] 21. Write integration tests
  - [ ] 21.1 Write `tests/conftest.py` with shared pytest fixtures
    - `app` fixture: `create_app()` with in-memory SQLite, temp key pair, and `TESTING=True`
    - `client` fixture: Flask test client
    - `auth_headers` fixture: register + login a test manufacturer, return `Authorization` header
    - _Requirements: 13.6_
  - [ ] 21.2 Write `tests/integration/test_product_flow.py`
    - Test: register manufacturer → login → register product → generate QR → decode QR URL → verify product returns `"authentic"`
    - Test: verify with tampered payload field returns `"invalid"`
    - Test: verify with unknown `product_id` returns `"not_found"`
    - _Requirements: 13.3, 13.5_
  - [ ] 21.3 Write `tests/integration/test_auth_flow.py`
    - Test: register → login → access authenticated endpoint → logout → same token rejected
    - Test: register duplicate email returns 409
    - Test: login with wrong password returns 401; after 5 attempts account locked returns 429
    - _Requirements: 13.3_
  - [ ] 21.4 Write `tests/integration/test_verification_flow.py`
    - Test: full QR-code-to-verification round trip returns `"authentic"`
    - Test: submit invalid signature returns `"invalid"` and scan event is recorded
    - Test: duplicate serial number from same manufacturer returns 409
    - _Requirements: 13.3, 13.4, 13.5_

- [ ] 22. Write documentation
  - [ ] 22.1 Write `README.md` with complete Windows PowerShell setup instructions
    - Steps: clone repo, create venv (`python -m venv .venv`), activate (`.venv\Scripts\Activate.ps1`), install dependencies (`pip install -r requirements.txt`), generate key (`python generate_key.py`), initialise DB (`python init_db.py`), set environment variables, run app (`flask run`)
    - Document all environment variables with descriptions
    - Include `pytest` command for running tests
    - _Requirements: 14.2, 14.3_

- [ ] 23. Final checkpoint — Full test suite passes
  - Ensure all tests pass (`python -m pytest tests/ -v`), ask the user if questions arise.

---

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP; core functionality is complete without them.
- Each task references specific requirements for full traceability.
- All DB interactions across every service must use parameterised `?` placeholders — never string concatenation.
- The `@require_auth` decorator (implemented in Task 14) is reused by all authenticated route blueprints.
- The `conftest.py` test DB uses an in-memory SQLite instance so tests are fully isolated and leave no files on disk.
- Property-based tests use Hypothesis `@given` with `settings(max_examples=100)` where needed.
- Run the full suite with: `python -m pytest tests/ -v`

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["2.1", "2.2"] },
    { "id": 1, "tasks": ["3.1", "4"] },
    { "id": 2, "tasks": ["3.2", "3.3", "3.4", "5.1", "8.1"] },
    { "id": 3, "tasks": ["5.2", "5.3", "5.4", "6.1", "8.2", "8.3"] },
    { "id": 4, "tasks": ["6.2", "6.3", "9.1", "10.1"] },
    { "id": 5, "tasks": ["9.2", "9.3", "9.4", "9.5", "10.2", "11.1"] },
    { "id": 6, "tasks": ["11.2", "11.3", "13.1"] },
    { "id": 7, "tasks": ["14.1", "15.1", "16.1", "17.1", "18.1"] },
    { "id": 8, "tasks": ["20.1", "20.2", "20.3", "20.4", "20.5", "21.1"] },
    { "id": 9, "tasks": ["21.2", "21.3", "21.4"] },
    { "id": 10, "tasks": ["22.1"] }
  ]
}
```
