# Design Document: TrustTrace — Product Authenticity Verification System

## Overview

TrustTrace is a web application that lets manufacturers register products, generate cryptographically signed QR codes, and lets customers publicly verify product authenticity by scanning those codes. The system is built on a Python Flask backend with an SQLite database and a plain HTML/CSS/JS frontend styled in navy-blue and white.

The core security guarantee is an ECDSA P-256 digital signature embedded in every QR code. Because only the server holds the private key, any tampered payload will fail signature verification — making counterfeiting detectable.

### Design Goals

- **Tamper-proof QR codes**: Every product payload is signed server-side; the private key never leaves the server.
- **Modular codebase**: Each major concern (auth, products, QR, signatures, verification, scanning, dashboard) lives in its own Python module/blueprint.
- **Defence-in-depth**: Parameterised queries, bcrypt password hashing, account lockout, input validation, and XSS sanitisation at every layer.
- **Windows-compatible setup**: All commands are valid in PowerShell; no POSIX-only tooling required.

---

## Architecture

The application follows a layered, service-oriented structure within a single Flask process. Blueprints separate route concerns; service modules contain all business logic; the database layer is accessed only through parameterised SQLite calls.

```mermaid
graph TD
    subgraph Browser
        A[Manufacturer UI] 
        B[Customer Verification Page]
    end

    subgraph Flask Application
        C[Auth Blueprint] --> AS[Auth Service]
        D[Product Blueprint] --> PS[Product Service]
        E[QR Blueprint] --> QS[QR Service]
        E --> SS[Signature Service]
        F[Verify Blueprint] --> VS[Verification Service]
        F --> SM[Scan Monitor]
        G[Dashboard Blueprint] --> DS[Dashboard Service]
    end

    subgraph Data Layer
        DB[(SQLite DB)]
        KF[keys/private.pem]
    end

    AS --> DB
    PS --> DB
    QS --> DB
    SS --> KF
    VS --> DB
    SM --> DB
    DS --> DB

    A --> C
    A --> D
    A --> E
    A --> G
    B --> F
```

### Key Design Decisions

1. **Single-process Flask with blueprints** — avoids microservice overhead for an application of this scope while still enforcing clean module boundaries.
2. **SQLite** — sufficient for the stated scope; parameterised queries via Python's built-in `sqlite3` module prevent SQL injection and make migration to PostgreSQL straightforward later.
3. **`cryptography` library (PyPI)** for ECDSA — uses OpenSSL bindings, is actively maintained, and supports PEM serialisation, P-256 (`SECP256R1`), SHA-256, and Base64url encoding natively. Preferred over `python-ecdsa` (pure-Python, slower) for production use.
4. **`qrcode[pil]`** with Pillow for QR image generation — produces PNG images streamed directly to the browser without writing to disk.
5. **Flask-Login** for session management — provides `@login_required` decorator and `current_user` proxy; session state is stored server-side using a `sessions` table to support explicit invalidation (logout) and 8-hour inactivity expiry.
6. **`flask-bcrypt`** for password hashing — wraps bcrypt with a configurable work factor (minimum 12).

---

## Components and Interfaces

### Module Structure

```
trust_trace/
├── app.py                  # Application factory; registers blueprints
├── config.py               # Environment-based configuration
├── database.py             # DB connection helpers; schema initialisation
├── services/
│   ├── auth_service.py     # Registration, login, lockout, session tokens
│   ├── product_service.py  # Product CRUD, Product_ID generation
│   ├── qr_service.py       # QR code image generation
│   ├── signature_service.py# Key loading, signing, verifying
│   ├── verification_service.py # Public verification logic
│   ├── scan_monitor.py     # Scan event recording, alert detection
│   └── dashboard_service.py# Statistics aggregation for dashboard
├── routes/
│   ├── auth_routes.py      # /api/auth/* endpoints
│   ├── product_routes.py   # /api/products/* endpoints
│   ├── qr_routes.py        # /api/qr/* endpoints
│   ├── verify_routes.py    # /api/verify/* endpoints
│   └── dashboard_routes.py # /api/dashboard/* endpoints
├── static/
│   ├── css/style.css
│   └── js/
│       ├── auth.js
│       ├── dashboard.js
│       └── verify.js
├── templates/
│   ├── index.html          # Manufacturer landing / login
│   ├── register.html
│   ├── dashboard.html
│   └── verify.html         # Public verification page
├── keys/
│   └── private.pem         # ECDSA P-256 private key (restricted permissions)
├── generate_key.py         # One-time key generation script
├── init_db.py              # Schema creation script
├── requirements.txt
└── README.md
```

### Service Interfaces

#### Auth Service (`services/auth_service.py`)

```python
def register_manufacturer(email: str, display_name: str, password: str) -> dict
# Returns: {"ok": True, "manufacturer_id": int} or {"ok": False, "error": str}

def login(email: str, password: str, ip_address: str) -> dict
# Returns: {"ok": True, "session_token": str} or {"ok": False, "error": str, "locked_until": str|None}

def logout(session_token: str) -> None

def validate_session(session_token: str) -> dict | None
# Returns manufacturer dict if valid, None if expired/invalid

def get_lockout_status(email: str) -> dict
# Returns: {"locked": bool, "locked_until": datetime|None}
```

#### Product Service (`services/product_service.py`)

```python
def register_product(manufacturer_id: int, name: str, category: str, serial_number: str) -> dict
# Returns: {"ok": True, "product_id": str} or {"ok": False, "error": str}

def get_product(product_id: str, manufacturer_id: int | None = None) -> dict | None
# manufacturer_id scopes lookup to owner; None for public verification

def list_products(manufacturer_id: int) -> list[dict]
```

#### Signature Service (`services/signature_service.py`)

```python
def load_private_key() -> ec.EllipticCurvePrivateKey
# Raises RuntimeError if key file absent or unreadable

def sign_payload(payload: dict) -> str
# Canonicalises payload, signs with ECDSA P-256 / SHA-256, returns Base64url signature

def verify_payload(payload: dict, signature_b64url: str) -> bool
# Returns True if signature matches; False if tampered or invalid
```

#### QR Service (`services/qr_service.py`)

```python
def generate_qr_png(product_id: str, manufacturer_id: int) -> bytes
# Returns PNG bytes of the QR code (min 300x300 px)

def get_or_create_qr(product_id: str, manufacturer_id: int) -> bytes
# Returns existing QR if already generated; creates and caches otherwise
```

#### Verification Service (`services/verification_service.py`)

```python
def verify_product(signed_payload_json: str, source_ip: str) -> dict
# Returns: {"status": "authentic"|"invalid"|"not_found", "product": dict|None, "message": str}
```

#### Scan Monitor (`services/scan_monitor.py`)

```python
def record_scan_event(product_id: str, ip_address: str, outcome: str, timestamp: datetime) -> None

def check_for_alerts(product_id: str) -> None
# Evaluates 60-minute windows; creates Suspicious_Activity_Alert if thresholds exceeded
```

#### Dashboard Service (`services/dashboard_service.py`)

```python
def get_product_stats(manufacturer_id: int) -> dict
def get_verification_history(manufacturer_id: int, product_id: str|None, date_from: str|None, date_to: str|None, page: int) -> dict
def get_security_alerts(manufacturer_id: int) -> list[dict]
def resolve_alert(alert_id: int, manufacturer_id: int) -> bool
```

---

## Data Models

### Schema

```sql
-- Manufacturers
CREATE TABLE manufacturers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    email           TEXT    NOT NULL UNIQUE,
    display_name    TEXT    NOT NULL,
    password_hash   TEXT    NOT NULL,
    created_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

-- Session tokens (server-side session store)
CREATE TABLE sessions (
    token           TEXT    PRIMARY KEY,
    manufacturer_id INTEGER NOT NULL REFERENCES manufacturers(id) ON DELETE CASCADE,
    created_at      TEXT    NOT NULL,
    last_active     TEXT    NOT NULL,
    is_valid        INTEGER NOT NULL DEFAULT 1  -- 0 = invalidated (logout)
);

-- Login attempt tracking for lockout
CREATE TABLE login_attempts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    email           TEXT    NOT NULL,
    attempted_at    TEXT    NOT NULL,
    success         INTEGER NOT NULL DEFAULT 0
);

-- Products
CREATE TABLE products (
    product_id      TEXT    PRIMARY KEY,           -- 128-bit CSPRNG hex
    manufacturer_id INTEGER NOT NULL REFERENCES manufacturers(id),
    name            TEXT    NOT NULL,
    category        TEXT    NOT NULL,
    serial_number   TEXT    NOT NULL,
    registered_at   TEXT    NOT NULL,
    qr_payload_hash TEXT,                          -- SHA-256 of the signed payload (idempotency check)
    UNIQUE (manufacturer_id, serial_number)
);

-- Scan events
CREATE TABLE scan_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id  TEXT    NOT NULL REFERENCES products(product_id),
    ip_address  TEXT    NOT NULL,
    outcome     TEXT    NOT NULL CHECK (outcome IN ('authentic','invalid','not_found')),
    occurred_at TEXT    NOT NULL
);

-- Suspicious activity alerts
CREATE TABLE suspicious_activity_alerts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id      TEXT    NOT NULL REFERENCES products(product_id),
    alert_type      TEXT    NOT NULL CHECK (alert_type IN ('volume','geo_distribution')),
    detected_at     TEXT    NOT NULL,
    scan_count      INTEGER NOT NULL,
    ip_addresses    TEXT    NOT NULL,  -- JSON array of distinct IPs
    resolved        INTEGER NOT NULL DEFAULT 0,
    resolved_at     TEXT
);

-- Indexes for hot query paths
CREATE INDEX idx_sessions_token        ON sessions(token);
CREATE INDEX idx_login_attempts_email  ON login_attempts(email, attempted_at);
CREATE INDEX idx_scan_events_product   ON scan_events(product_id, occurred_at);
CREATE INDEX idx_products_manufacturer ON products(manufacturer_id);
```

### Entity Relationships

```mermaid
erDiagram
    MANUFACTURERS {
        int id PK
        text email
        text display_name
        text password_hash
        text created_at
    }
    SESSIONS {
        text token PK
        int manufacturer_id FK
        text created_at
        text last_active
        int is_valid
    }
    LOGIN_ATTEMPTS {
        int id PK
        text email
        text attempted_at
        int success
    }
    PRODUCTS {
        text product_id PK
        int manufacturer_id FK
        text name
        text category
        text serial_number
        text registered_at
        text qr_payload_hash
    }
    SCAN_EVENTS {
        int id PK
        text product_id FK
        text ip_address
        text outcome
        text occurred_at
    }
    SUSPICIOUS_ACTIVITY_ALERTS {
        int id PK
        text product_id FK
        text alert_type
        text detected_at
        int scan_count
        text ip_addresses
        int resolved
        text resolved_at
    }

    MANUFACTURERS ||--o{ SESSIONS : "has"
    MANUFACTURERS ||--o{ PRODUCTS : "owns"
    PRODUCTS ||--o{ SCAN_EVENTS : "receives"
    PRODUCTS ||--o{ SUSPICIOUS_ACTIVITY_ALERTS : "triggers"
```

---

## API Design

All API endpoints return JSON. Authenticated endpoints require a session token in the `Authorization: Bearer <token>` header (or the `session_token` cookie set at login).

### Auth Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/register` | No | Register manufacturer |
| POST | `/api/auth/login` | No | Login; returns session token |
| POST | `/api/auth/logout` | Yes | Invalidate session |

**POST `/api/auth/register`**
```json
// Request
{ "email": "mfg@example.com", "display_name": "Acme Corp", "password": "securepass123!" }

// 201 Created
{ "ok": true, "manufacturer_id": 42 }

// 409 Conflict
{ "ok": false, "error": "email_already_registered" }

// 422 Unprocessable Entity
{ "ok": false, "error": "password_too_short", "min_length": 12 }
{ "ok": false, "error": "invalid_email_format", "field": "email" }
```

**POST `/api/auth/login`**
```json
// Request
{ "email": "mfg@example.com", "password": "securepass123!" }

// 200 OK
{ "ok": true, "session_token": "<token>", "expires_in_seconds": 28800 }

// 401 Unauthorized
{ "ok": false, "error": "authentication_failed" }

// 429 Too Many Requests
{ "ok": false, "error": "account_locked", "locked_until": "2024-01-01T12:15:00Z" }
```

### Product Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/products` | Yes | Register product |
| GET | `/api/products` | Yes | List manufacturer's products |
| GET | `/api/products/<product_id>` | Yes | Get product detail |

**POST `/api/products`**
```json
// Request
{ "name": "Widget Pro", "category": "Electronics", "serial_number": "SN-001" }

// 201 Created
{ "ok": true, "product_id": "a3f8c2d1..." }

// 409 Conflict
{ "ok": false, "error": "duplicate_serial_number", "field": "serial_number" }

// 422 Unprocessable Entity
{ "ok": false, "error": "field_too_long", "field": "name", "max_length": 255 }
```

### QR Code Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/qr/<product_id>` | Yes | Download QR code PNG |

Returns `Content-Type: image/png` with `Content-Disposition: attachment; filename="<product_id>.png"`. Returns 403 if the product does not belong to the authenticated manufacturer.

### Verification Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/verify` | No | Verify product from signed payload in query string |

```
GET /api/verify?payload=<base64url-encoded-signed-payload-json>
```

```json
// 200 OK — authentic
{
  "status": "authentic",
  "product": {
    "product_id": "a3f8c2d1...",
    "name": "Widget Pro",
    "category": "Electronics",
    "serial_number": "SN-001",
    "registered_at": "2024-01-01T10:00:00Z"
  }
}

// 200 OK — invalid signature
{ "status": "invalid", "message": "Signature verification failed. This product record may have been tampered with." }

// 200 OK — unknown product
{ "status": "not_found", "message": "Product not found in the registry." }
```

### Dashboard Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/dashboard/stats` | Yes | Product and scan counts |
| GET | `/api/dashboard/history` | Yes | Paginated scan events |
| GET | `/api/dashboard/alerts` | Yes | Unresolved security alerts |
| PATCH | `/api/dashboard/alerts/<alert_id>/resolve` | Yes | Mark alert resolved |

**GET `/api/dashboard/history`** query params: `product_id`, `date_from` (ISO 8601), `date_to` (ISO 8601), `page` (default 1). Returns max 50 events per page.

---

## Security Design

### ECDSA P-256 Signing Flow

```mermaid
sequenceDiagram
    participant Mfg as Manufacturer
    participant QR as QR Service
    participant Sig as Signature Service
    participant DB

    Mfg->>QR: GET /api/qr/<product_id>
    QR->>DB: Fetch product record
    DB-->>QR: Product data
    QR->>QR: Check qr_payload_hash (idempotency)
    QR->>Sig: sign_payload(canonical_json)
    Sig->>Sig: Load private.pem from filesystem
    Sig->>Sig: ECDSA P-256 / SHA-256 sign
    Sig-->>QR: Base64url signature
    QR->>QR: Build verification URL with signed payload
    QR->>QR: Render QR PNG (min 300×300)
    QR->>DB: Store qr_payload_hash
    QR-->>Mfg: PNG image download
```

**Canonical payload** (signed fields — order is fixed for deterministic serialisation):
```json
{
  "product_id": "<uuid-hex>",
  "serial_number": "<string>",
  "name": "<string>",
  "manufacturer_id": "<int>",
  "registered_at": "<ISO-8601>"
}
```

Keys are sorted alphabetically before JSON serialisation (`sort_keys=True`, no whitespace) to ensure deterministic byte sequences across Python versions.

**Signature encoding**: `base64.urlsafe_b64encode(der_signature).rstrip(b'=').decode()` — Base64url without padding, safe for URL embedding.

**Verification URL format**:
```
https://<host>/verify?payload=<base64url(json_with_signature)>
```

The `payload` query parameter contains a Base64url-encoded JSON object:
```json
{
  "product_id": "...",
  "serial_number": "...",
  "name": "...",
  "manufacturer_id": 42,
  "registered_at": "...",
  "sig": "<base64url-der-signature>"
}
```

### Private Key Management

- Stored at `keys/private.pem` (configurable via `PRIVATE_KEY_PATH` env var).
- Generated once with `generate_key.py` using `ec.generate_private_key(ec.SECP256R1())`.
- On Windows, `generate_key.py` sets the ACL so only the current user (application process owner) has read access.
- At Flask startup (`app.py`), `signature_service.load_private_key()` is called; if the file is absent or unreadable, the application logs `CRITICAL: Private key unavailable` and raises `SystemExit(1)`.
- The public key is derived in-memory at startup; it is never written to a file but is accessible via `/api/public-key` for transparency (optional).

### Password Security

- **Hashing**: `flask_bcrypt.generate_password_hash(password, rounds=12)`.
- **Validation**: Minimum 12 characters enforced before hashing.
- **Never logged**: Passwords are cleared from request objects immediately after hashing; no debug logging of request bodies.

### Account Lockout

- After 5 consecutive failed logins within 10 minutes for a given email, the account is locked for 15 minutes.
- Implemented by querying `login_attempts` for recent failures; no additional in-memory state needed.
- The error response is generic (`authentication_failed`) for unauthenticated failures; lockout status is returned only when the account is confirmed locked.

### Input Validation

- All endpoints validate request body fields before any processing using a thin validation helper (`validate_fields(data, schema)`).
- Parameterised queries: all DB calls use `?` placeholders via Python's `sqlite3` module — no string concatenation in SQL.
- HTML special characters in all user-supplied strings rendered in the browser are escaped using JavaScript's `textContent` (never `innerHTML`) on the frontend, and `markupsafe.escape()` on any server-rendered template values.

### Session Management

- Session tokens: 32-byte CSPRNG hex strings (`secrets.token_hex(32)`).
- Stored in the `sessions` table with `last_active` updated on each authenticated request.
- Expiry check: `last_active < NOW() - 8 hours` → session rejected, `session_expired` error returned.
- Logout: sets `is_valid = 0` in DB; subsequent requests with the same token are rejected.

---

## Frontend Design

### Pages and Navigation

```
/               → index.html    (login form; link to register)
/register       → register.html (manufacturer registration form)
/dashboard      → dashboard.html (authenticated; requires valid session)
/verify         → verify.html   (public; reads ?payload= from URL)
```

### Colour Scheme and Responsive Layout

- **Primary**: `#0a1f44` (navy blue) for header, sidebar, button backgrounds.
- **Secondary**: `#ffffff` (white) for content areas, card backgrounds.
- **Accent**: `#1e90ff` (dodger blue) for links and hover states.
- **Error**: `#d32f2f` (red) for inline validation messages.
- Responsive breakpoints: fluid grid from 320 px to 2560 px; navigation collapses to a hamburger menu below 768 px via CSS `@media` queries.
- All forms use `<label for="...">` associations; error messages use `role="alert"` for screen reader accessibility; colour contrast ratios meet WCAG 2.1 Level AA (minimum 4.5:1 for normal text).

### Dashboard Polling

- The dashboard fetches `/api/dashboard/stats` every 30 seconds using `setInterval` — no WebSocket required.
- Stats are rendered by updating `textContent` of DOM elements (no `innerHTML`).

### Verification Page Flow

```mermaid
sequenceDiagram
    participant C as Customer Browser
    participant V as verify.html (JS)
    participant API as /api/verify

    C->>V: Load /verify?payload=<signed_payload>
    V->>V: Extract payload from URL
    V->>API: GET /api/verify?payload=<signed_payload>
    API-->>V: { status, product, message }
    V->>V: Render result (authentic / invalid / not_found)
```

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Signature Round-Trip

*For any* valid canonical product payload (arbitrary product_id, name, serial_number, manufacturer_id, registered_at), signing the payload with `sign_payload` and then verifying the result with `verify_payload` SHALL return `True`.

**Validates: Requirements 10.1, 10.4, 13.4**

---

### Property 2: Tampered Payload Fails Verification

*For any* valid signed payload, modifying any single field in the canonical payload (product_id, name, serial_number, manufacturer_id, or registered_at) before calling `verify_payload` SHALL return `False`.

**Validates: Requirements 5.3, 10.5**

---

### Property 3: Whitespace-Only Passwords Are Rejected

*For any* string composed entirely of whitespace characters, `register_manufacturer` SHALL return `{"ok": False, "error": "password_too_short"}` (since whitespace-only strings of fewer than 12 characters, or any string considered invalid, fail the minimum-length rule).

More precisely: *for any* password string with `len(password.strip()) == 0` or `len(password) < 12`, registration SHALL be rejected.

**Validates: Requirements 1.3**

---

### Property 4: Duplicate Email Registration Is Rejected

*For any* email address already present in the `manufacturers` table, a subsequent registration request with the same email SHALL return `{"ok": False, "error": "email_already_registered"}` regardless of the other fields.

**Validates: Requirements 1.2**

---

### Property 5: Duplicate Serial Number Per Manufacturer Is Rejected

*For any* manufacturer account and any serial_number already registered under that account, a second product registration with the same serial_number SHALL return `{"ok": False, "error": "duplicate_serial_number"}`.

**Validates: Requirements 3.3**

---

### Property 6: QR Code Idempotency

*For any* product that has already had a QR code generated (i.e., `qr_payload_hash` is set), calling `get_or_create_qr` again SHALL return the same PNG bytes (same payload, same signature) rather than generating a new signature.

**Validates: Requirements 4.6**

---

### Property 7: Volume Alert Threshold

*For any* product_id, if the number of scan events recorded within any 60-minute sliding window exceeds 10, `check_for_alerts` SHALL create a `Suspicious_Activity_Alert` with `alert_type = 'volume'`.

**Validates: Requirements 6.1**

---

### Property 8: Geographic Distribution Alert Threshold

*For any* product_id, if the count of distinct IP addresses in scan events within any 60-minute window exceeds 5, `check_for_alerts` SHALL create a `Suspicious_Activity_Alert` with `alert_type = 'geo_distribution'`.

**Validates: Requirements 6.3**

---

### Property 9: Scan Event Persistence Round-Trip

*For any* verification attempt (arbitrary product_id, ip_address, outcome, timestamp), after `record_scan_event` is called, querying scan events for that product_id SHALL include a record matching the recorded fields.

**Validates: Requirements 5.5**

---

### Property 10: Verification History Filtering Correctness

*For any* manufacturer account, date_from, and date_to values, all scan events returned by `get_verification_history` with those date constraints SHALL have `occurred_at` values within the closed interval `[date_from, date_to]`, and no event outside that interval SHALL appear in the results.

**Validates: Requirements 8.4**

---

## Error Handling

| Scenario | HTTP Status | Response |
|----------|-------------|----------|
| Missing required field | 422 | `{"ok": false, "error": "missing_field", "field": "<name>"}` |
| Field too long (>255 chars) | 400 | `{"ok": false, "error": "field_too_long", "field": "<name>"}` |
| Invalid email format | 422 | `{"ok": false, "error": "invalid_email_format", "field": "email"}` |
| Email already registered | 409 | `{"ok": false, "error": "email_already_registered"}` |
| Auth failure (bad creds) | 401 | `{"ok": false, "error": "authentication_failed"}` |
| Account locked | 429 | `{"ok": false, "error": "account_locked", "locked_until": "<ISO-8601>"}` |
| Invalid / expired session | 401 | `{"ok": false, "error": "session_expired"}` |
| Duplicate serial number | 409 | `{"ok": false, "error": "duplicate_serial_number"}` |
| Product not owned by caller | 403 | `{"ok": false, "error": "forbidden"}` |
| Private key unavailable | — | App refuses to start (logged + `SystemExit`) |
| Verification — bad signature | 200 | `{"status": "invalid", ...}` |
| Verification — unknown product | 200 | `{"status": "not_found", ...}` |
| Unhandled server error | 500 | `{"ok": false, "error": "internal_error"}` (no stack trace) |

Flask's `@app.errorhandler` decorators handle 400, 401, 403, 404, 422, 429, and 500 uniformly.

---

## Testing Strategy

### Dual Testing Approach

Testing uses both **unit/example-based tests** for concrete scenarios and **property-based tests** for universal correctness guarantees. All tests are run with `pytest`.

**Library choice for property-based testing**: [`hypothesis`](https://hypothesis.readthedocs.io/) — the standard PBT library for Python, mature, actively maintained, integrates natively with pytest.

### Test Organisation

```
tests/
├── unit/
│   ├── test_signature_service.py   # Sign/verify, tamper detection, key loading
│   ├── test_auth_service.py        # Registration, login, lockout logic
│   ├── test_product_service.py     # Product registration, ID generation
│   ├── test_scan_monitor.py        # Volume and geo-distribution threshold logic
│   ├── test_verification_service.py# Payload verification outcomes
│   └── test_dashboard_service.py  # Filtering, pagination
├── integration/
│   ├── test_product_flow.py        # Register → QR generate → Verify end-to-end
│   ├── test_auth_flow.py           # Register → Login → Dashboard → Logout
│   └── test_verification_flow.py  # Public verification with authentic and tampered payloads
└── conftest.py                     # Shared fixtures: app instance, test DB, key pair
```

### Property-Based Tests

Each property test uses `@given` from Hypothesis with a minimum of 100 iterations (Hypothesis default; `settings(max_examples=100)` where needed).

**Tag format**: `# Feature: trust-trace, Property <N>: <property_text>`

| Property | Test Location | Hypothesis Strategy |
|----------|--------------|---------------------|
| Property 1: Signature round-trip | `test_signature_service.py` | `st.fixed_dictionaries` with `st.text`, `st.integers` |
| Property 2: Tampered payload fails | `test_signature_service.py` | Same + `st.one_of` to mutate a random field |
| Property 3: Whitespace/short passwords rejected | `test_auth_service.py` | `st.text(alphabet=st.characters(whitelist_categories=('Zs',)))` and `st.text(max_size=11)` |
| Property 4: Duplicate email rejected | `test_auth_service.py` | `st.emails()` |
| Property 5: Duplicate serial number rejected | `test_product_service.py` | `st.text(min_size=1, max_size=50)` |
| Property 6: QR idempotency | `test_qr_service.py` | `st.from_model(Product)` |
| Property 7: Volume alert threshold | `test_scan_monitor.py` | `st.lists(scan_event_strategy, min_size=11)` within 60-min window |
| Property 8: Geo-distribution alert threshold | `test_scan_monitor.py` | `st.lists` of distinct IPs exceeding 5 |
| Property 9: Scan event persistence | `test_scan_monitor.py` | `st.from_regex(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')` for IPs |
| Property 10: History date filtering | `test_dashboard_service.py` | `st.dates()` pairs for range bounds |

### Unit / Example-Based Tests

- **Signature Service**: valid payload signs and verifies; tampered payload fails; missing private key raises `RuntimeError`; Base64url output contains no `+`, `/`, or `=` characters.
- **Scan Monitor**: exactly 10 scans does NOT trigger alert; 11th scan triggers `volume` alert; 5 distinct IPs does NOT trigger geo alert; 6th distinct IP triggers `geo_distribution` alert.
- **Auth Service**: password shorter than 12 chars rejected; duplicate email rejected; 5th failed login within 10 min triggers lockout; valid credentials return session token; expired session rejected.
- **Integration tests**: full product registration → QR generation → public verification cycle; verification with tampered payload returns `"invalid"`; duplicate serial number returns 409.

### Running Tests

```powershell
# From project root in PowerShell
python -m pytest tests/ -v
```

No additional configuration required beyond a standard virtual environment with `requirements.txt` installed.
