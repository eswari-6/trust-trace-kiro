# Requirements Document

## Introduction

TrustTrace is a Product Authenticity Verification System that enables manufacturers to register products and generate cryptographically signed QR codes, and allows customers to verify product authenticity through a public-facing portal. The system uses ECDSA P-256 digital signatures to ensure tamper-proof product records, detects suspicious scanning patterns (such as repeated scans of the same QR code), and provides manufacturers with an admin dashboard for monitoring product registrations, verification history, and security alerts. The backend is implemented in Python Flask with an SQLite database; the frontend uses HTML, CSS, and JavaScript with a responsive navy-blue and white design.

---

## Glossary

- **System**: The TrustTrace Product Authenticity Verification System as a whole.
- **Auth_Service**: The backend component responsible for manufacturer registration, login, session management, and password hashing.
- **Product_Service**: The backend component responsible for product registration, unique ID generation, and serial number management.
- **QR_Service**: The backend component responsible for generating and encoding signed QR codes for registered products.
- **Signature_Service**: The backend component responsible for ECDSA P-256 key management, signing product records, and verifying signatures.
- **Verification_Service**: The backend component responsible for processing public product verification requests and returning authenticity results.
- **Scan_Monitor**: The backend component responsible for tracking scan frequency and detecting suspicious scanning patterns.
- **Dashboard_Service**: The backend component responsible for aggregating product statistics, verification history, and security alerts for the admin dashboard.
- **DB**: The SQLite database that persists all system data.
- **Manufacturer**: An authenticated user who registers and manages products on the platform.
- **Customer**: An unauthenticated user who scans a QR code or visits the public verification page to check product authenticity.
- **Product_ID**: A system-generated unique identifier assigned to each registered product.
- **Serial_Number**: A Manufacturer-provided or system-generated alphanumeric identifier for a specific product unit.
- **QR_Code**: A machine-readable image that encodes a signed verification URL for a registered product.
- **Signed_Payload**: A JSON object containing product metadata and an ECDSA P-256 digital signature, embedded in the verification URL.
- **Private_Key**: The ECDSA P-256 private key held exclusively server-side and used by the Signature_Service to sign product records.
- **Public_Key**: The ECDSA P-256 public key used by the Verification_Service to verify signed product payloads.
- **Verification_Result**: The structured response returned to a Customer after a verification attempt, indicating authenticity status and product details.
- **Scan_Event**: A record of a single verification attempt for a product, including timestamp, IP address, and outcome.
- **Suspicious_Activity_Alert**: A notification raised when the Scan_Monitor detects scanning patterns that warrant review, such as repeated scans of the same QR code within a defined time window.
- **Admin_Dashboard**: The authenticated web interface that provides the Manufacturer with product statistics, verification history, and security alerts.
- **Password_Hash**: A bcrypt-derived hash of a Manufacturer's password stored in the DB.

---

## Requirements

### Requirement 1: Manufacturer Registration

**User Story:** As a Manufacturer, I want to register an account, so that I can log in and manage my products on the platform.

#### Acceptance Criteria

1. WHEN a registration request is submitted with a unique email address, a display name, and a password of at least 12 characters, THE Auth_Service SHALL create a new Manufacturer account and store the Password_Hash in the DB.
2. WHEN a registration request is submitted with an email address that already exists in the DB, THE Auth_Service SHALL return an error indicating the email is already registered.
3. WHEN a registration request is submitted with a password shorter than 12 characters, THE Auth_Service SHALL return an error specifying the minimum password length requirement.
4. WHEN a registration request is submitted with a missing or malformed email address, THE Auth_Service SHALL return a validation error identifying the invalid field.
5. THE Auth_Service SHALL hash all passwords using bcrypt with a minimum work factor of 12 before persisting them to the DB.
6. THE Auth_Service SHALL never store or log plaintext passwords at any point.

---

### Requirement 2: Manufacturer Login and Session Management

**User Story:** As a Manufacturer, I want to log in to my account, so that I can access the admin dashboard and manage my products.

#### Acceptance Criteria

1. WHEN a login request is submitted with a registered email and the correct password, THE Auth_Service SHALL issue an authenticated session token and return it to the Manufacturer.
2. WHEN a login request is submitted with an unregistered email or an incorrect password, THE Auth_Service SHALL return a generic authentication error without indicating which field is incorrect.
3. WHEN a Manufacturer submits 5 consecutive failed login attempts within 10 minutes for the same account, THE Auth_Service SHALL lock the account for 15 minutes and return an error indicating the lockout duration.
4. WHILE a Manufacturer holds a valid session token, THE Auth_Service SHALL grant access to all authenticated endpoints.
5. WHEN a session token expires after 8 hours of inactivity, THE Auth_Service SHALL reject subsequent requests using that token and return a session-expired error.
6. WHEN a Manufacturer logs out, THE Auth_Service SHALL invalidate the session token immediately.

---

### Requirement 3: Product Registration

**User Story:** As a Manufacturer, I want to register a product with its details, so that I can generate a verifiable QR code for it.

#### Acceptance Criteria

1. WHEN an authenticated Manufacturer submits a product registration request with a product name, category, and Serial_Number, THE Product_Service SHALL create a new product record, assign a unique Product_ID, and persist the record to the DB.
2. THE Product_Service SHALL generate Product_IDs using a cryptographically random method that produces at least 128 bits of entropy.
3. WHEN a product registration request is submitted with a Serial_Number that already exists under the same Manufacturer account, THE Product_Service SHALL return an error indicating the duplicate Serial_Number.
4. WHEN a product registration request is submitted with any required field missing or exceeding 255 characters, THE Product_Service SHALL return a validation error identifying the offending field.
5. THE Product_Service SHALL associate each product record with the authenticated Manufacturer's account identifier.
6. WHEN a product is successfully registered, THE Product_Service SHALL record the registration timestamp in the DB.

---

### Requirement 4: QR Code Generation

**User Story:** As a Manufacturer, I want to generate a QR code for each registered product, so that Customers can scan it to verify authenticity.

#### Acceptance Criteria

1. WHEN an authenticated Manufacturer requests a QR code for a registered product, THE QR_Service SHALL generate a QR_Code that encodes a verification URL containing the Signed_Payload for that product.
2. THE Signature_Service SHALL sign the product payload using the server-side Private_Key before the QR_Service embeds it in the verification URL.
3. THE QR_Service SHALL return the QR_Code as a downloadable PNG image with a minimum resolution of 300×300 pixels.
4. THE Signature_Service SHALL never transmit or expose the Private_Key to the browser or any client-facing response.
5. WHEN a Manufacturer requests a QR code for a Product_ID that does not belong to their account, THE QR_Service SHALL return an authorization error.
6. WHEN a QR code has already been generated for a product, THE QR_Service SHALL return the same QR_Code for that product rather than generating a new signature.

---

### Requirement 5: Public Product Verification

**User Story:** As a Customer, I want to verify a product by scanning its QR code or entering a Product_ID, so that I can confirm whether the product is authentic.

#### Acceptance Criteria

1. WHEN a Customer submits a verification request containing a Signed_Payload, THE Verification_Service SHALL verify the ECDSA P-256 signature using the Public_Key and return a Verification_Result.
2. WHEN the signature in the Signed_Payload is valid and the Product_ID exists in the DB, THE Verification_Service SHALL return a Verification_Result with status "authentic" and the product's registered details.
3. WHEN the signature in the Signed_Payload is invalid or has been tampered with, THE Verification_Service SHALL return a Verification_Result with status "invalid" and a message indicating signature failure.
4. WHEN the Product_ID in the Signed_Payload does not exist in the DB, THE Verification_Service SHALL return a Verification_Result with status "not_found".
5. THE Verification_Service SHALL record a Scan_Event for every verification attempt, including the timestamp, source IP address, Product_ID, and outcome.
6. WHEN a verification request is submitted, THE Verification_Service SHALL pass the Scan_Event to the Scan_Monitor for pattern analysis before returning the Verification_Result to the Customer.

---

### Requirement 6: Suspicious Scan Detection

**User Story:** As a Manufacturer, I want the system to detect repeated or unusual QR code scans, so that I can investigate potential counterfeit activity.

#### Acceptance Criteria

1. WHEN the Scan_Monitor detects more than 10 verification attempts for the same Product_ID within any 60-minute window, THE Scan_Monitor SHALL create a Suspicious_Activity_Alert and persist it to the DB.
2. WHEN a Suspicious_Activity_Alert is created, THE Scan_Monitor SHALL NOT automatically mark the product as counterfeit; the alert SHALL indicate that the scanning pattern warrants Manufacturer review.
3. WHEN the Scan_Monitor detects verification attempts for the same Product_ID originating from more than 5 distinct IP addresses within any 60-minute window, THE Scan_Monitor SHALL create a Suspicious_Activity_Alert for geographic distribution anomaly.
4. THE Scan_Monitor SHALL include in each Suspicious_Activity_Alert the Product_ID, alert type, detection timestamp, scan count, and the IP addresses involved.
5. WHEN a Manufacturer views a Suspicious_Activity_Alert, THE Dashboard_Service SHALL present the alert details without asserting that the associated physical product is counterfeit.

---

### Requirement 7: Admin Dashboard — Product Statistics

**User Story:** As a Manufacturer, I want to view statistics about my registered products, so that I can monitor product distribution and verification activity.

#### Acceptance Criteria

1. WHILE a Manufacturer is authenticated, THE Dashboard_Service SHALL display the total count of registered products associated with their account.
2. WHILE a Manufacturer is authenticated, THE Dashboard_Service SHALL display the total count of verification attempts across all products in their account.
3. WHEN a Manufacturer selects a specific product, THE Dashboard_Service SHALL display the verification attempt count, last verification timestamp, and registration date for that product.
4. THE Dashboard_Service SHALL refresh displayed statistics within 30 seconds of a new Scan_Event being recorded without requiring a full page reload.
5. WHEN a Manufacturer account has no registered products, THE Dashboard_Service SHALL display a message indicating no products are registered and provide a link to the product registration page.

---

### Requirement 8: Admin Dashboard — Verification History

**User Story:** As a Manufacturer, I want to view the verification history for my products, so that I can audit scan activity and identify patterns.

#### Acceptance Criteria

1. WHILE a Manufacturer is authenticated, THE Dashboard_Service SHALL display a paginated list of Scan_Events for all products in the Manufacturer's account, ordered by timestamp descending.
2. THE Dashboard_Service SHALL display for each Scan_Event: the Product_ID, Serial_Number, verification outcome, timestamp, and source IP address.
3. WHEN a Manufacturer filters the verification history by a specific product, THE Dashboard_Service SHALL display only Scan_Events associated with that product.
4. WHEN a Manufacturer filters the verification history by date range, THE Dashboard_Service SHALL display only Scan_Events with timestamps within the specified range.
5. THE Dashboard_Service SHALL paginate verification history results with a maximum of 50 Scan_Events per page.

---

### Requirement 9: Admin Dashboard — Security Alerts

**User Story:** As a Manufacturer, I want to view security alerts on my dashboard, so that I can investigate suspicious scanning activity promptly.

#### Acceptance Criteria

1. WHILE a Manufacturer is authenticated, THE Dashboard_Service SHALL display all unresolved Suspicious_Activity_Alerts associated with the Manufacturer's products.
2. THE Dashboard_Service SHALL display for each Suspicious_Activity_Alert: the alert type, Product_ID, detection timestamp, scan count, and distinct IP address count.
3. WHEN a Manufacturer marks a Suspicious_Activity_Alert as resolved, THE Dashboard_Service SHALL update the alert status in the DB and remove the alert from the unresolved alerts view.
4. WHEN no unresolved Suspicious_Activity_Alerts exist for a Manufacturer's account, THE Dashboard_Service SHALL display a message indicating no active alerts.
5. THE Dashboard_Service SHALL present each Suspicious_Activity_Alert with explanatory text clarifying that the alert indicates a scanning pattern anomaly and does not confirm that the physical product is counterfeit.

---

### Requirement 10: Digital Signature Integrity

**User Story:** As a system operator, I want all product records to be protected by digital signatures, so that tampering with QR code payloads can be detected.

#### Acceptance Criteria

1. THE Signature_Service SHALL use ECDSA with the P-256 curve and SHA-256 digest for all signing operations.
2. THE Signature_Service SHALL store the Private_Key in a server-side file protected by filesystem permissions that restrict read access to the application process owner only.
3. WHEN the Private_Key file is absent or unreadable at application startup, THE System SHALL log an error and refuse to start.
4. THE Signature_Service SHALL sign a canonical JSON payload containing the Product_ID, Serial_Number, product name, Manufacturer identifier, and registration timestamp.
5. WHEN the Verification_Service receives a payload where any signed field has been modified, THE Verification_Service SHALL detect the signature mismatch and return a Verification_Result with status "invalid".
6. THE Signature_Service SHALL encode signatures using Base64-URL encoding without padding for safe embedding in URLs.

---

### Requirement 11: Input Validation and Injection Prevention

**User Story:** As a system operator, I want all user inputs to be validated and sanitised, so that the system is protected against injection attacks and malformed data.

#### Acceptance Criteria

1. THE System SHALL use parameterized queries for all DB interactions and SHALL NOT construct SQL statements by concatenating user-supplied strings.
2. WHEN any API endpoint receives a request with a field value exceeding its defined maximum length, THE System SHALL return a 400 status code and a validation error before processing the input.
3. WHEN any API endpoint receives a request with unexpected or extraneous fields, THE System SHALL ignore the extraneous fields and process only the defined fields.
4. THE System SHALL validate that email address fields conform to RFC 5322 format before processing registration or login requests.
5. THE System SHALL sanitise all user-supplied strings rendered in the browser to prevent cross-site scripting by escaping HTML special characters before insertion into the DOM.

---

### Requirement 12: Responsive User Interface

**User Story:** As a Manufacturer or Customer, I want to use TrustTrace on any device, so that I can register products or verify authenticity from desktop, tablet, or mobile browsers.

#### Acceptance Criteria

1. THE System SHALL render all pages using a responsive layout that adapts to viewport widths from 320 pixels to 2560 pixels without horizontal scrolling.
2. THE System SHALL apply a navy-blue and white colour scheme consistently across all pages, with sufficient colour contrast to meet WCAG 2.1 Level AA for text elements.
3. WHEN a Customer navigates to the public verification page, THE System SHALL display the Verification_Result clearly within the primary content area without requiring the Customer to scroll below the fold on a 768-pixel-wide viewport.
4. WHEN a Manufacturer accesses the Admin_Dashboard on a viewport narrower than 768 pixels, THE System SHALL collapse the navigation into a compact menu control.
5. THE System SHALL display all forms with clearly labelled input fields and inline error messages positioned adjacent to the field that caused the error.

---

### Requirement 13: Automated Testing

**User Story:** As a developer, I want automated tests for the system's core components, so that regressions are detected before deployment.

#### Acceptance Criteria

1. THE System SHALL include a unit test suite covering the Signature_Service sign and verify operations, including valid payloads, tampered payloads, and missing fields.
2. THE System SHALL include a unit test suite covering the Scan_Monitor threshold logic for both volume-based and geographic-distribution-based alert conditions.
3. THE System SHALL include integration tests covering the product registration, QR code generation, and public verification flows as end-to-end request sequences.
4. THE System SHALL include a test verifying the round-trip property: FOR ALL valid product registrations, signing the product payload and then verifying the resulting signature SHALL return a valid result equal to the original payload.
5. THE System SHALL include tests for error conditions: submitting invalid signatures, non-existent Product_IDs, and duplicate Serial_Numbers SHALL each return the defined error responses.
6. WHEN the test suite is executed using the command `pytest`, THE System SHALL report test results to standard output without requiring additional configuration beyond a standard Python virtual environment.

---

### Requirement 14: Setup and Deployment

**User Story:** As a developer, I want clear setup instructions for Windows PowerShell, so that I can run the application locally without guesswork.

#### Acceptance Criteria

1. THE System SHALL include a `requirements.txt` file listing all Python dependencies with pinned version numbers.
2. THE System SHALL include a `README.md` file containing step-by-step Windows PowerShell setup instructions covering virtual environment creation, dependency installation, key generation, database initialisation, and application startup.
3. WHEN the setup script or documented commands are executed in sequence on a Windows system with Python 3.10 or later installed, THE System SHALL reach a running state without requiring manual file edits beyond setting environment variables.
4. THE System SHALL include a script or documented command for generating a new ECDSA P-256 Private_Key and storing it in the expected location with correct filesystem permissions.
5. THE System SHALL use environment variables for all configuration values that differ between development and production, including the Private_Key file path, database path, and secret key for session signing.
